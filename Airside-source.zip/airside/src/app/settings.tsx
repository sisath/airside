import React, { useState } from 'react';
import { Alert, Platform, ScrollView, StyleSheet, Text, View } from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Clipboard from 'expo-clipboard';
import { useChat } from '../state/ChatProvider';
import { formatRoomCode } from '../core/room-code';
import { enableAlerts } from '../services/alerts';
import { forgetSettings } from '../services/settings';
import { Brand, Button, Icon, IconButton, Notice } from '../ui/components';
import { usePalette } from '../ui/theme';

export default function Settings() {
  const c = usePalette(), insets = useSafeAreaInsets(), ctx = useChat();
  const [showCode, setShowCode] = useState(false);
  const [copied, setCopied] = useState(false);
  const [alertsOn, setAlertsOn] = useState(false);
  const [problem, setProblem] = useState('');
  const [confirm, setConfirm] = useState<'clear' | 'end' | 'forget' | null>(null);
  const action = async (type: 'clear' | 'end' | 'forget') => {
    if (type === 'clear') ctx.clear();
    else {
      if (type === 'forget') { try { await forgetSettings(); } catch { setProblem('Could not remove the saved chat code. Try again.'); return; } }
      await ctx.end(); router.replace('/');
    }
    setConfirm(null);
  };
  const request = (type: 'clear' | 'end' | 'forget') => {
    if (Platform.OS === 'web') { setConfirm(type); return; }
    const titles = { clear: 'Clear messages on this phone?', end: 'End this chat?', forget: 'Forget this pairing?' };
    const details = { clear: 'This does not remove messages from your partner’s phone.', end: 'The conversation will be removed from this phone. Your saved code stays available.', forget: 'The saved name and code will be removed from this phone. Pair again to reconnect.' };
    Alert.alert(titles[type], details[type], [{ text: 'Cancel', style: 'cancel' }, { text: type === 'clear' ? 'Clear' : type === 'end' ? 'End chat' : 'Forget', style: 'destructive', onPress: () => { void action(type); } }]);
  };
  return <ScrollView contentContainerStyle={[s.page, { paddingTop: insets.top + 10, paddingBottom: insets.bottom + 28 }]} style={{ backgroundColor: c.bg }}>
    <Brand trailing={<IconButton name="close" label="Close settings" onPress={() => router.back()} />} />
    <Text style={[s.title, { color: c.ink }]}>Settings</Text>
    <View style={s.section}><View style={s.sectionTitle}><Icon name="bluetooth-outline" /><Text style={[s.heading, { color: c.ink }]}>Joining a room</Text></View>{[
      'Choose Create a chat on one phone. Use its six-character code to invite people. Compare the verification number before approving each join.',
      'On the other phones choose Join a chat, enter a name and the code, and allow Bluetooth access.',
      'Up to 8 people can join. Keep the owner nearby and every app open. The owner relays messages.',
      'Test together before the flight. Use Bluetooth only when your airline and crew permit it.',
    ].map((text, i) => <View key={text} style={s.step}><Text style={[s.stepNumber, { color: c.green }]}>{i + 1}</Text><Text style={[s.body, { color: c.muted }]}>{text}</Text></View>)}</View>
    <View style={[s.section, { borderTopColor: c.line, borderTopWidth: 1 }]}><View style={s.sectionTitle}><Icon name="lock-closed-outline" /><Text style={[s.heading, { color: c.ink }]}>Room privacy</Text></View><Text style={[s.body, { color: c.muted }]}>A short chat code identifies the room. Each connection uses fresh encryption keys and owner approval. Compare the verification number on both phones; names are not verified identities. The owner relays and can read room messages. There are no accounts, internet servers, ads, or analytics.</Text><Text style={[s.body, { color: c.muted }]}>Rooms expire 24 hours after creation. Names and room expiry are saved securely; messages stay in memory. Photos and voice recordings use temporary app storage and are cleared when you leave, clear or expire the room, or next launch the app. Copies saved outside CloseBy cannot be deleted remotely.</Text><Text style={[s.body, { color: c.muted }]}>Delivered means every participant connected when the owner accepted the message acknowledged it. It is not a read receipt. Late joiners do not receive earlier messages. Queued messages wait while the app stays open.</Text></View>
    <Notice>Rooms support nearby, foreground text, compressed photos and voice messages up to 15 seconds on iPhone and Android. Android hosting requires Bluetooth advertising support. If the owner leaves, the room pauses; there is no automatic owner transfer.</Notice>
    {ctx.running && !ctx.demo && <View style={s.section}><Text style={[s.heading, { color: c.ink }]}>Room code</Text><Button secondary onPress={() => setShowCode(!showCode)}>{showCode ? 'Hide chat code' : 'Show chat code'}</Button>{showCode && <><Text selectable style={[s.secret, { backgroundColor: c.surface, color: c.ink }]}>{formatRoomCode(ctx.code)}</Text><Button secondary onPress={async () => { try { await Clipboard.setStringAsync(formatRoomCode(ctx.code)); setCopied(true); } catch { setProblem('Could not copy the code.'); } }}>{copied ? 'Copied' : 'Copy code'}</Button></>}</View>}
    <View style={s.section}><Text style={[s.heading, { color: c.ink }]}>Offline alerts</Text><Text style={[s.body, { color: c.muted }]}>Alerts require a message to arrive over Bluetooth. Closed or suspended apps cannot reliably receive messages. Typing indicators appear inside the room.</Text><Button secondary onPress={async () => { try { const enabled = await enableAlerts(); setAlertsOn(enabled); if (!enabled) setProblem('Notifications were not enabled. In-app alerts still work.'); } catch { setProblem('Notifications could not be enabled.'); } }}>{alertsOn ? 'Message alerts enabled' : 'Enable message alerts'}</Button></View>
    {problem ? <Notice warning>{problem}</Notice> : null}
    {ctx.running && <View style={s.section}><Button secondary onPress={() => request('clear')}>Clear messages on this phone</Button><Button secondary onPress={() => request('end')}>{ctx.demo ? 'Leave the demo' : 'End chat'}</Button></View>}
    <Button secondary onPress={() => request('forget')}>Forget saved pairing</Button>
    {confirm && <View style={s.section}><Notice warning>{confirm === 'clear' ? 'Clear messages on this phone? Your partner keeps their copy.' : confirm === 'forget' ? 'Remove saved pairing and end this chat?' : 'End this chat and remove its messages from this phone?'}</Notice><Button onPress={() => { void action(confirm); }}>Confirm</Button><Button secondary onPress={() => setConfirm(null)}>Cancel</Button></View>}
    <Text style={[s.version, { color: c.muted }]}>CloseBy 1.2</Text>
  </ScrollView>;
}
const s = StyleSheet.create({ page: { width: '100%', maxWidth: 500, alignSelf: 'center', paddingHorizontal: 25 }, title: { fontSize: 29, fontWeight: '500', letterSpacing: -1, marginTop: 24 }, subtitle: { fontSize: 13, lineHeight: 20, marginTop: 10 }, section: { paddingTop: 24, marginTop: 12, marginBottom: 18, gap: 13 }, sectionTitle: { flexDirection: 'row', alignItems: 'center', gap: 9 }, heading: { fontSize: 16, fontWeight: '600', flexShrink: 1 }, body: { fontSize: 13, lineHeight: 21, flex: 1 }, step: { flexDirection: 'row', gap: 12 }, stepNumber: { fontSize: 14, fontWeight: '600', width: 16, paddingTop: 2 }, secret: { fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace', textAlign: 'center', fontSize: 14, padding: 18, borderRadius: 12 }, version: { textAlign: 'center', fontSize: 11, marginTop: 30 } });
