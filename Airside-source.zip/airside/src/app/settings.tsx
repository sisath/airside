import React, { useState } from 'react';
import { Alert, Platform, ScrollView, StyleSheet, Switch, Text, View } from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Clipboard from 'expo-clipboard';
import config from '../../app.json';
import { useChat } from '../state/ChatProvider';
import { formatRoomCode } from '../core/room-code';
import { Brand, Button, IconButton, Notice } from '../ui/components';
import { usePalette } from '../ui/theme';
export default function Settings() {
  const c = usePalette(), insets = useSafeAreaInsets(), ctx = useChat();
  const [showCode, setShowCode] = useState(false), [copied, setCopied] = useState(false), [busy, setBusy] = useState(false);
  const [problem, setProblem] = useState(''), [confirm, setConfirm] = useState<'clear' | 'end' | null>(null);
  const action = async (type: 'clear' | 'end') => { if (type === 'clear') ctx.clear(); else { await ctx.end(); router.dismissTo('/'); } setConfirm(null); };
  const request = (type: 'clear' | 'end') => {
    if (Platform.OS === 'web') { setConfirm(type); return; }
    Alert.alert(type === 'clear' ? 'Clear Messages On This Phone?' : 'End Chat?', undefined, [{ text: 'Cancel', style: 'cancel' }, { text: type === 'clear' ? 'Clear' : 'End Chat', style: 'destructive', onPress: () => { void action(type); } }]);
  };
  return <ScrollView contentContainerStyle={[s.page, { paddingTop: insets.top + 10, paddingBottom: insets.bottom + 28 }]} style={{ backgroundColor: c.bg }}>
    <Brand onPress={() => router.dismissTo('/')} trailing={<IconButton name="close" label="Close Settings" onPress={() => router.back()} />} />
    {ctx.running && <View style={s.options}>
      <Button secondary onPress={() => setShowCode(!showCode)}>{showCode ? 'Hide Chat Code' : 'Show Chat Code'}</Button>
      {showCode && <><Text selectable style={[s.secret, { backgroundColor: c.surface, color: c.ink }]}>{formatRoomCode(ctx.code)}</Text><Button secondary onPress={async () => { try { await Clipboard.setStringAsync(formatRoomCode(ctx.code)); setCopied(true); } catch { setProblem('Could Not Copy Code.'); } }}>{copied ? 'Copied' : 'Copy Code'}</Button></>}
      <View style={[s.toggle, { borderColor: c.line }]}><Text style={{ color: c.ink, fontSize: 16, fontWeight: '600', flex: 1 }}>Enable Message Alerts</Text><Switch accessibilityLabel="Enable Message Alerts" value={ctx.alertsOn} disabled={busy} trackColor={{ true: c.green }} onValueChange={enabled => { setBusy(true); void ctx.toggleAlerts(enabled).catch(() => setProblem('Could Not Change Alerts.')).finally(() => setBusy(false)); }} /></View>
      <Button secondary onPress={() => request('clear')}>Clear Messages On This Phone</Button>
      <Button secondary onPress={() => request('end')}>End Chat</Button>
    </View>}
    {problem ? <Notice warning>{problem}</Notice> : null}
    {confirm && <View style={s.options}><Text style={{ color: c.ink }}>{confirm === 'clear' ? 'Clear Messages On This Phone?' : 'End Chat?'}</Text><Button onPress={() => { void action(confirm); }}>Confirm</Button><Button secondary onPress={() => setConfirm(null)}>Cancel</Button></View>}
    <Text style={[s.version, { color: c.muted }]}>CloseBy {config.expo.version}</Text>
  </ScrollView>;
}
const s = StyleSheet.create({ page: { width: '100%', maxWidth: 500, alignSelf: 'center', paddingHorizontal: 25 }, options: { gap: 14, marginTop: 28 }, toggle: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 16, borderBottomWidth: 1 }, secret: { fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace', textAlign: 'center', fontSize: 20, padding: 18, borderRadius: 12 }, version: { textAlign: 'center', fontSize: 11, marginTop: 30 } });
