import Sheet from '../ui/Sheet';
import AttachmentButton from '../ui/AttachmentButton';
import VideoMessage from '../ui/VideoMessage';
import React, { useRef, useState } from 'react';
import { Image, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { Redirect, router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useKeepAwake } from 'expo-keep-awake';
import * as Haptics from 'expo-haptics';
import { MAX_TEXT } from '../core/wire';
import type { DisplayMessage } from '../state/ChatProvider';
import type { Attachment } from '../core/media';
import { useRoomPlayback } from '../services/playback';
import MediaTools from '../ui/MediaTools';
import { useChat } from '../state/ChatProvider';
import { Brand, Button, Icon, IconButton, Notice } from '../ui/components';
import { usePalette } from '../ui/theme';

function Bubble({ message, onRetry, onPlay, playing, onHeartReply }: { message: DisplayMessage; onRetry(): void; onPlay(a: Attachment): void; playing: boolean; onHeartReply(): void }) {
  const c = usePalette(), outgoing = message.direction === 'out';
  const time = new Date(message.at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const status = { queued: "Queued", sending: 'Sending…', delivered: 'Delivered', retry: "Retry" }[message.status];
  return <View style={[s.bubble, outgoing ? s.sent : s.received, { backgroundColor: outgoing ? c.sent : c.surface }, message.heart && { borderWidth: 1, borderColor: '#E9B8C5' }]}>{!outgoing && <Text style={[s.sender, { color: c.green }]}>{message.name}</Text>}{message.media ? message.attachment ? message.attachment.kind === 'video' ? <VideoMessage attachment={message.attachment} /> : message.attachment.kind === 'photo' ? <Image accessibilityLabel={"Photo From " + message.name} source={{ uri: 'data:image/jpeg;base64,' + message.attachment.base64 }} style={s.photo} resizeMode="contain" /> : <Pressable accessibilityRole="button" accessibilityLabel={playing ? "Pause Voice Message" : "Play Voice Message"} onPress={() => onPlay(message.attachment!)} style={s.voice}><Icon name={playing ? 'pause' : 'play'} size={22} /><Text style={{ color: c.ink }}>Voice · {Math.ceil((message.attachment.durationMs ?? 0) / 1000)}s</Text></Pressable> : <Text style={[s.message, { color: c.ink }]}>{message.text || ('Receiving ' + message.media.kind[0].toUpperCase() + message.media.kind.slice(1) + ' · ' + Math.round((message.progress ?? 0) * 100) + '%')}</Text> : message.heart ? <Pressable accessibilityRole="button" accessibilityLabel="Reply To Heart" onPress={onHeartReply} style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}><Icon name="heart" size={28} color="#BB3B62" />{message.text !== '♥' && <Text selectable style={[s.message, { color: c.ink, flexShrink: 1 }]}>{message.text}</Text>}</Pressable> : <Text selectable style={[s.message, { color: c.ink }]}>{message.text}</Text>}{outgoing && message.status === 'retry' ? <Pressable onPress={onRetry} accessibilityRole="button" accessibilityLabel="Retry Message" style={s.retry}><Text style={[s.timestamp, { color: c.danger }]}>{status}</Text></Pressable> : <Text style={[s.timestamp, { color: c.muted }]}>{time}{outgoing ? ` · ${status}` : ''}</Text>}</View>;
}
export default function Chat() {
  useKeepAwake('airside-chat', { suppressDeactivateWarnings: true });
  const c = usePalette(), insets = useSafeAreaInsets(), ctx = useChat(), playback = useRoomPlayback();
  const [mediaError, setMediaError] = useState('');
  const [participantsOpen, setParticipantsOpen] = useState(false), [heartOpen, setHeartOpen] = useState(false), [heartText, setHeartText] = useState('');
  const [text, setText] = useState('');
  const [reconnecting, setReconnecting] = useState(false);
  const scroll = useRef<React.ComponentRef<typeof ScrollView>>(null);
  const [atBottom, setAtBottom] = useState(true);
  if (!ctx.running) return <Redirect href="/" />;
  const expired = ctx.chat.status === 'expired';
  const connected = ctx.chat.status === 'connected';
  const label = ctx.demo ? 'Demo' : connected ? 'Connected' : ctx.chat.status === 'verifying' ? 'Verifying…' : ctx.bluetooth === 'connecting' ? 'Connecting…' : expired ? 'Room Expired' : ctx.mode === 'create' ? 'Waiting…' : ctx.verification ? 'Approval Pending…' : 'Searching…';
  const send = (value: string) => {
    if (expired || !value.trim()) return;
    ctx.typing(false); ctx.send(value); setText(''); setAtBottom(true);
    requestAnimationFrame(() => scroll.current?.scrollToEnd({ animated: true }));
    if (Platform.OS !== 'web') void Haptics.selectionAsync().catch(() => {});
  };
  const reconnect = async () => { setReconnecting(true); try { await ctx.reconnect(); } finally { setReconnecting(false); } };
  return <KeyboardAvoidingView style={{ flex: 1, backgroundColor: c.bg }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
    <View style={[s.page, { paddingTop: insets.top + 6, paddingBottom: Math.max(insets.bottom, 10) }]}>
      <Brand onPress={() => router.dismissTo('/')} trailing={<View style={s.actions}><IconButton name="ellipsis-horizontal" label="Chat Settings" onPress={() => router.push('/settings')} /></View>} />
      <View style={[s.contact, { borderTopColor: c.line }]}><Pressable accessibilityRole="button" accessibilityLabel="View Participants" onPress={() => setParticipantsOpen(true)} style={[s.avatar, { backgroundColor: c.avatar }]}><Icon name="people-outline" size={25} /></Pressable><View style={{ flex: 1 }}><Text style={[s.name, { color: c.ink }]}>{ctx.chat.members.length} {ctx.chat.members.length === 1 ? 'Person' : 'People'} · {ctx.mode === 'create' ? "Your Room" : "Group Chat"}</Text><View style={s.connection}><View style={[s.dot, { backgroundColor: connected ? c.green : c.muted }]} /><Text style={[s.connectionText, { color: c.muted }]} accessibilityLiveRegion="polite">{label}</Text></View></View><Icon name={ctx.demo ? 'flask-outline' : 'bluetooth-outline'} size={22} color={c.muted} /></View>
      {ctx.pending.map(request => <View key={request.peer} style={[s.approval, { backgroundColor: c.surface }]}><Text style={{ color: c.ink }}>{request.name} Wants To Join</Text><Text style={{ color: c.muted, fontSize: 12 }}>Verification · {request.verification}</Text><View style={{ flexDirection: 'row', gap: 20 }}><Pressable accessibilityRole="button" accessibilityLabel={'Approve ' + request.name} onPress={() => ctx.approve(request.peer)} style={s.reconnect}><Text style={{ color: c.green }}>Approve</Text></Pressable><Pressable accessibilityRole="button" accessibilityLabel={'Reject ' + request.name} onPress={() => ctx.reject(request.peer)} style={s.reconnect}><Text style={{ color: c.danger }}>Reject</Text></Pressable></View></View>)}
      {!connected && !expired && ctx.mode === 'join' && !!ctx.verification && <Notice>Verification · {ctx.verification}</Notice>}
      {mediaError ? <Notice warning>{mediaError}</Notice> : null}
      {(ctx.error || ctx.chat.problem) && <View style={{ marginTop: 10 }}><Notice warning>{ctx.error || ctx.chat.problem}</Notice></View>}
      {!connected && !ctx.demo && !expired && <View style={s.waiting}><Pressable disabled={reconnecting} accessibilityRole="button" onPress={reconnect} style={s.reconnect}><Text style={[s.reconnectText, { color: c.green }]}>{reconnecting ? 'Reconnecting…' : 'Reconnect'}</Text></Pressable></View>}
      {expired && <Button onPress={() => { void ctx.end().then(() => router.dismissTo('/')); }}>Create A New Chat</Button>}
      <ScrollView ref={scroll} style={{ flex: 1 }} contentContainerStyle={s.messages} keyboardShouldPersistTaps="handled" onContentSizeChange={() => { if (atBottom) scroll.current?.scrollToEnd({ animated: true }); }} onScroll={e => { const { contentOffset, layoutMeasurement, contentSize } = e.nativeEvent; setAtBottom(contentOffset.y + layoutMeasurement.height >= contentSize.height - 65); }} scrollEventThrottle={100}>
        <Text style={[s.day, { color: c.muted }]}>{ctx.demo ? 'DEMO' : 'CHAT'}</Text>
        {ctx.chat.messages.length === 0 && <View style={s.empty}><Icon name="chatbubble-ellipses-outline" size={35} color={c.muted} /><Text style={[s.emptyHeading, { color: c.ink }]}>No Messages Yet</Text></View>}
        {ctx.chat.messages.map(m => <Bubble onHeartReply={() => { setHeartText(''); setHeartOpen(true); }} key={m.id} message={m} onRetry={() => ctx.retry(m.id)} playing={playback.playingId === m.attachment?.id} onPlay={a => { void playback.toggle(a).catch(() => setMediaError("Voice Message Could Not Be Played.")); }} />)}
      </ScrollView>
      {ctx.chat.typing.length > 0 && <Text accessibilityLiveRegion="polite" style={[s.memberNames, { color: c.muted }]}>{ctx.chat.typing.map(p => p.name).join(', ')} Typing…</Text>}
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 10 }}><MediaTools disabled={!connected || expired || ctx.transfer !== null} suspended={ctx.backgrounded || expired} onSend={ctx.sendAttachment} onError={setMediaError} /><AttachmentButton heart label="Send A Heart" icon="heart" disabled={!connected || expired} onPress={() => { ctx.sendHeart(); setHeartText(''); setHeartOpen(true); setAtBottom(true); }} /></View>
      {ctx.transfer !== null && <View style={s.waiting}><Text style={{ color: c.muted }}>Sending Media · {Math.round(ctx.transfer * 100)}%</Text><Pressable accessibilityRole="button" onPress={ctx.cancelTransfer} style={s.reconnect}><Text style={{ color: c.green }}>Cancel Transfer</Text></Pressable></View>}
      <View style={[s.composer, { backgroundColor: c.surface }]}><TextInput accessibilityLabel="Message" multiline editable={!expired} value={text} onChangeText={value => { setText(value); ctx.typing(!!value.trim()); }} onBlur={() => ctx.typing(false)} maxLength={MAX_TEXT} placeholder="Message…" placeholderTextColor={c.muted} style={[s.input, { color: c.ink }]} /><Pressable disabled={expired || !text.trim()} accessibilityRole="button" accessibilityLabel="Send Message" onPress={() => send(text)} style={({ pressed }) => [s.send, { backgroundColor: c.green, opacity: !text.trim() ? .4 : pressed ? .7 : 1 }]}><Icon name="arrow-up" size={24} color={c.greenText} /></Pressable></View>
      {text.length > MAX_TEXT - 100 && <Text style={[s.characterCount, { color: c.muted }]}>{text.length}/{MAX_TEXT}</Text>}
      <Sheet visible={participantsOpen} title="Participants" onClose={() => setParticipantsOpen(false)}>{ctx.chat.members.map(member => <View key={member.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: c.line }}><View style={[s.avatar, { backgroundColor: c.avatar }]}><Text style={{ color: c.green, fontSize: 20, fontWeight: '600' }}>{member.name.slice(0, 1)}</Text></View><Text style={{ flex: 1, color: c.ink, fontSize: 17 }}>{member.name}</Text>{member.host && <Text style={{ color: c.muted }}>Owner</Text>}</View>)}</Sheet>
      <Sheet visible={heartOpen} title="Heart Message" onClose={() => setHeartOpen(false)}><View style={[s.composer, { backgroundColor: c.surface }]}><TextInput accessibilityLabel="Heart Message" placeholder="Message…" placeholderTextColor={c.muted} value={heartText} onChangeText={setHeartText} maxLength={MAX_TEXT} multiline style={[s.input, { color: c.ink }]} /><AttachmentButton heart label="Send Heart Message" icon="heart" disabled={!connected || expired || !heartText.trim()} onPress={() => { ctx.sendHeart(heartText); setHeartText(''); setHeartOpen(false); setAtBottom(true); }} /></View></Sheet>
    </View>
  </KeyboardAvoidingView>;
}
const s = StyleSheet.create({
  photo: { width: 210, height: 180, borderRadius: 10 }, voice: { flexDirection: 'row', alignItems: 'center', gap: 10, minHeight: 44 }, approval: { padding: 12, borderRadius: 12, gap: 8, marginTop: 8 },
  page: { flex: 1, width: '100%', maxWidth: 560, alignSelf: 'center', paddingHorizontal: 20 }, actions: { flexDirection: 'row', gap: 8 },
  contact: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 18, borderTopWidth: 1 }, avatar: { width: 46, height: 46, borderRadius: 26, alignItems: 'center', justifyContent: 'center' }, name: { fontSize: 16, fontWeight: '600' }, connection: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 5 }, dot: { width: 6, height: 6, borderRadius: 3 }, connectionText: { fontSize: 11, flexShrink: 1 },
  flight: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', padding: 12, gap: 8, borderRadius: 12 }, flightText: { fontSize: 11 },
  waiting: { paddingTop: 10, flexDirection: 'row', alignItems: 'center', gap: 8 }, waitingText: { flex: 1, fontSize: 11, lineHeight: 17 }, reconnect: { minHeight: 44, justifyContent: 'center', paddingHorizontal: 6 }, reconnectText: { fontSize: 12, fontWeight: '600' },
  sender: { fontSize: 11, fontWeight: '600', marginBottom: 5 }, memberNames: { fontSize: 11, paddingTop: 10 },
  messages: { paddingVertical: 24, gap: 14 }, day: { textAlign: 'center', fontSize: 9, letterSpacing: 1.4, marginBottom: 10 }, bubble: { maxWidth: '86%', paddingHorizontal: 15, paddingVertical: 12, borderRadius: 19 }, sent: { alignSelf: 'flex-end', borderBottomRightRadius: 5 }, received: { alignSelf: 'flex-start', borderBottomLeftRadius: 5 }, message: { fontSize: 15, lineHeight: 22 }, timestamp: { fontSize: 9, textAlign: 'right', marginTop: 7 }, retry: { minHeight: 35, justifyContent: 'center' },
  empty: { alignItems: 'center', paddingTop: 35, gap: 14 }, emptyHeading: { fontSize: 17, fontWeight: '500' }, emptyText: { textAlign: 'center', fontSize: 13, lineHeight: 20 },
  composer: { borderRadius: 27, flexDirection: 'row', alignItems: 'flex-end', padding: 6, paddingLeft: 16, gap: 8 }, input: { flex: 1, fontSize: 16, minHeight: 44, maxHeight: 115, paddingVertical: 11 }, send: { width: 44, height: 44, borderRadius: 24, alignItems: 'center', justifyContent: 'center' }, footer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, paddingTop: 11, paddingBottom: 4 }, footerText: { fontSize: 10 }, characterCount: { textAlign: 'right', fontSize: 10, marginTop: 5 },
});

