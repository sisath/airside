import React, { useRef, useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { Redirect, router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useKeepAwake } from 'expo-keep-awake';
import * as Haptics from 'expo-haptics';
import { MAX_TEXT } from '../core/wire';
import type { RoomMessage } from '../core/room';
import { useChat } from '../state/ChatProvider';
import { Brand, Icon, IconButton, Notice } from '../ui/components';
import { usePalette } from '../ui/theme';

function Bubble({ message, onRetry }: { message: RoomMessage; onRetry(): void }) {
  const c = usePalette(), outgoing = message.direction === 'out';
  const time = new Date(message.at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const status = { queued: 'Queued · waiting for connection', sending: 'Sending…', delivered: 'Delivered', retry: 'Not delivered · tap to retry' }[message.status];
  return <View style={[s.bubble, outgoing ? s.sent : s.received, { backgroundColor: outgoing ? c.sent : c.surface }]}>{!outgoing && <Text style={[s.sender, { color: c.green }]}>{message.name}</Text>}<Text selectable style={[s.message, { color: c.ink }]}>{message.text}</Text>{outgoing && message.status === 'retry' ? <Pressable onPress={onRetry} accessibilityRole="button" accessibilityLabel="Retry message" style={s.retry}><Text style={[s.timestamp, { color: c.danger }]}>{status}</Text></Pressable> : <Text style={[s.timestamp, { color: c.muted }]}>{time}{outgoing ? ` · ${status}` : ''}</Text>}</View>;
}
export default function Chat() {
  useKeepAwake('airside-chat');
  const c = usePalette(), insets = useSafeAreaInsets(), ctx = useChat();
  const [text, setText] = useState('');
  const [reconnecting, setReconnecting] = useState(false);
  const scroll = useRef<React.ComponentRef<typeof ScrollView>>(null);
  const [atBottom, setAtBottom] = useState(true);
  if (!ctx.running) return <Redirect href="/" />;
  const connected = ctx.chat.status === 'connected';
  const label = ctx.demo ? 'Demo · simulated group' : connected ? 'Connected nearby' : ctx.chat.status === 'verifying' ? 'Verifying private connection…' : ctx.bluetooth === 'connecting' ? 'Connecting…' : ctx.mode === 'create' ? 'Waiting for participants…' : 'Searching for room…';
  const send = (value: string) => {
    if (!value.trim()) return;
    ctx.send(value); setText(''); setAtBottom(true);
    requestAnimationFrame(() => scroll.current?.scrollToEnd({ animated: true }));
    if (Platform.OS !== 'web') void Haptics.selectionAsync().catch(() => {});
  };
  const reconnect = async () => { setReconnecting(true); try { await ctx.reconnect(); } finally { setReconnecting(false); } };
  return <KeyboardAvoidingView style={{ flex: 1, backgroundColor: c.bg }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
    <View style={[s.page, { paddingTop: insets.top + 6, paddingBottom: Math.max(insets.bottom, 10) }]}>
      <Brand trailing={<View style={s.actions}><IconButton name="arrow-back" label="Back to pairing" onPress={() => router.back()} /><IconButton name="ellipsis-horizontal" label="Chat settings" onPress={() => router.push('/settings')} /></View>} />
      <View style={[s.contact, { borderTopColor: c.line }]}><View style={[s.avatar, { backgroundColor: c.avatar }]}><Icon name="people-outline" size={25} /></View><View style={{ flex: 1 }}><Text style={[s.name, { color: c.ink }]}>{ctx.chat.members.length} {ctx.chat.members.length === 1 ? 'person' : 'people'} · {ctx.mode === 'create' ? 'Your room' : 'Group chat'}</Text><View style={s.connection}><View style={[s.dot, { backgroundColor: connected ? c.green : c.muted }]} /><Text style={[s.connectionText, { color: c.muted }]} accessibilityLiveRegion="polite">{label}</Text></View></View><Icon name={ctx.demo ? 'flask-outline' : 'bluetooth-outline'} size={22} color={c.muted} /></View>
      {ctx.demo ? <Notice>Demo mode. Replies are simulated; no messages leave this device.</Notice> : <View style={[s.flight, { backgroundColor: c.surface }]}><Icon name="airplane-outline" size={15} color={c.muted} /><Text style={[s.flightText, { color: c.muted }]}>Offline</Text></View>}
      <Text numberOfLines={2} style={[s.memberNames, { color: c.muted }]}>{ctx.chat.members.map(m => m.name + (m.host ? ' (owner)' : '')).join(' · ')}</Text>
      {(ctx.error || ctx.chat.problem) && <View style={{ marginTop: 10 }}><Notice warning>{ctx.error || ctx.chat.problem}</Notice></View>}
      {!connected && !ctx.demo && <View style={s.waiting}><Text style={[s.waitingText, { color: c.muted }]}>Keep Bluetooth on and the room owner nearby. Messages wait here until connected.</Text><Pressable disabled={reconnecting} accessibilityRole="button" onPress={reconnect} style={s.reconnect}><Text style={[s.reconnectText, { color: c.green }]}>{reconnecting ? 'Reconnecting…' : 'Reconnect'}</Text></Pressable></View>}
      <ScrollView ref={scroll} style={{ flex: 1 }} contentContainerStyle={s.messages} keyboardShouldPersistTaps="handled" onContentSizeChange={() => { if (atBottom) scroll.current?.scrollToEnd({ animated: true }); }} onScroll={e => { const { contentOffset, layoutMeasurement, contentSize } = e.nativeEvent; setAtBottom(contentOffset.y + layoutMeasurement.height >= contentSize.height - 65); }} scrollEventThrottle={100}>
        <Text style={[s.day, { color: c.muted }]}>{ctx.demo ? 'DEMO' : 'CHAT'}</Text>
        {ctx.chat.messages.length === 0 && <View style={s.empty}><Icon name="chatbubble-ellipses-outline" size={35} color={c.muted} /><Text style={[s.emptyHeading, { color: c.ink }]}>No messages yet</Text><Text style={[s.emptyText, { color: c.muted }]}>Send a message to start chatting.</Text></View>}
        {ctx.chat.messages.map(m => <Bubble key={m.id} message={m} onRetry={() => ctx.retry(m.id)} />)}
      </ScrollView>
      <View style={s.quickRow}>{['Want a snack? 🍪', 'Look outside ☁️'].map(message => <Pressable key={message} accessibilityRole="button" onPress={() => send(message)} style={[s.quick, { borderColor: c.line }]}><Text style={[s.quickText, { color: c.ink }]}>{message}</Text></Pressable>)}</View>
      <View style={[s.composer, { backgroundColor: c.surface }]}><TextInput accessibilityLabel="Message" multiline value={text} onChangeText={setText} maxLength={MAX_TEXT} placeholder="Message…" placeholderTextColor={c.muted} style={[s.input, { color: c.ink }]} /><Pressable disabled={!text.trim()} accessibilityRole="button" accessibilityLabel="Send message" onPress={() => send(text)} style={({ pressed }) => [s.send, { backgroundColor: c.green, opacity: !text.trim() ? .4 : pressed ? .7 : 1 }]}><Icon name="arrow-up" size={24} color={c.greenText} /></Pressable></View>
      {text.length > MAX_TEXT - 100 && <Text style={[s.characterCount, { color: c.muted }]}>{text.length}/{MAX_TEXT}</Text>}
      <View style={s.footer}><Icon name="lock-closed-outline" size={11} color={c.muted} /><Text style={[s.footerText, { color: c.muted }]}>{ctx.demo ? 'Preview only · Bluetooth is not in use' : 'Encrypted · Keep CloseBy open on all phones'}</Text></View>
    </View>
  </KeyboardAvoidingView>;
}
const s = StyleSheet.create({
  page: { flex: 1, width: '100%', maxWidth: 560, alignSelf: 'center', paddingHorizontal: 20 }, actions: { flexDirection: 'row', gap: 8 },
  contact: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 18, borderTopWidth: 1 }, avatar: { width: 46, height: 46, borderRadius: 26, alignItems: 'center', justifyContent: 'center' }, name: { fontSize: 16, fontWeight: '600' }, connection: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 5 }, dot: { width: 6, height: 6, borderRadius: 3 }, connectionText: { fontSize: 11, flexShrink: 1 },
  flight: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', padding: 12, gap: 8, borderRadius: 12 }, flightText: { fontSize: 11 },
  waiting: { paddingTop: 10, flexDirection: 'row', alignItems: 'center', gap: 8 }, waitingText: { flex: 1, fontSize: 11, lineHeight: 17 }, reconnect: { minHeight: 44, justifyContent: 'center', paddingHorizontal: 6 }, reconnectText: { fontSize: 12, fontWeight: '600' },
  sender: { fontSize: 11, fontWeight: '600', marginBottom: 5 }, memberNames: { fontSize: 11, paddingTop: 10 },
  messages: { paddingVertical: 24, gap: 14 }, day: { textAlign: 'center', fontSize: 9, letterSpacing: 1.4, marginBottom: 10 }, bubble: { maxWidth: '86%', paddingHorizontal: 15, paddingVertical: 12, borderRadius: 19 }, sent: { alignSelf: 'flex-end', borderBottomRightRadius: 5 }, received: { alignSelf: 'flex-start', borderBottomLeftRadius: 5 }, message: { fontSize: 15, lineHeight: 22 }, timestamp: { fontSize: 9, textAlign: 'right', marginTop: 7 }, retry: { minHeight: 35, justifyContent: 'center' },
  empty: { alignItems: 'center', paddingTop: 35, gap: 14 }, emptyHeading: { fontSize: 17, fontWeight: '500' }, emptyText: { textAlign: 'center', fontSize: 13, lineHeight: 20 },
  quickRow: { flexDirection: 'row', gap: 8, flexWrap: 'wrap', paddingVertical: 10 }, quick: { borderWidth: 1, borderRadius: 22, paddingHorizontal: 13, minHeight: 42, justifyContent: 'center' }, quickText: { fontSize: 12 },
  composer: { borderRadius: 27, flexDirection: 'row', alignItems: 'flex-end', padding: 6, paddingLeft: 16, gap: 8 }, input: { flex: 1, fontSize: 16, minHeight: 44, maxHeight: 115, paddingVertical: 11 }, send: { width: 44, height: 44, borderRadius: 24, alignItems: 'center', justifyContent: 'center' }, footer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, paddingTop: 11, paddingBottom: 4 }, footerText: { fontSize: 10 }, characterCount: { textAlign: 'right', fontSize: 10, marginTop: 5 },
});

