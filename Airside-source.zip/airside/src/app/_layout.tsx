import React from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { ChatProvider } from '../state/ChatProvider';
import { usePalette } from '../ui/theme';
export default function Layout() {
  const c = usePalette();
  return <ChatProvider><StatusBar style="auto" /><Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: c.bg } }}><Stack.Screen name="index" /><Stack.Screen name="chat" /><Stack.Screen name="settings" options={{ presentation: 'modal' }} /></Stack></ChatProvider>;
}
