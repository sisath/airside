import React, { useEffect, useState } from 'react';
import { ActivityIndicator, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import * as Clipboard from 'expo-clipboard';
import { createCode, formatCode, validCode } from '../core/wire';
import { loadSettings } from '../services/settings';
import { secureRandom } from '../services/random';
import type { RoomMode } from '../core/room-wire';
import { useChat } from '../state/ChatProvider';
import { Brand, Button, Icon, Notice } from '../ui/components';
import { usePalette } from '../ui/theme';

export default function Welcome() {
  const c = usePalette(), insets = useSafeAreaInsets(), chat = useChat();
  const [name, setName] = useState('');
  const [mode, setMode] = useState<RoomMode | null>(null);
  const [createdCode, setCreatedCode] = useState('');
  const [joinCode, setJoinCode] = useState('');
  const code = mode === 'create' ? createdCode : joinCode;
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [localError, setLocalError] = useState<string | null>(null);
  useEffect(() => {
    let mounted = true;
    loadSettings().then(settings => {
      if (!mounted) return;
      setName(settings.name);
      setCreatedCode(settings.mode === 'create' && settings.code ? settings.code : createCode(secureRandom));
      setJoinCode(settings.mode === 'join' ? settings.code : '');
    }).catch(() => { if (mounted) { setLocalError('Saved settings could not be loaded. You can pair again.'); setCreatedCode(createCode(secureRandom)); } })
      .finally(() => { if (mounted) setLoaded(true); });
    return () => { mounted = false; };
  }, []);
  const connect = async () => {
    setBusy(true); setLocalError(null);
    try { if (await chat.start(name, code, mode!)) router.push('/chat'); }
    finally { setBusy(false); }
  };
  const demo = async () => { setBusy(true); try { await chat.startDemo(); router.push('/chat'); } catch { setLocalError('The demo could not start. Please try again.'); } finally { setBusy(false); } };
  return <KeyboardAvoidingView style={{ flex: 1, backgroundColor: c.bg }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
    <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={[s.page, { paddingTop: insets.top + 10, paddingBottom: insets.bottom + 20 }]}>
      <Brand trailing={<View style={[s.offline, { backgroundColor: c.surface }]}><Icon name="airplane-outline" size={14} color={c.muted} /><Text style={[s.offlineText, { color: c.muted }]}>Offline</Text></View>} />
      <View style={s.hero}><View style={[s.orbitOuter, { borderColor: c.line }]}><View style={[s.orbitInner, { backgroundColor: c.surface, borderColor: c.line }]}><Icon name="chatbubbles-outline" size={46} color={c.green} /><View style={[s.heart, { backgroundColor: c.bg }]}><Icon name="bluetooth" size={20} color={c.green} /></View></View></View><Text style={[s.heading, { color: c.ink }]}>Offline messaging</Text></View>
      <View style={s.form}>
        {!mode ? <>
          <Button onPress={() => { setMode('create'); setCopied(false); }}>Create a chat</Button>
          <Button secondary onPress={() => { setMode('join'); setCopied(false); }}>Join a chat</Button>
        </> : <>
          <View style={s.labelRow}><Text style={[s.sectionTitle, { color: c.ink }]}>{mode === 'create' ? 'Create a chat' : 'Join a chat'}</Text><Pressable accessibilityRole="button" onPress={() => { setMode(null); setLocalError(null); }} style={s.textTap}><Text style={[s.textLink, { color: c.green }]}>Back</Text></Pressable></View>
          <Text style={[s.label, { color: c.ink }]}>Your name</Text>
          <TextInput accessibilityLabel="Your name" value={name} onChangeText={setName} maxLength={32} placeholder="Your name" placeholderTextColor={c.muted} autoComplete="given-name" style={[s.input, { backgroundColor: c.surface, color: c.ink }]} />
          {mode === 'create' ? <>
            <View style={s.labelRow}><Text style={[s.label, { color: c.ink }]}>Chat code</Text><Pressable accessibilityRole="button" accessibilityLabel="Generate a new chat code" onPress={() => { setCreatedCode(createCode(secureRandom)); setCopied(false); }} style={s.textTap}><Text style={[s.textLink, { color: c.green }]}>New code</Text></Pressable></View>
            <Pressable accessibilityRole="button" accessibilityLabel="Copy chat code" onPress={async () => { try { await Clipboard.setStringAsync(formatCode(code)); setCopied(true); } catch { setLocalError('Could not copy the code.'); } }} style={[s.codeBox, { backgroundColor: c.surface }]}><Text selectable style={[s.code, { color: c.ink }]}>{formatCode(code) || 'Creating code…'}</Text><Icon name={copied ? 'checkmark' : 'copy-outline'} size={19} color={c.green} /></Pressable>
            {copied && <Text style={[s.help, { color: c.muted }]}>Copied</Text>}
          </> : <>
            <Text style={[s.label, { color: c.ink }]}>Chat code</Text>
            <TextInput accessibilityLabel="Chat code" value={joinCode} onChangeText={setJoinCode} maxLength={32} placeholder="XXXXX-XXXXX-XXXXX-XXXXX" placeholderTextColor={c.muted} autoCapitalize="characters" autoCorrect={false} autoComplete="off" style={[s.input, s.codeInput, { backgroundColor: c.surface, color: c.ink }]} />
          </>}
          <Text style={[s.help, { color: c.muted }]}>Up to 8 people. The room owner must stay nearby with CloseBy open.</Text>
          {Platform.OS === 'web' ? <Notice>Install CloseBy to connect over Bluetooth. The browser is a preview.</Notice> : <Button disabled={!loaded || busy || !name.trim() || !validCode(code)} onPress={connect}>{busy ? 'Starting Bluetooth…' : mode === 'create' ? 'Create chat' : 'Join chat'}</Button>}
        </>}
        {(localError || chat.error) && <Notice warning>{localError || chat.error}</Notice>}
        {chat.running && <Button secondary onPress={() => router.push('/chat')}>Return to your chat</Button>}
        {busy && <ActivityIndicator color={c.green} accessibilityLabel="Starting chat" />}
        <Pressable disabled={busy} accessibilityRole="button" onPress={demo} style={s.demoButton}><Text style={[s.textLink, { color: c.green }]}>Try the demo <Text style={{ fontWeight: '400' }}>↗</Text></Text></Pressable>
      </View>
      <View style={s.footer}><View style={s.footerRow}><Icon name="lock-closed-outline" size={13} color={c.muted} /><Text style={[s.footerText, { color: c.muted }]}>Private messages. Direct over Bluetooth.</Text></View><Pressable accessibilityRole="button" onPress={() => router.push('/settings')} style={s.textTap}><Text style={[s.help, { color: c.muted }]}>How it works & privacy</Text></Pressable></View>
    </ScrollView>
  </KeyboardAvoidingView>;
}
const s = StyleSheet.create({
  page: { flexGrow: 1, paddingHorizontal: 25, maxWidth: 480, width: '100%', alignSelf: 'center' },
  offline: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 10, paddingVertical: 8, borderRadius: 20 }, offlineText: { fontSize: 10 },
  hero: { alignItems: 'center', paddingTop: 30, paddingBottom: 30 }, orbitOuter: { width: 135, height: 135, borderRadius: 70, borderWidth: 1, alignItems: 'center', justifyContent: 'center', marginBottom: 28 }, orbitInner: { width: 108, height: 108, borderRadius: 60, borderWidth: 1, alignItems: 'center', justifyContent: 'center' }, heart: { position: 'absolute', right: -3, bottom: 1, padding: 8, borderRadius: 24 },
  heading: { fontSize: 34, fontWeight: '500', lineHeight: 40, letterSpacing: -1.5, textAlign: 'center' }, subtitle: { fontSize: 14, marginTop: 13 },
  sectionTitle: { fontSize: 20, fontWeight: '600' },
  form: { gap: 12 }, label: { fontSize: 13, fontWeight: '600' }, labelRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  input: { borderRadius: 15, minHeight: 54, paddingHorizontal: 16, fontSize: 16 }, codeInput: { fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace', fontSize: 14 },
  codeBox: { flexDirection: 'row', gap: 8, alignItems: 'center', borderRadius: 15, padding: 16 }, code: { flex: 1, fontSize: 13, letterSpacing: .7, fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace' },
  help: { fontSize: 12, lineHeight: 18 }, textTap: { minHeight: 38, justifyContent: 'center' }, textLink: { fontSize: 13, fontWeight: '600' }, demoButton: { minHeight: 44, alignItems: 'center', justifyContent: 'center' }, footer: { alignItems: 'center', marginTop: 22, paddingBottom: 6 }, footerRow: { flexDirection: 'row', alignItems: 'center', gap: 6 }, footerText: { fontSize: 11 },
});
