import React, { useEffect, useState } from 'react';
import { ActivityIndicator, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import * as Clipboard from 'expo-clipboard';
import { createCode, formatCode, validCode } from '../core/wire';
import { loadSettings } from '../services/settings';
import { secureRandom } from '../services/random';
import { isHost, useChat } from '../state/ChatProvider';
import { Brand, Button, Icon, Notice } from '../ui/components';
import { usePalette } from '../ui/theme';

export default function Welcome() {
  const c = usePalette(), insets = useSafeAreaInsets(), chat = useChat();
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [localError, setLocalError] = useState<string | null>(null);
  useEffect(() => {
    let mounted = true;
    loadSettings().then(settings => {
      if (!mounted) return;
      setName(settings.name);
      setCode(settings.code || (isHost ? createCode(secureRandom) : ''));
    }).catch(() => { if (mounted) { setLocalError('Saved settings could not be loaded. You can pair again.'); if (isHost) setCode(createCode(secureRandom)); } })
      .finally(() => { if (mounted) setLoaded(true); });
    return () => { mounted = false; };
  }, []);
  const connect = async () => {
    setBusy(true); setLocalError(null);
    try { if (await chat.start(name, code)) router.push('/chat'); }
    finally { setBusy(false); }
  };
  const demo = async () => { setBusy(true); try { await chat.startDemo(); router.push('/chat'); } catch { setLocalError('The demo could not start. Please try again.'); } finally { setBusy(false); } };
  return <KeyboardAvoidingView style={{ flex: 1, backgroundColor: c.bg }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
    <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={[s.page, { paddingTop: insets.top + 10, paddingBottom: insets.bottom + 20 }]}>
      <Brand trailing={<View style={[s.offline, { backgroundColor: c.surface }]}><Icon name="airplane-outline" size={14} color={c.muted} /><Text style={[s.offlineText, { color: c.muted }]}>Offline, together</Text></View>} />
      <View style={s.hero}><View style={[s.orbitOuter, { borderColor: c.line }]}><View style={[s.orbitInner, { backgroundColor: c.surface, borderColor: c.line }]}><Icon name="chatbubbles-outline" size={46} color={c.green} /><View style={[s.heart, { backgroundColor: c.bg }]}><Icon name="heart" size={20} color={c.green} /></View></View></View><Text style={[s.heading, { color: c.ink }]}>A little closer,{ '\n' }wherever you go.</Text><Text style={[s.subtitle, { color: c.muted }]}>Just you two. No signal needed.</Text></View>
      <View style={s.form}>
        <Text style={[s.label, { color: c.ink }]}>What should we call you?</Text>
        <TextInput accessibilityLabel="Your name" value={name} onChangeText={setName} maxLength={32} placeholder="Your name" placeholderTextColor={c.muted} autoComplete="given-name" style={[s.input, { backgroundColor: c.surface, color: c.ink }]} />
        {Platform.OS === 'web' ? <Notice>This browser shows the design only. Install Airside on both phones for Bluetooth messaging.</Notice> : isHost ? <>
          <View style={s.labelRow}><Text style={[s.label, { color: c.ink }]}>Your private pairing code</Text><Pressable accessibilityRole="button" accessibilityLabel="Generate a new pairing code" onPress={() => { setCode(createCode(secureRandom)); setCopied(false); }} style={s.textTap}><Text style={[s.textLink, { color: c.green }]}>New code</Text></Pressable></View>
          <Pressable accessibilityRole="button" accessibilityLabel="Copy pairing code" onPress={async () => { try { await Clipboard.setStringAsync(formatCode(code)); setCopied(true); } catch { setLocalError('Copy failed. Your partner can type the code instead.'); } }} style={[s.codeBox, { backgroundColor: c.surface }]}><Text selectable style={[s.code, { color: c.ink }]}>{formatCode(code) || 'Creating code…'}</Text><Icon name={copied ? 'checkmark' : 'copy-outline'} size={19} color={c.green} /></Pressable>
          <Text style={[s.help, { color: c.muted }]}>{copied ? 'Copied. Share it privately with her Samsung.' : 'Share this code privately with her Samsung. You only need to pair once.'}</Text>
        </> : <>
          <Text style={[s.label, { color: c.ink }]}>Pairing code from his iPhone</Text>
          <TextInput accessibilityLabel="Pairing code" value={code} onChangeText={setCode} maxLength={32} placeholder="XXXXX-XXXXX-XXXXX-XXXXX" placeholderTextColor={c.muted} autoCapitalize="characters" autoCorrect={false} autoComplete="off" style={[s.input, s.codeInput, { backgroundColor: c.surface, color: c.ink }]} />
          <Text style={[s.help, { color: c.muted }]}>Open Airside on the iPhone and enter its 20-character code here.</Text>
        </>}
        {(localError || chat.error) && <Notice warning>{localError || chat.error}</Notice>}
        {chat.running && <Button secondary onPress={() => router.push('/chat')}>Return to your chat</Button>}
        {Platform.OS !== 'web' && <Button disabled={!loaded || busy || !name.trim() || !validCode(code)} onPress={connect}>{busy ? 'Starting Bluetooth…' : isHost ? 'Open our chat' : 'Find our chat'}</Button>}
        {busy && <ActivityIndicator color={c.green} accessibilityLabel="Starting chat" />}
        <Pressable disabled={busy} accessibilityRole="button" onPress={demo} style={s.demoButton}><Text style={[s.textLink, { color: c.green }]}>Try the demo <Text style={{ fontWeight: '400' }}>↗</Text></Text></Pressable>
      </View>
      <View style={s.footer}><View style={s.footerRow}><Icon name="lock-closed-outline" size={13} color={c.muted} /><Text style={[s.footerText, { color: c.muted }]}>Private messages. Direct over Bluetooth.</Text></View><Pressable accessibilityRole="button" onPress={() => router.push('/settings')} style={s.textTap}><Text style={[s.help, { color: c.muted }]}>How it works & privacy</Text></Pressable></View>
    </ScrollView>
  </KeyboardAvoidingView>;
}
const s = StyleSheet.create({
  page: { flexGrow: 1, paddingHorizontal: 25, maxWidth: 480, width: '100%', alignSelf: 'center' },
  offline: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 10, paddingVertical: 8, borderRadius: 20 }, offlineText: { fontSize: 10 },
  hero: { alignItems: 'center', paddingTop: 30, paddingBottom: 30 }, orbitOuter: { width: 135, height: 135, borderRadius: 70, borderWidth: 1, alignItems: 'center', justifyContent: 'center', marginBottom: 28 }, orbitInner: { width: 108, height: 108, borderRadius: 60, borderWidth: 1, alignItems: 'center', justifyContent: 'center' }, heart: { position: 'absolute', right: -3, bottom: 1, padding: 8, borderRadius: 24 },
  heading: { fontSize: 34, fontWeight: '500', lineHeight: 40, letterSpacing: -1.5, textAlign: 'center' }, subtitle: { fontSize: 14, marginTop: 13 },
  form: { gap: 12 }, label: { fontSize: 13, fontWeight: '600' }, labelRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  input: { borderRadius: 15, minHeight: 54, paddingHorizontal: 16, fontSize: 16 }, codeInput: { fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace', fontSize: 14 },
  codeBox: { flexDirection: 'row', gap: 8, alignItems: 'center', borderRadius: 15, padding: 16 }, code: { flex: 1, fontSize: 13, letterSpacing: .7, fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace' },
  help: { fontSize: 12, lineHeight: 18 }, textTap: { minHeight: 38, justifyContent: 'center' }, textLink: { fontSize: 13, fontWeight: '600' }, demoButton: { minHeight: 44, alignItems: 'center', justifyContent: 'center' }, footer: { alignItems: 'center', marginTop: 22, paddingBottom: 6 }, footerRow: { flexDirection: 'row', alignItems: 'center', gap: 6 }, footerText: { fontSize: 11 },
});
