import React from 'react';
import type { Attachment } from '../core/media';
export default function VideoMessage({ attachment }: { attachment: Attachment }) {
  return React.createElement('video', { controls: true, playsInline: true, src: `data:${attachment.mime};base64,${attachment.base64}`, style: { width: 240, maxWidth: '100%' } });
}
