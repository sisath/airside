import React from 'react';
import { View } from 'react-native';
import type { MediaKind } from '../core/media';
import AttachmentButton from './AttachmentButton';
export default function MediaTools(_props: { disabled: boolean; suspended: boolean; onSend(bytes: Uint8Array, kind: MediaKind, durationMs?: number): Promise<void>; onError(message: string): void }) {
  return <View style={{ flexDirection: 'row', gap: 8 }}><AttachmentButton label="Photo" icon="image-outline" disabled onPress={() => {}} /><AttachmentButton label="Record Video" icon="videocam-outline" disabled onPress={() => {}} /><AttachmentButton label="Record Voice" icon="mic-outline" disabled onPress={() => {}} /></View>;
}
