import React from 'react';
import { Text } from 'react-native';
import type { MediaKind } from '../core/media';
import { usePalette } from './theme';
export default function MediaTools(_props: { disabled: boolean; suspended: boolean; onSend(bytes: Uint8Array, kind: MediaKind, durationMs?: number): Promise<void>; onError(message: string): void }) {
  const c = usePalette(); return <Text style={{ color: c.muted, fontSize: 11, paddingVertical: 10 }}>Photos, video and voice recording are available in the installed app.</Text>;
}
