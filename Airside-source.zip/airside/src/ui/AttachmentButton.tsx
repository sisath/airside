import React from 'react';
import { Pressable } from 'react-native';
import { Icon } from './components';
import { usePalette } from './theme';
export default function AttachmentButton({ label, icon, onPress, disabled, heart }: { label: string; icon: React.ComponentProps<typeof Icon>['name']; onPress(): void; disabled?: boolean; heart?: boolean }) {
  const c = usePalette();
  return <Pressable accessibilityRole="button" accessibilityLabel={label} disabled={disabled} onPress={onPress} style={({ pressed }) => ({ width: 48, height: 48, borderRadius: 16, borderWidth: 1, borderColor: heart ? '#E9B8C5' : c.line, backgroundColor: heart ? '#FBE9EF' : c.surface, alignItems: 'center', justifyContent: 'center', opacity: disabled ? .35 : pressed ? .6 : 1, transform: [{ scale: pressed ? .94 : 1 }] })}><Icon name={icon} size={25} color={heart ? '#BB3B62' : c.green} /></Pressable>;
}
