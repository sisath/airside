import React, { useEffect, useRef, useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { AudioModule, AudioQuality, IOSOutputFormat, setAudioModeAsync, useAudioRecorder, useAudioRecorderState } from 'expo-audio';
import type { MediaKind } from '../core/media';
import { pickPhoto, readVoice, discardVoice } from '../services/media';
import { usePalette } from './theme';
import { Icon } from './components';
type Props = { disabled: boolean; suspended: boolean; onSend(bytes: Uint8Array, kind: MediaKind, durationMs?: number): Promise<void>; onError(message: string): void };
export default function MediaTools({ disabled, suspended, onSend, onError }: Props) {
  const c = usePalette(), [recording, setRecording] = useState(false), [busy, setBusy] = useState(false);
  const live = useRef(false);
  const recorder = useAudioRecorder({ extension: '.m4a', fileName: 'closeby-voice', directory: 'cache', sampleRate: 16000, numberOfChannels: 1, bitRate: 24000,
    android: { outputFormat: 'mpeg4', audioEncoder: 'aac', maxFileSize: 60000 }, ios: { outputFormat: IOSOutputFormat.MPEG4AAC, audioQuality: AudioQuality.LOW }, web: { mimeType: 'audio/mp4', bitsPerSecond: 24000 } });
  const state = useAudioRecorderState(recorder, 250);
  const cancel = async () => { live.current = false; setRecording(false); try { await recorder.stop(); } catch { /* Already stopped at the duration limit. */ } discardVoice(recorder.uri); await setAudioModeAsync({ allowsRecording: false, playsInSilentMode: true, shouldRouteThroughEarpiece: false, shouldPlayInBackground: false, interruptionMode: 'doNotMix' }); };
  useEffect(() => { if (suspended && live.current) void cancel(); }, [suspended]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => () => { if (live.current) void recorder.stop().then(() => discardVoice(recorder.uri)).catch(() => {}); }, [recorder]);
  const start = async () => {
    if (busy || disabled) return; setBusy(true);
    try {
      const permission = await AudioModule.requestRecordingPermissionsAsync(); if (!permission.granted) throw Error('Microphone access is needed to record a voice message.');
      await setAudioModeAsync({ allowsRecording: true, playsInSilentMode: true, shouldPlayInBackground: false });
      await recorder.prepareToRecordAsync(); recorder.record({ forDuration: 15 }); live.current = true; setRecording(true);
    } catch (e) { onError(e instanceof Error ? e.message : 'Recording could not start.'); }
    finally { setBusy(false); }
  };
  const sendVoice = async () => {
    if (busy) return; setBusy(true); live.current = false;
    try {
      const duration = Math.min(15000, Math.max(1, recorder.getStatus().durationMillis));
      try { await recorder.stop(); } catch { /* Automatic limit may already have stopped it. */ }
      setRecording(false); await setAudioModeAsync({ allowsRecording: false, playsInSilentMode: true, shouldRouteThroughEarpiece: false, shouldPlayInBackground: false, interruptionMode: 'doNotMix' });
      if (!recorder.uri) throw Error('No recording was produced.');
      await onSend(await readVoice(recorder.uri), 'voice', duration);
    } catch (e) { discardVoice(recorder.uri); onError(e instanceof Error ? e.message : 'Voice message could not be sent.'); }
    finally { setBusy(false); }
  };
  const photo = async () => {
    if (busy || disabled) return; setBusy(true);
    try { const bytes = await pickPhoto(); if (bytes) await onSend(bytes, 'photo'); }
    catch (e) { onError(e instanceof Error ? e.message : 'Photo could not be sent.'); }
    finally { setBusy(false); }
  };
  return <View style={{ flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap' }}>{recording ? <>
    <Text accessibilityLiveRegion="polite" style={{ color: c.danger, fontSize: 12 }}>{Math.min(15, Math.floor(state.durationMillis / 1000))} / 15s</Text>
    <ToolButton label="Send voice" icon="send-outline" onPress={() => { void sendVoice(); }} disabled={busy} /><ToolButton label="Discard" icon="close" onPress={() => { void cancel(); }} disabled={busy} />
  </> : <><ToolButton label="Photo" icon="image-outline" onPress={() => { void photo(); }} disabled={busy || disabled} /><ToolButton label="Record voice" icon="mic-outline" onPress={() => { void start(); }} disabled={busy || disabled} /></>}</View>;
}

function ToolButton({ label, icon, onPress, disabled }: { label: string; icon: React.ComponentProps<typeof Icon>['name']; onPress(): void; disabled: boolean }) {
  const c = usePalette(); return <Pressable accessibilityRole="button" accessibilityLabel={label} disabled={disabled} onPress={onPress} style={{ minHeight: 44, paddingHorizontal: 10, flexDirection: 'row', gap: 6, alignItems: 'center', opacity: disabled ? 0.4 : 1 }}><Icon name={icon} size={20} /><Text style={{ color: c.ink, fontSize: 12 }}>{label}</Text></Pressable>;
}
