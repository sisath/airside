import { useColorScheme } from 'react-native';
export const light = { bg: '#FFFDF8', surface: '#F0F2E9', ink: '#263B34', muted: '#6F7D73', line: '#E1E6DB', green: '#315C48', greenText: '#FFFFFF', sent: '#DCEBD6', avatar: '#E6DFCC', warning: '#795B22', warningBg: '#F9EFDA', danger: '#A13E36' };
export const dark = { bg: '#18231E', surface: '#26352C', ink: '#EFF4EC', muted: '#AFBDB0', line: '#3B4C40', green: '#B1CDA8', greenText: '#18291D', sent: '#36533F', avatar: '#514936', warning: '#E4C88E', warningBg: '#393322', danger: '#F1A59C' };
export type Palette = typeof light;
export function usePalette(): Palette { return useColorScheme() === 'dark' ? dark : light; }
