import React from 'react';
import { Pressable, StyleSheet, Text, View, type ViewStyle } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { usePalette } from './theme';
export function Icon({ name, size = 20, color }: { name: React.ComponentProps<typeof Ionicons>['name']; size?: number; color?: string }) {
  const c = usePalette(); return <Ionicons name={name} size={size} color={color ?? c.ink} />;
}
export function Brand({ trailing }: { trailing?: React.ReactNode }) {
  const c = usePalette();
  return <View style={s.brandRow}><View style={s.brand}><Icon name="chatbubbles-outline" size={26} /><Text style={[s.brandText, { color: c.ink }]}>CloseBy</Text></View>{trailing}</View>;
}
export function IconButton({ name, label, onPress, disabled }: { name: React.ComponentProps<typeof Ionicons>['name']; label: string; onPress(): void; disabled?: boolean }) {
  const c = usePalette();
  return <Pressable accessibilityRole="button" accessibilityLabel={label} disabled={disabled} onPress={onPress} style={({ pressed }) => [s.iconButton, { backgroundColor: c.surface, opacity: disabled ? .4 : pressed ? .7 : 1 }]}><Icon name={name} /></Pressable>;
}
export function Button({ children, onPress, secondary = false, disabled = false, style }: { children: React.ReactNode; onPress(): void; secondary?: boolean; disabled?: boolean; style?: ViewStyle }) {
  const c = usePalette();
  return <Pressable accessibilityRole="button" disabled={disabled} onPress={onPress} style={({ pressed }) => [s.button, { backgroundColor: secondary ? c.surface : c.green, opacity: disabled ? .45 : pressed ? .8 : 1 }, style]}><Text style={[s.buttonText, { color: secondary ? c.ink : c.greenText }]}>{children}</Text></Pressable>;
}
export function Notice({ children, warning = false }: { children: React.ReactNode; warning?: boolean }) {
  const c = usePalette();
  return <View accessibilityLiveRegion="polite" style={[s.notice, { backgroundColor: warning ? c.warningBg : c.surface }]}><Icon name={warning ? 'alert-circle-outline' : 'information-circle-outline'} size={17} color={warning ? c.warning : c.muted} /><Text style={[s.noticeText, { color: warning ? c.warning : c.muted }]}>{children}</Text></View>;
}
const s = StyleSheet.create({
  brandRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 12 },
  brand: { flexDirection: 'row', alignItems: 'center', gap: 9 }, brandText: { fontSize: 28, fontWeight: '600', letterSpacing: -1.2 },
  iconButton: { minWidth: 44, minHeight: 44, borderRadius: 24, alignItems: 'center', justifyContent: 'center' },
  button: { minHeight: 54, borderRadius: 18, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 18, paddingVertical: 14 },
  buttonText: { fontSize: 16, fontWeight: '600' },
  notice: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, padding: 13, borderRadius: 13 }, noticeText: { flex: 1, fontSize: 12, lineHeight: 18 },
});
