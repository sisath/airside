import React from 'react';
import { KeyboardAvoidingView, Modal, Platform, Pressable, ScrollView, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { IconButton } from './components';
import { usePalette } from './theme';
export default function Sheet({ visible, title, onClose, children }: { visible: boolean; title: string; onClose(): void; children: React.ReactNode }) {
  const c = usePalette(), insets = useSafeAreaInsets();
  return <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}><KeyboardAvoidingView style={{ flex: 1, justifyContent: 'flex-end' }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}><Pressable accessible={false} onPress={onClose} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: '#00000066' }} /><View accessibilityViewIsModal style={{ backgroundColor: c.bg, padding: 22, paddingBottom: Math.max(insets.bottom, 22), borderTopLeftRadius: 28, borderTopRightRadius: 28, maxHeight: '80%', width: '100%', maxWidth: 560, alignSelf: 'center' }}><View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 }}><Text accessibilityRole="header" style={{ color: c.ink, fontSize: 23, fontWeight: '600' }}>{title}</Text><IconButton name="close" label={'Close ' + title} onPress={onClose} /></View><ScrollView keyboardShouldPersistTaps="handled">{children}</ScrollView></View></KeyboardAvoidingView></Modal>;
}
