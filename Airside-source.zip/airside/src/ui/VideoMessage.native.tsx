import React, { useEffect, useState } from 'react';
import { AppState, Pressable, Text, View } from 'react-native';
import { useVideoPlayer, VideoView } from 'expo-video';
import { setAudioModeAsync } from 'expo-audio';
import type { Attachment } from '../core/media';
import { attachmentURI } from '../services/media';
import { Icon } from './components';
import { usePalette } from './theme';
export default function VideoMessage({ attachment }: { attachment: Attachment }) {
  const [open, setOpen] = useState(false), c = usePalette();
  return open ? <View><Clip attachment={attachment} /><Pressable accessibilityRole="button" onPress={() => setOpen(false)} style={{ padding: 10 }}><Text style={{ color: c.green }}>Close video</Text></Pressable></View> : <Pressable accessibilityRole="button" accessibilityLabel="Play video message" onPress={() => setOpen(true)} style={{ minHeight: 70, flexDirection: 'row', alignItems: 'center', gap: 10 }}><Icon name="videocam-outline" /><Text style={{ color: c.ink }}>Video · {Math.ceil((attachment.durationMs ?? 0) / 1000)}s · Tap to play</Text></Pressable>;
}
function Clip({ attachment }: { attachment: Attachment }) {
  const player = useVideoPlayer({ uri: attachmentURI(attachment) });
  useEffect(() => {
    let active = true;
    void setAudioModeAsync({ allowsRecording: false, playsInSilentMode: true, shouldRouteThroughEarpiece: false, shouldPlayInBackground: false }).then(() => { if (active) player.play(); }).catch(() => {});
    const listener = AppState.addEventListener('change', state => { if (state !== 'active') player.pause(); });
    return () => { active = false; listener.remove(); };
  }, [player]);
  return <VideoView player={player} nativeControls contentFit="contain" style={{ width: 240, height: 180, maxWidth: '100%' }} />;
}
