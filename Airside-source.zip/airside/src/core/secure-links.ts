import { x25519 } from '@noble/curves/ed25519.js';
import { xchacha20poly1305 } from '@noble/ciphers/chacha.js';
import { sha256 } from '@noble/hashes/sha2.js';
import { hkdf } from '@noble/hashes/hkdf.js';
import { bytesToHex, hexToBytes, concatBytes, utf8ToBytes } from '@noble/hashes/utils.js';
import { fromByteArray, toByteArray } from 'base64-js';
import { MAX_PACKET, normaliseCode, type RandomBytes } from './wire';
import type { RoomMode } from './room-wire';
import { ROOM_LIFETIME } from './room-code';

export type JoinRequest = { peer: string; name: string; verification: string };
type Link = { secret: Uint8Array; publicKey: string; remote: string; key?: Uint8Array; name: string; verification: string; approved: boolean; created: number };
type Options = { mode: RoomMode; code: string; name: string; expiresAt?: number; random: RandomBytes; now?: () => number;
  send(payload: string, peer: string): Promise<void>; packet(payload: string, peer: string): void;
  linked(peer: string, linked: boolean): void; changed(pending: JoinRequest[], verification: string): void; expiry(value: number): void };

// The short code is discovery, not an encryption password. Fresh X25519 keys
// protect each link; users compare the short authentication string before approval.
export class SecureLinks {
  private links = new Map<string, Link>();
  private rejected = new Set<string>();
  private chain = Promise.resolve();
  private lastKnock = 0;
  private disposed = false;
  private epoch = 0;
  private now: () => number;
  constructor(private o: Options) { this.now = o.now ?? Date.now; }
  private fresh(): Link { const secret = this.o.random(32); return { secret, publicKey: bytesToHex(x25519.getPublicKey(secret)), remote: '', name: '', verification: '', approved: false, created: this.now() }; }
  private raw(peer: string, value: unknown) {
    const payload = fromByteArray(utf8ToBytes(JSON.stringify(value))), epoch = this.epoch;
    this.chain = this.chain.catch(() => {}).then(async () => { if (!this.disposed && epoch === this.epoch) await this.o.send(payload, peer); });
    // Control-frame failures recover through periodic knock retries.
    void this.chain.catch(() => {});
  }
  private derive(l: Link, remote: string) {
    const guest = this.o.mode === 'join' ? l.publicKey : remote, host = this.o.mode === 'create' ? l.publicKey : remote;
    const transcript = utf8ToBytes(`closeby-links-v3:${normaliseCode(this.o.code)}:${guest}:${host}`);
    l.key = hkdf(sha256, x25519.getSharedSecret(l.secret, hexToBytes(remote)), sha256(transcript), utf8ToBytes('link encryption'), 32);
    l.remote = remote;
    const digest = sha256(concatBytes(l.key, transcript));
    const number = ((digest[0] * 16777216 + digest[1] * 65536 + digest[2] * 256 + digest[3]) % 1000000).toString().padStart(6, '0');
    l.verification = `${number.slice(0, 3)} ${number.slice(3)}`;
  }
  private publish() { this.o.changed(Array.from(this.links, ([peer, l]) => ({ peer, ...l })).filter(l => !l.approved && !!l.remote).map(l => ({ peer: l.peer, name: l.name, verification: l.verification })), this.links.get('host')?.verification ?? ''); }
  link(peer: string, connected: boolean) {
    const old = this.links.get(peer); old?.secret.fill(0); old?.key?.fill(0); this.links.delete(peer);
    if (!connected) this.o.linked(peer, false);
    else if (this.o.mode === 'join') { this.links.set('host', this.fresh()); this.knock(); }
    this.publish();
  }
  private knock() { const l = this.links.get('host'); if (!l) return; this.lastKnock = this.now(); this.raw('host', { v: 3, t: 'knock', key: l.publicKey, name: this.o.name }); }
  private box(l: Link, body: unknown): string {
    if (!l.key) throw Error('Connection has not been verified.');
    const nonce = this.o.random(24), plain = utf8ToBytes(JSON.stringify(body));
    const bytes = concatBytes(nonce, xchacha20poly1305(l.key, nonce, utf8ToBytes('closeby-links-v3')).encrypt(plain));
    if (bytes.length > MAX_PACKET - 200) throw Error('Secure frame is too large.');
    return fromByteArray(bytes);
  }
  private boxed(peer: string, l: Link, body: unknown) { this.raw(peer, { v: 3, t: 'sealed', data: this.box(l, body) }); }
  receive(payload: string, peer: string) {
    if (this.disposed || payload.length > Math.ceil(MAX_PACKET / 3) * 4) return;
    try {
      const p = JSON.parse(new TextDecoder().decode(toByteArray(payload)));
      if (!p || p.v !== 3) return;
      const keyOK = (v: unknown): v is string => typeof v === 'string' && /^[a-f0-9]{64}$/.test(v);
      if (p.t === 'knock' && this.o.mode === 'create') {
        if (!keyOK(p.key) || this.rejected.has(p.key) || typeof p.name !== 'string' || !p.name.trim() || p.name.length > 32 || (this.o.expiresAt ?? 0) <= this.now()) return;
        let l = this.links.get(peer);
        if (l && l.remote !== p.key) return; // Reconnect must produce a new physical link event.
        if (!l) { if (this.links.size >= 7) return; l = this.fresh(); l.name = p.name; this.derive(l, p.key); this.links.set(peer, l); }
        this.raw(peer, { v: 3, t: 'offer', key: l.publicKey, client: l.remote });
        if (l.approved) this.boxed(peer, l, { t: 'approved', expiresAt: this.o.expiresAt });
        this.publish(); return;
      }
      const l = this.links.get(peer);
      if (!l) return;
      if (p.t === 'offer' && this.o.mode === 'join' && p.client === l.publicKey && keyOK(p.key)) {
        if (l.remote && l.remote !== p.key) return;
        this.derive(l, p.key); this.publish(); return;
      }
      if (p.t !== 'sealed' || !l.key || typeof p.data !== 'string' || p.data.length > 11000) return;
      const data = toByteArray(p.data); if (data.length < 41 || data.length > MAX_PACKET) return;
      const body = JSON.parse(new TextDecoder().decode(xchacha20poly1305(l.key, data.slice(0, 24), utf8ToBytes('closeby-links-v3')).decrypt(data.slice(24))));
      if (body.t === 'approved' && this.o.mode === 'join') {
        if (!Number.isSafeInteger(body.expiresAt) || body.expiresAt <= this.now() || body.expiresAt > this.now() + ROOM_LIFETIME + 300000) return;
        this.o.expiry(Math.min(body.expiresAt, this.now() + ROOM_LIFETIME));
        if (!l.approved) { l.approved = true; this.o.linked('host', true); this.publish(); }
      } else if (body.t === 'data' && l.approved && typeof body.payload === 'string' && body.payload.length <= 11000) this.o.packet(body.payload, peer);
    } catch { /* Invalid keys, frames and unauthenticated ciphertext cannot change room state. */ }
  }
  approve(peer: string) {
    const l = this.links.get(peer); if (!l?.key || l.approved || this.o.mode !== 'create' || (this.o.expiresAt ?? 0) <= this.now()) return;
    l.approved = true; this.boxed(peer, l, { t: 'approved', expiresAt: this.o.expiresAt }); this.o.linked(peer, true); this.publish();
  }
  reject(peer: string) { const l = this.links.get(peer); if (l) { this.rejected.add(l.remote); l.secret.fill(0); l.key?.fill(0); this.links.delete(peer); } this.publish(); }
  send(payload: string, peer: string): Promise<void> {
    const l = this.links.get(peer); if (!l?.approved) return Promise.reject(Error('Connection is awaiting owner approval.'));
    const epoch = this.epoch, wire = fromByteArray(utf8ToBytes(JSON.stringify({ v: 3, t: 'sealed', data: this.box(l, { t: 'data', payload }) })));
    const result = this.chain.catch(() => {}).then(async () => { if (this.disposed || epoch !== this.epoch) throw Error('Room stopped'); await this.o.send(wire, peer); });
    this.chain = result.catch(() => {}); return result;
  }
  tick() {
    if (this.disposed) return;
    if (this.o.mode === 'join' && !this.links.get('host')?.approved && this.now() - this.lastKnock > 3000) this.knock();
    if (this.o.mode === 'create') for (const [peer, l] of this.links) if (!l.approved && this.now() - l.created > 60000) this.reject(peer);
  }
  dispose() { this.disposed = true; this.epoch++; for (const l of this.links.values()) { l.secret.fill(0); l.key?.fill(0); } this.links.clear(); }
}
