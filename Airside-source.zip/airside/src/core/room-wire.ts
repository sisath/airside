import { xchacha20poly1305 } from '@noble/ciphers/chacha.js';
import { sha256 } from '@noble/hashes/sha2.js';
import { bytesToHex, concatBytes, utf8ToBytes } from '@noble/hashes/utils.js';
import { fromByteArray, toByteArray } from 'base64-js';
import { validRoomCode } from './room-code';
import { validMediaChunk, type MediaChunk } from './media';
import { MAX_PACKET, MAX_TEXT, normaliseCode, validCode, type RandomBytes } from './wire';

export const MAX_MEMBERS = 8;
export type RoomMode = 'create' | 'join';
export type Member = { id: string; name: string; host: boolean };
type Base = { v: 2; session: string };
export type RoomPacket = Base & (
  | { t: 'hello'; name: string; identity: string }
  | { t: 'welcome'; to: string; name: string; challenge: string; expiresAt: number }
  | { t: 'ready'; to: string; challenge: string }
  | { t: 'ping' | 'pong'; to: string }
  | { t: 'roster'; to: string; members: Member[] }
  | { t: 'submit'; to: string; id: string; text: string; heart?: true; media?: MediaChunk }
  | { t: 'message'; to: string; id: string; author: string; name: string; text: string; at: number; heart?: true; media?: MediaChunk }
  | { t: 'typing'; to: string; active: boolean }
  | { t: 'activity'; to: string; member: string; name: string; active: boolean }
  | { t: 'ack' | 'receipt'; to: string; id: string }
  | { t: 'error'; to: string; text: string }
);
const idOK = (v: unknown): v is string => typeof v === 'string' && /^[a-f0-9]{32}$/.test(v);
const nameOK = (v: unknown): v is string => typeof v === 'string' && !!v.trim() && v.length <= 32;
export function parseRoomPacket(value: unknown): RoomPacket {
  if (!value || typeof value !== 'object') throw Error('Invalid room packet');
  const p = value as Record<string, unknown>;
  if (p.v !== 2 || !idOK(p.session)) throw Error('Unsupported room packet');
  if (p.t !== 'hello' && !idOK(p.to)) throw Error('Invalid recipient');
  switch (p.t) {
    case 'hello': case 'welcome': if (p.t === 'hello' && !idOK(p.identity)) throw Error('Invalid identity'); if (!nameOK(p.name)) throw Error('Invalid name'); if (p.t === 'welcome' && (!idOK(p.challenge) || !Number.isSafeInteger(p.expiresAt))) throw Error('Invalid challenge'); break;
    case 'ready': if (!idOK(p.challenge)) throw Error('Invalid challenge'); break;
    case 'ping': case 'pong': break;
    case 'roster':
      if (!Array.isArray(p.members) || p.members.length < 1 || p.members.length > MAX_MEMBERS ||
        p.members.some(m => !m || !idOK(m.id) || !nameOK(m.name) || typeof m.host !== 'boolean') ||
        new Set(p.members.map(m => m.id)).size !== p.members.length || p.members.filter(m => m.host).length !== 1) throw Error('Invalid members');
      break;
    case 'message':
      if (!idOK(p.author) || !nameOK(p.name) || !Number.isSafeInteger(p.at) || (p.at as number) < 0) throw Error('Invalid message author');
      // fall through: messages and submissions have the same text limits.
    case 'submit':
      if ((p.heart !== undefined && p.heart !== true) || (p.heart && p.media) || typeof p.text !== 'string' || (!p.text.trim() && !p.media) || p.text.length > MAX_TEXT || (p.media !== undefined && !validMediaChunk(p.media))) throw Error('Invalid message');
      // fall through
    case 'ack': case 'receipt': if (!idOK(p.id)) throw Error('Invalid message ID'); break;
    case 'typing': if (typeof p.active !== 'boolean') throw Error('Invalid typing state'); break;
    case 'activity': if (!idOK(p.member) || !nameOK(p.name) || typeof p.active !== 'boolean') throw Error('Invalid typing state'); break;
    case 'error': if (typeof p.text !== 'string' || p.text.length > 200) throw Error('Invalid error'); break;
    default: throw Error('Unknown room packet');
  }
  return p as unknown as RoomPacket;
}
export function roomServiceUUID(code: string): string {
  const h = bytesToHex(sha256(utf8ToBytes(`closeby-room-discovery-v3:${normaliseCode(code)}`))).slice(0, 32);
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}
export class RoomCodec {
  private key: Uint8Array;
  constructor(code: string, private random: RandomBytes) {
    if (!validRoomCode(code) && !validCode(code)) throw Error('Enter the six-character chat code.');
    this.key = sha256(utf8ToBytes(`closeby-room-encryption-v2:${normaliseCode(code)}`));
  }
  dispose() { this.key.fill(0); }
  encode(p: RoomPacket): string {
    parseRoomPacket(p);
    const nonce = this.random(24);
    const data = concatBytes(nonce, xchacha20poly1305(this.key, nonce, utf8ToBytes('closeby-room-v2')).encrypt(utf8ToBytes(JSON.stringify(p))));
    if (data.length > MAX_PACKET) throw Error('Packet too large');
    return fromByteArray(data);
  }
  decode(text: string): RoomPacket {
    if (text.length > Math.ceil(MAX_PACKET / 3) * 4) throw Error('Packet too large');
    const data = toByteArray(text);
    if (data.length < 41 || data.length > MAX_PACKET) throw Error('Invalid packet');
    const plain = xchacha20poly1305(this.key, data.slice(0, 24), utf8ToBytes('closeby-room-v2')).decrypt(data.slice(24));
    return parseRoomPacket(JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(plain)));
  }
}
