import { sha256 } from '@noble/hashes/sha2.js';
import { bytesToHex } from '@noble/hashes/utils.js';
import { fromByteArray, toByteArray } from 'base64-js';
import { randomId, type RandomBytes } from './wire';

export const MEDIA_CHUNK_CHARS = 1536;
export const MAX_MEDIA_BYTES = 64 * 1024;
export const MAX_ROOM_MEDIA_BYTES = 4 * 1024 * 1024;
export type MediaKind = 'photo' | 'voice';
export type MediaChunk = { id: string; kind: MediaKind; mime: 'image/jpeg' | 'audio/mp4'; size: number; hash: string; index: number; total: number; data: string; durationMs?: number };
export type Attachment = { id: string; kind: MediaKind; mime: 'image/jpeg' | 'audio/mp4'; base64: string; size: number; durationMs?: number };
export function validMediaChunk(value: unknown): value is MediaChunk {
  if (!value || typeof value !== 'object') return false;
  const m = value as MediaChunk;
  return /^[a-f0-9]{32}$/.test(m.id) && /^[a-f0-9]{64}$/.test(m.hash) &&
    ((m.kind === 'photo' && m.mime === 'image/jpeg' && m.durationMs === undefined) || (m.kind === 'voice' && m.mime === 'audio/mp4' && Number.isInteger(m.durationMs) && m.durationMs! > 0 && m.durationMs! <= 15000)) &&
    Number.isInteger(m.size) && m.size > 0 && m.size <= MAX_MEDIA_BYTES && Number.isInteger(m.total) && m.total === Math.ceil(Math.ceil(m.size / 3) * 4 / MEDIA_CHUNK_CHARS) &&
    Number.isInteger(m.index) && m.index >= 0 && m.index < m.total && typeof m.data === 'string' && m.data.length > 0 && m.data.length <= MEDIA_CHUNK_CHARS &&
    m.data.length % 4 === 0 && /^[A-Za-z0-9+/]+={0,2}$/.test(m.data) && (m.index === m.total - 1 || (m.data.length === MEDIA_CHUNK_CHARS && !m.data.includes('=')));
}
export function splitMedia(bytes: Uint8Array, kind: MediaKind, random: RandomBytes, durationMs?: number): MediaChunk[] {
  if (!bytes.length || bytes.length > MAX_MEDIA_BYTES) throw Error('Keep attachments below 64 KB for Bluetooth.');
  if (kind === 'voice' && (!durationMs || durationMs > 15000)) throw Error('Voice messages can be up to 15 seconds.');
  const data = fromByteArray(bytes), total = Math.ceil(data.length / MEDIA_CHUNK_CHARS), id = randomId(random), hash = bytesToHex(sha256(bytes));
  return Array.from({ length: total }, (_, index) => ({ id, hash, kind, mime: kind === 'photo' ? 'image/jpeg' : 'audio/mp4', size: bytes.length, index, total, data: data.slice(index * MEDIA_CHUNK_CHARS, (index + 1) * MEDIA_CHUNK_CHARS), ...(kind === 'voice' ? { durationMs } : {}) }));
}
// A bounded room-local reassembler. Conflicting metadata and checksums never render.
export class MediaAssembler {
  private entries = new Map<string, { meta: MediaChunk; parts: Map<number, string>; at: number; complete?: Attachment }>();
  private bytes = 0;
  accept(author: string, chunk: MediaChunk, now: number): { progress: number; attachment?: Attachment } {
    if (!validMediaChunk(chunk)) throw Error('Invalid attachment chunk');
    const key = `${author}:${chunk.id}`;
    let e = this.entries.get(key);
    if (!e) {
      if (this.bytes + chunk.size > MAX_ROOM_MEDIA_BYTES || this.entries.size >= 100) throw Error('Room attachment storage is full.');
      e = { meta: chunk, parts: new Map(), at: now }; this.entries.set(key, e); this.bytes += chunk.size;
    }
    if (['hash', 'size', 'total', 'mime', 'kind', 'durationMs'].some(k => e!.meta[k as keyof MediaChunk] !== chunk[k as keyof MediaChunk])) throw Error('Conflicting attachment data');
    const old = e.parts.get(chunk.index); if (old !== undefined && old !== chunk.data) throw Error('Conflicting attachment chunk');
    e.parts.set(chunk.index, chunk.data); e.at = now;
    if (!e.complete && e.parts.size === chunk.total) {
      const base64 = Array.from({ length: chunk.total }, (_, i) => e!.parts.get(i)!).join(''), bytes = toByteArray(base64);
      if (bytes.length !== chunk.size || bytesToHex(sha256(bytes)) !== chunk.hash) throw Error('Attachment verification failed');
      if (chunk.kind === 'photo' && !(bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[bytes.length - 2] === 0xff && bytes[bytes.length - 1] === 0xd9)) throw Error('Invalid JPEG');
      if (chunk.kind === 'voice' && !(bytes.length >= 12 && String.fromCharCode(...bytes.slice(4, 8)) === 'ftyp')) throw Error('Invalid voice recording');
      e.complete = { id: chunk.id, kind: chunk.kind, mime: chunk.mime, size: chunk.size, base64, durationMs: chunk.durationMs };
    }
    return { progress: e.parts.size / chunk.total, attachment: e.complete };
  }
  prune(now: number) { for (const [key, e] of this.entries) if (!e.complete && now - e.at > 120000) { this.entries.delete(key); this.bytes -= e.meta.size; } }
  clear() { this.entries.clear(); this.bytes = 0; }
}
