import { xchacha20poly1305 } from '@noble/ciphers/chacha.js';
import { utf8ToBytes } from '@noble/hashes/utils.js';
import { fromByteArray, toByteArray } from 'base64-js';
import type { RoomHistory } from './room';
import type { MediaChunk } from './media';
import type { RandomBytes } from './wire';
export type SavedChat = { room: RoomHistory; outgoing: { chunks: MediaChunk[]; ids: string[] }[] };
export function sealChat(chat: SavedChat, key: Uint8Array, label: string, random: RandomBytes): string {
  const nonce = random(24), expiresAt = chat.room.expiresAt;
  const bytes = utf8ToBytes(JSON.stringify(chat));
  if (bytes.length > 20 * 1024 * 1024) throw Error('Saved chat storage is full.');
  return JSON.stringify({ expiresAt, nonce: fromByteArray(nonce), data: fromByteArray(xchacha20poly1305(key, nonce, utf8ToBytes(label + ':' + expiresAt)).encrypt(bytes)) });
}
export function openChat(raw: string, key: Uint8Array, label: string, now = Date.now()): SavedChat | null {
  if (raw.length > 30 * 1024 * 1024) throw Error('Invalid saved chat size.');
  const envelope = JSON.parse(raw);
  if (!Number.isSafeInteger(envelope.expiresAt) || envelope.expiresAt <= now) return null;
  const chat = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(xchacha20poly1305(key, toByteArray(envelope.nonce), utf8ToBytes(label + ':' + envelope.expiresAt)).decrypt(toByteArray(envelope.data)))) as SavedChat;
  if (chat.room.expiresAt !== envelope.expiresAt || !Array.isArray(chat.outgoing) || chat.outgoing.length > 50) throw Error('Invalid saved chat.');
  return chat;
}
