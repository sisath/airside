import { validRoomCode } from './room-code';
import type { RoomMode } from './room-wire';
type Settings = { name: string; code: string; mode?: RoomMode; expiresAt?: number };
export type RecentChat = Settings & { expiresAt: number; visitedAt: number };
const INDEX = 'closeby.recent.index';
const key = (code: string) => 'closeby.recent.' + code;
type Storage = { getItemAsync(key: string): Promise<string | null>; setItemAsync(key: string, value: string): Promise<void>; deleteItemAsync(key: string): Promise<void> };
export function createRecentChats(storage: Storage, now = Date.now) {
let queue: Promise<unknown> = Promise.resolve();
async function read(): Promise<RecentChat[]> {
  const codes: string[] = JSON.parse(await storage.getItemAsync(INDEX) || '[]');
  const rooms: RecentChat[] = [];
  for (const code of codes) {
    if (!validRoomCode(code)) continue;
    try {
      const room = JSON.parse(await storage.getItemAsync(key(code)) || 'null') as RecentChat | null;
      if (room && room.expiresAt > now() && new Date(room.visitedAt).toDateString() === new Date(now()).toDateString()) rooms.push(room);
      else await storage.deleteItemAsync(key(code));
    } catch { await storage.deleteItemAsync(key(code)); }
  }
  await storage.setItemAsync(INDEX, JSON.stringify(rooms.map(r => r.code)));
  return rooms.sort((a, b) => b.visitedAt - a.visitedAt);
}
function loadRecentChats(): Promise<RecentChat[]> {
  const task = queue.then(read); queue = task.catch(() => {}); return task;
}
function rememberChat(settings: Settings): Promise<void> {
  const task = queue.then(async () => {
    if (!validRoomCode(settings.code) || !settings.expiresAt || settings.expiresAt <= now()) return;
    const rooms = await read();
    const room: RecentChat = { ...settings, expiresAt: settings.expiresAt, visitedAt: now() };
    await storage.setItemAsync(key(room.code), JSON.stringify(room));
    await storage.setItemAsync(INDEX, JSON.stringify([room.code, ...rooms.filter(r => r.code !== room.code).map(r => r.code)]));
  });
  queue = task.catch(() => {}); return task;
}

return { loadRecentChats, rememberChat };
}
