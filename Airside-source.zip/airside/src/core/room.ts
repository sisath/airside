import { MAX_TEXT, randomId, type RandomBytes } from './wire';
import { MAX_MEMBERS, RoomCodec, type Member, type RoomMode, type RoomPacket } from './room-wire';

export type RoomMessage = { id: string; text: string; at: number; author: string; name: string; direction: 'in' | 'out'; status: 'queued' | 'sending' | 'delivered' | 'retry' };
export type RoomSnapshot = { status: 'waiting' | 'verifying' | 'connected'; members: Member[]; messages: RoomMessage[]; problem: string | null };
type Options = { code: string; name: string; mode: RoomMode; random: RandomBytes; send(payload: string, peer: string): Promise<void>; changed(state: RoomSnapshot): void; now?: () => number };
type Peer = { identity: string; session: string; name: string; ready: boolean; seen: number; challenge: string };
type Delivery = { message: RoomMessage; targets: Map<string, string>; acks: Set<string>; attempts: number; at: number; senderPeer?: string };

// A room owner relays messages. Physical peer IDs are bound to fresh encrypted
// challenge responses; possession of the code admits a participant, not an identity.
export class RoomSession {
  private codec: RoomCodec;
  private local: string;
  private identity: string;
  private host = '';
  private challenge = '';
  private total = 0;
  private linked = false;
  private peers = new Map<string, Peer>();
  private members: Member[] = [];
  private messages: RoomMessage[] = [];
  private seen = new Set<string>();
  private deliveries = new Map<string, Delivery>();
  private attempts = new Map<string, { count: number; at: number }>();
  private problem: string | null = null;
  private chain = Promise.resolve();
  private lastHello = 0;
  private lastPing = 0;
  private hostSeen = 0;
  private disposed = false;
  private epoch = 0;
  private now: () => number;
  constructor(private o: Options) {
    this.codec = new RoomCodec(o.code, o.random); this.local = randomId(o.random); this.identity = this.local; this.now = o.now ?? Date.now;
    this.members = [this.self()];
  }
  private self(): Member { return { id: this.identity, name: this.o.name, host: this.o.mode === 'create' }; }
  snapshot(): RoomSnapshot {
    return { status: this.o.mode === 'create' ? (this.members.length > 1 ? 'connected' : 'waiting') : this.host && this.members.length > 1 ? 'connected' : this.linked ? 'verifying' : 'waiting',
      members: this.members.map(m => ({ ...m })), messages: this.messages.map(m => ({ ...m })), problem: this.problem };
  }
  private publish() { if (!this.disposed) this.o.changed(this.snapshot()); }
  private tx(peer: string, body: Omit<RoomPacket, 'v' | 'session'>) {
    const p = { ...body, v: 2, session: this.local } as RoomPacket, epoch = this.epoch;
    this.chain = this.chain.then(async () => { if (!this.disposed && epoch === this.epoch) await this.o.send(this.codec.encode(p), peer); }).catch(() => {
      if (!this.disposed && epoch === this.epoch) { this.problem = 'A Bluetooth transfer was interrupted. Unconfirmed messages can be retried.'; this.publish(); }
    });
  }
  link(peer: string, linked: boolean) {
    if (this.disposed) return;
    if (this.o.mode === 'create') {
      if (!linked) { this.peers.delete(peer); this.roster(); }
      // The client sends hello after subscribing. Do not admit raw BLE subscribers.
    } else {
      this.epoch++; this.chain = Promise.resolve(); this.linked = linked; this.host = ''; this.challenge = '';
      if (linked) { this.local = randomId(this.o.random);  }
      this.members = [this.self()];
      this.attempts.clear();
      this.messages.filter(m => m.direction === 'out' && m.status !== 'delivered').forEach(m => { m.status = 'queued'; });
      if (linked) this.hello();
      else this.problem = 'Room owner disconnected. Keep the owner nearby and reconnect.';
    }
    this.publish();
  }
  private hello() { this.lastHello = this.now(); this.tx('host', { t: 'hello', name: this.o.name, identity: this.identity } as RoomPacket); }
  receive(payload: string, peer: string) {
    if (this.disposed) return;
    let p: RoomPacket; try { p = this.codec.decode(payload); } catch { return; }
    if (p.session === this.local) return;
    if (this.o.mode === 'create') this.receiveAsHost(p, peer); else this.receiveAsGuest(p);
  }
  private receiveAsHost(p: RoomPacket, peer: string) {
    if (p.t === 'hello') {
      const old = this.peers.get(peer);
      if (!old && this.peers.size >= MAX_MEMBERS - 1) { this.tx(peer, { t: 'error', to: p.session, text: 'This room is full (8 people maximum).' } as RoomPacket); return; }
      if (old?.session !== p.session) this.peers.set(peer, { identity: p.identity, session: p.session, name: p.name, ready: false, seen: this.now(), challenge: randomId(this.o.random) });
      this.tx(peer, { t: 'welcome', to: p.session, name: this.o.name, challenge: this.peers.get(peer)!.challenge } as RoomPacket); return;
    }
    const who = this.peers.get(peer);
    if (!who || who.session !== p.session || !('to' in p) || p.to !== this.local) return;
    who.seen = this.now();
    if (p.t === 'ready') { if (p.challenge !== who.challenge) return;
      for (const [id, existing] of this.peers) if (id !== peer && existing.identity === who.identity) this.peers.delete(id);
      who.ready = true; this.problem = null; this.roster(); this.flushQueued(); return; }
    if (!who.ready) return;
    if (p.t === 'submit') {
      const existing = this.deliveries.get(p.id);
      if (existing) { if (existing.message.author === who.identity) {
        // A reconnect changes the encrypted session, but keeps the sender identity.
        if (existing.senderPeer && existing.senderPeer !== peer) { existing.targets.delete(existing.senderPeer); existing.acks.delete(existing.senderPeer); }
        existing.senderPeer = peer;
        if (existing.targets.get(peer) !== p.session) { existing.targets.set(peer, p.session); existing.acks.delete(peer); }
        this.broadcast(existing);
      } return; }
      if (this.seen.has(p.id)) return;
      if (this.total >= 1000) { this.tx(peer, { t: 'error', to: p.session, text: 'Chat is full. Create a new room.' } as RoomPacket); return; }
      const message: RoomMessage = { id: p.id, author: who.identity, name: who.name, text: p.text, at: this.now(), direction: 'in', status: 'delivered' };
      this.total++; this.messages.push(message); this.seen.add(p.id); this.beginDelivery(message, peer); this.publish();
    } else if (p.t === 'ack') {
      const d = this.deliveries.get(p.id);
      if (d?.targets.get(peer) === p.session) { d.acks.add(peer); this.complete(d); }
    } else if (p.t === 'ping') this.tx(peer, { t: 'pong', to: p.session } as RoomPacket);
  }
  private receiveAsGuest(p: RoomPacket) {
    if (!this.linked || !('to' in p) || p.to !== this.local) return;
    if (p.t === 'welcome') {
      if (this.host && this.host !== p.session) return;
      this.host = p.session; this.challenge = p.challenge; this.hostSeen = this.now(); this.problem = null;
      this.tx('host', { t: 'ready', to: this.host, challenge: this.challenge } as RoomPacket); return;
    }
    if (p.t === 'error' && !this.host) { this.problem = p.text; this.publish(); return; }
    if (!this.host || p.session !== this.host) return;
    this.hostSeen = this.now();
    if (p.t === 'roster') {
      if (!p.members.some(m => m.id === this.identity) || !p.members.some(m => m.id === this.host && m.host)) return;
      this.members = p.members; this.problem = null; this.flushQueued();
    } else if (p.t === 'message') {
      if (!this.seen.has(p.id)) {
        const own = this.messages.find(m => m.id === p.id && m.direction === 'out');
        if (!own) {
          if (this.messages.length >= 1000) { this.problem = 'Chat is full. Create a new room.'; this.publish(); return; }
          this.total++; this.messages.push({ id: p.id, author: p.author, name: p.name, text: p.text, at: this.now(), direction: 'in', status: 'delivered' });
        }
        this.seen.add(p.id);
      }
      this.tx('host', { t: 'ack', to: this.host, id: p.id } as RoomPacket);
    } else if (p.t === 'receipt') {
      const m = this.messages.find(m => m.id === p.id && m.direction === 'out');
      if (m) { m.status = 'delivered'; this.attempts.delete(m.id); }
    } else if (p.t === 'ping') this.tx('host', { t: 'pong', to: this.host } as RoomPacket);
    else if (p.t === 'error') this.problem = p.text;
    this.publish();
  }
  private roster() {
    this.members = [this.self(), ...Array.from(this.peers.values()).filter(p => p.ready).map(p => ({ id: p.identity, name: p.name, host: false }))];
    for (const [peer, p] of this.peers) if (p.ready) this.tx(peer, { t: 'roster', to: p.session, members: this.members } as RoomPacket);
    this.publish();
  }
  send(text: string): string {
    text = text.trim();
    if (!text || text.length > MAX_TEXT) throw Error(`Messages must contain 1–${MAX_TEXT} characters.`);
    if (this.messages.length >= 1000) throw Error('Chat is full. Create a new room.');
    const message: RoomMessage = { id: randomId(this.o.random), text, at: this.now(), author: this.identity, name: this.o.name, direction: 'out', status: 'queued' };
    this.total++; this.messages.push(message); this.deliver(message); this.publish(); return message.id;
  }
  private flushQueued() { this.messages.filter(m => m.direction === 'out' && m.status === 'queued').forEach(m => this.deliver(m)); }
  private deliver(m: RoomMessage) {
    if (this.o.mode === 'create') { if (this.members.length > 1) this.beginDelivery(m); }
    else if (this.host && this.members.length > 1) {
      const a = this.attempts.get(m.id); this.attempts.set(m.id, { count: (a?.count ?? 0) + 1, at: this.now() }); m.status = 'sending';
      this.tx('host', { t: 'submit', to: this.host, id: m.id, text: m.text } as RoomPacket);
    }
  }
  private beginDelivery(m: RoomMessage, senderPeer?: string) {
    const d: Delivery = { message: m, targets: new Map(Array.from(this.peers).filter(([, p]) => p.ready).map(([id, p]) => [id, p.session])), acks: new Set(), attempts: 0, at: 0, senderPeer };
    this.deliveries.set(m.id, d); if (m.direction === 'out') m.status = 'sending'; this.broadcast(d);
  }
  private broadcast(d: Delivery) {
    d.at = this.now(); d.attempts++;
    for (const [peer, session] of d.targets) {
      if (d.acks.has(peer) || this.peers.get(peer)?.session !== session) continue;
      const m = d.message;
      this.tx(peer, { t: 'message', to: session, id: m.id, text: m.text, at: m.at, author: m.author, name: m.name } as RoomPacket);
    }
    this.complete(d);
  }
  private complete(d: Delivery) {
    if (d.acks.size !== d.targets.size) return;
    if (d.message.direction === 'out') d.message.status = 'delivered';
    else for (const [peer, p] of this.peers) if (p.identity === d.message.author && p.ready) this.tx(peer, { t: 'receipt', to: p.session, id: d.message.id } as RoomPacket);
    // Retain bounded delivery metadata to answer retries after a lost receipt.
    this.publish();
  }
  retry(id: string) {
    const m = this.messages.find(m => m.id === id && m.direction === 'out');
    if (!m || m.status === 'delivered') return;
    const d = this.deliveries.get(id);
    if (this.o.mode === 'create' && d) {
      if (this.members.length > 1) this.beginDelivery(m); else m.status = 'queued';
    }
    else { this.attempts.delete(id); m.status = 'queued'; this.deliver(m); }
    this.publish();
  }
  tick() {
    if (this.disposed) return;
    const now = this.now();
    if (this.o.mode === 'join') {
      if (!this.linked) return;
      if (!this.host) { if (now - this.lastHello >= 2000) this.hello(); return; }
      if (this.members.length === 1 && now - this.lastHello > 2000) { this.lastHello = now; this.tx('host', { t: 'ready', to: this.host, challenge: this.challenge } as RoomPacket); }
      if (now - this.hostSeen > 30000) { this.link('host', false); return; }
      for (const m of this.messages) {
        const a = this.attempts.get(m.id);
        if (m.direction === 'out' && m.status === 'sending' && a && now - a.at > 6000) {
          if (a.count >= 3) m.status = 'retry'; else this.deliver(m);
        }
      }
    } else {
      for (const [peer, p] of this.peers) if (now - p.seen > 30000) { this.peers.delete(peer); this.roster(); }
      for (const d of this.deliveries.values()) if (d.acks.size < d.targets.size && now - d.at > 6000 && d.attempts < 3) this.broadcast(d);
      for (const d of this.deliveries.values()) if (d.message.direction === 'out' && d.acks.size < d.targets.size && d.attempts >= 3 && now - d.at > 6000) d.message.status = 'retry';
    }
    if (now - this.lastPing > 7000) {
      this.lastPing = now;
      if (this.o.mode === 'create') for (const [peer, p] of this.peers) if (p.ready) this.tx(peer, { t: 'ping', to: p.session } as RoomPacket);
      if (this.o.mode === 'join' && this.host) this.tx('host', { t: 'ping', to: this.host } as RoomPacket);
    }
    this.publish();
  }
  resetLinks() {
    if (this.o.mode === 'join') this.link('host', false);
    else { this.peers.clear(); this.roster(); }
  }
  clearHistory() { this.messages = []; this.attempts.clear(); this.publish(); }
  dispose() { this.disposed = true; this.epoch++; this.peers.clear(); }
}
