import { ROOM_LIFETIME } from './room-code';
import { validMediaChunk, type MediaChunk } from './media';
import { MAX_TEXT, randomId, type RandomBytes } from './wire';
import { MAX_MEMBERS, RoomCodec, type Member, type RoomMode, type RoomPacket } from './room-wire';

export type RoomMessage = { id: string; text: string; heart?: true; media?: MediaChunk; at: number; author: string; name: string; direction: 'in' | 'out'; status: 'queued' | 'sending' | 'delivered' | 'retry' };
export type RoomSnapshot = { status: 'waiting' | 'verifying' | 'connected' | 'expired'; expiresAt: number; typing: { id: string; name: string }[]; members: Member[]; messages: RoomMessage[]; problem: string | null };
export type RoomHistory = { identity: string; expiresAt: number; messages: RoomMessage[]; seen: string[]; receipts: [string, string][] };
type Options = { history?: RoomHistory; code: string; name: string; mode: RoomMode; random: RandomBytes; send(payload: string, peer: string): Promise<void>; changed(state: RoomSnapshot): void; now?: () => number; expiresAt?: number; ackWaitMs?: number };
type Peer = { identity: string; session: string; name: string; ready: boolean; seen: number; challenge: string };
type Delivery = { message: RoomMessage; targets: Map<string, string>; acks: Set<string>; attempts: number; at: number; senderPeer?: string; inflight: boolean };

// A room owner relays messages. Physical peer IDs are bound to fresh encrypted
// challenge responses; possession of the code admits a participant, not an identity.
export class RoomSession {
  private codec: RoomCodec;
  private local: string;
  private identity: string;
  private host = '';
  private challenge = '';
  private total = 0;
  private expiresAt: number;
  private expired = false;
  private typing = new Map<string, { name: string; until: number }>();
  private lastTyping = 0;
  private wasTyping = false;
  private linked = false;
  private peers = new Map<string, Peer>();
  private members: Member[] = [];
  private messages: RoomMessage[] = [];
  private restoredPending = new Set<string>();
  private seen = new Set<string>();
  private receipts = new Map<string, string>();
  private deliveries = new Map<string, Delivery>();
  private attempts = new Map<string, { count: number; at: number; pending: boolean }>();
  private problem: string | null = null;
  private chain = Promise.resolve();
  private lastHello = 0;
  private lastPing = 0;
  private hostSeen = 0;
  private disposed = false;
  private epoch = 0;
  private now: () => number;
  constructor(private o: Options) {
    this.codec = new RoomCodec(o.code, o.random); this.local = randomId(o.random); this.identity = this.local; this.now = o.now ?? Date.now;
    this.expiresAt = o.expiresAt ?? (o.mode === 'create' ? this.now() + ROOM_LIFETIME : 0);
    if (o.history && o.history.expiresAt > this.now()) {
      const h = o.history;
      if (!/^[a-f0-9]{32}$/.test(h.identity) || h.messages.length > 6000 || h.seen.length > 6000 || h.receipts.length > 6000) throw Error('Invalid saved chat.');
      if (o.mode === 'join') this.identity = h.identity; this.expiresAt = this.expiresAt ? Math.min(this.expiresAt, h.expiresAt) : h.expiresAt;
      this.messages = h.messages.map(m => {
        if (!/^[a-f0-9]{32}$/.test(m.id) || !/^[a-f0-9]{32}$/.test(m.author) || typeof m.text !== 'string' || m.text.length > MAX_TEXT || typeof m.name !== 'string' || m.name.length > 32 || !Number.isSafeInteger(m.at) || !['in', 'out'].includes(m.direction) || !['queued', 'sending', 'delivered', 'retry'].includes(m.status) || (m.media && !validMediaChunk(m.media)) || (m.heart !== undefined && m.heart !== true) || (m.heart && !!m.media)) throw Error('Invalid saved message.');
        return { ...m, status: m.direction === 'out' && m.status !== 'delivered' ? 'retry' : m.status };
      });
      for (const m of this.messages) if (m.direction === 'out' && m.status !== 'delivered') this.restoredPending.add(m.id);
      this.seen = new Set(h.seen); this.receipts = new Map(h.receipts); this.total = Math.max(this.seen.size, this.messages.length);
    }
    this.members = [this.self()];
  }
  history(): RoomHistory { return { identity: this.identity, expiresAt: this.expiresAt, messages: this.messages.map(m => ({ ...m })), seen: [...this.seen], receipts: [...this.receipts] }; }
  private self(): Member { return { id: this.identity, name: this.o.name, host: this.o.mode === 'create' }; }
  snapshot(): RoomSnapshot {
    return { expiresAt: this.expiresAt, typing: Array.from(this.typing, ([id, p]) => ({ id, name: p.name })), status: this.expired ? 'expired' : this.o.mode === 'create' ? (this.members.length > 1 ? 'connected' : 'waiting') : this.host && this.members.length > 1 ? 'connected' : this.linked ? 'verifying' : 'waiting',
      members: this.members.map(m => ({ ...m })), messages: this.messages.map(m => ({ ...m })), problem: this.problem };
  }
  private publish() { if (!this.disposed) this.o.changed(this.snapshot()); }
  private tx(peer: string, body: Omit<RoomPacket, 'v' | 'session'>) {
    const p = { ...body, v: 2, session: this.local } as RoomPacket, epoch = this.epoch;
    this.chain = this.chain.then(async () => { if (!this.disposed && !this.expired && epoch === this.epoch) await this.o.send(this.codec.encode(p), peer); }).catch(() => {
      if (!this.disposed && epoch === this.epoch) { this.problem = 'Transfer Interrupted.'; this.publish(); }
    });
    return this.chain;
  }
  link(peer: string, linked: boolean) {
    if (this.disposed || !this.live()) return;
    if (this.o.mode === 'create') {
      if (!linked) { this.peers.delete(peer); this.roster(); }
      // The client sends hello after subscribing. Do not admit raw BLE subscribers.
    } else {
      this.epoch++; this.chain = Promise.resolve(); this.linked = linked; this.host = ''; this.challenge = '';
      if (linked) { this.local = randomId(this.o.random);  }
      this.members = [this.self()];
      this.attempts.clear();
      this.messages.filter(m => m.direction === 'out' && m.status !== 'delivered' && !this.restoredPending.has(m.id)).forEach(m => { m.status = 'queued'; });
      if (linked) this.hello();
      else this.problem = 'Disconnected.';
    }
    this.publish();
  }
  private hello() { this.lastHello = this.now(); this.tx('host', { t: 'hello', name: this.o.name, identity: this.identity } as RoomPacket); }
  receive(payload: string, peer: string) {
    if (this.disposed || !this.live()) return;
    let p: RoomPacket; try { p = this.codec.decode(payload); } catch { return; }
    if (p.session === this.local) return;
    if (this.o.mode === 'create') this.receiveAsHost(p, peer); else this.receiveAsGuest(p);
  }
  private receiveAsHost(p: RoomPacket, peer: string) {
    if (p.t === 'hello') {
      const old = this.peers.get(peer);
      if (!old && this.peers.size >= MAX_MEMBERS - 1) { this.tx(peer, { t: 'error', to: p.session, text: 'This room is full (8 people maximum).' } as RoomPacket); return; }
      if (old?.session !== p.session) this.peers.set(peer, { identity: p.identity, session: p.session, name: p.name, ready: false, seen: this.now(), challenge: randomId(this.o.random) });
      this.tx(peer, { t: 'welcome', to: p.session, name: this.o.name, challenge: this.peers.get(peer)!.challenge, expiresAt: this.expiresAt } as RoomPacket); return;
    }
    const who = this.peers.get(peer);
    if (!who || who.session !== p.session || !('to' in p) || p.to !== this.local) return;
    who.seen = this.now();
    if (p.t === 'ready') { if (p.challenge !== who.challenge) return;
      for (const [id, existing] of this.peers) if (id !== peer && existing.identity === who.identity) this.peers.delete(id);
      who.ready = true; this.problem = null; this.roster(); this.flushQueued(); return; }
    if (!who.ready) return;
    if (p.t === 'submit') {
      const existing = this.deliveries.get(p.id);
      if (existing) { if (existing.message.author === who.identity) {
        // A reconnect changes the encrypted session, but keeps the sender identity.
        if (existing.senderPeer && existing.senderPeer !== peer) { existing.targets.delete(existing.senderPeer); existing.acks.delete(existing.senderPeer); }
        existing.senderPeer = peer;
        if (existing.targets.get(peer) !== p.session) { existing.targets.set(peer, p.session); existing.acks.delete(peer); }
        this.broadcast(existing);
      } return; }
      if (this.seen.has(p.id)) { if (this.receipts.get(p.id) === who.identity) this.tx(peer, { t: 'receipt', to: p.session, id: p.id } as RoomPacket); return; }
      if (this.total >= 6000) { this.tx(peer, { t: 'error', to: p.session, text: 'Chat Full.' } as RoomPacket); return; }
      const message: RoomMessage = { id: p.id, author: who.identity, name: who.name, text: p.text, media: p.media, heart: p.heart, at: this.now(), direction: 'in', status: 'delivered' };
      this.total++; this.messages.push(message); this.seen.add(p.id); this.beginDelivery(message, peer); this.publish();
    } else if (p.t === 'typing') {
      this.activity(who.identity, who.name, p.active);
      for (const [id, person] of this.peers) if (person.ready && id !== peer) this.tx(id, { t: 'activity', to: person.session, member: who.identity, name: who.name, active: p.active } as RoomPacket);
    } else if (p.t === 'ack') {
      const d = this.deliveries.get(p.id);
      if (d?.targets.get(peer) === p.session) { d.acks.add(peer); this.complete(d); }
    } else if (p.t === 'ping') this.tx(peer, { t: 'pong', to: p.session } as RoomPacket);
  }
  private receiveAsGuest(p: RoomPacket) {
    if (!this.linked || !('to' in p) || p.to !== this.local) return;
    if (p.t === 'welcome') {
      if (this.host && this.host !== p.session) return;
      if (!this.setExpiry(p.expiresAt)) return;
      this.host = p.session; this.challenge = p.challenge; this.hostSeen = this.now(); this.problem = null;
      this.tx('host', { t: 'ready', to: this.host, challenge: this.challenge } as RoomPacket); return;
    }
    if (p.t === 'error' && !this.host) { this.problem = p.text; this.publish(); return; }
    if (!this.host || p.session !== this.host) return;
    this.hostSeen = this.now();
    if (p.t === 'roster') {
      if (!p.members.some(m => m.id === this.identity) || !p.members.some(m => m.id === this.host && m.host)) return;
      this.members = p.members; this.problem = null; this.flushQueued();
    } else if (p.t === 'message') {
      if (!this.seen.has(p.id)) {
        const own = this.messages.find(m => m.id === p.id && m.direction === 'out');
        if (!own) {
          if (this.messages.length >= 6000) { this.problem = 'Chat Full.'; this.publish(); return; }
          this.total++; this.messages.push({ id: p.id, author: p.author, name: p.name, text: p.text, media: p.media, heart: p.heart, at: this.now(), direction: 'in', status: 'delivered' });
        }
        this.seen.add(p.id);
      }
      this.tx('host', { t: 'ack', to: this.host, id: p.id } as RoomPacket);
    } else if (p.t === 'activity') { this.activity(p.member, p.name, p.active);
    } else if (p.t === 'receipt') {
      const m = this.messages.find(m => m.id === p.id && m.direction === 'out');
      if (m) { m.status = 'delivered'; this.attempts.delete(m.id); }
    } else if (p.t === 'ping') this.tx('host', { t: 'pong', to: this.host } as RoomPacket);
    else if (p.t === 'error') this.problem = p.text;
    this.publish();
  }
  private roster() {
    this.members = [this.self(), ...Array.from(this.peers.values()).filter(p => p.ready).map(p => ({ id: p.identity, name: p.name, host: false }))];
    for (const [peer, p] of this.peers) if (p.ready) this.tx(peer, { t: 'roster', to: p.session, members: this.members } as RoomPacket);
    this.publish();
  }
  send(text: string, media?: MediaChunk, heart = false): string {
    if (!this.live()) throw Error('Room Expired.');
    if (heart && media) throw Error('Invalid Heart Message.');
    text = text.trim();
    if ((!text && !media) || text.length > MAX_TEXT) throw Error(`Messages must contain 1–${MAX_TEXT} characters.`);
    if (this.total >= 6000 || this.messages.length >= 6000) throw Error('Chat Full.');
    const message: RoomMessage = { id: randomId(this.o.random), text, media, ...(heart ? { heart: true as const } : {}), at: this.now(), author: this.identity, name: this.o.name, direction: 'out', status: 'queued' };
    this.total++; this.messages.push(message); this.deliver(message); this.publish(); return message.id;
  }
  private flushQueued() { this.messages.filter(m => m.direction === 'out' && m.status === 'queued').forEach(m => this.deliver(m)); }
  private deliver(m: RoomMessage) {
    if (this.o.mode === 'create') { if (this.members.length > 1) this.beginDelivery(m); }
    else if (this.host && this.members.length > 1) {
      const a = this.attempts.get(m.id); this.attempts.set(m.id, { count: (a?.count ?? 0) + 1, at: this.now(), pending: true }); m.status = 'sending';
      void this.tx('host', { t: 'submit', to: this.host, id: m.id, text: m.text, media: m.media, heart: m.heart } as RoomPacket).then(() => { const sent = this.attempts.get(m.id); if (sent) { sent.pending = false; sent.at = this.now(); } });
    }
  }
  private beginDelivery(m: RoomMessage, senderPeer?: string) {
    const d: Delivery = { message: m, targets: new Map(Array.from(this.peers).filter(([, p]) => p.ready).map(([id, p]) => [id, p.session])), acks: new Set(), attempts: 0, at: 0, inflight: false, senderPeer };
    this.deliveries.set(m.id, d); if (m.direction === 'out') m.status = 'sending'; this.broadcast(d);
  }
  private broadcast(d: Delivery) {
    if (d.inflight) return;
    d.at = this.now(); d.attempts++; d.inflight = true;
    const sent: Promise<void>[] = [];
    for (const [peer, session] of d.targets) {
      if (d.acks.has(peer) || this.peers.get(peer)?.session !== session) continue;
      const m = d.message;
      sent.push(this.tx(peer, { t: 'message', to: session, id: m.id, text: m.text, media: m.media, heart: m.heart, at: m.at, author: m.author, name: m.name } as RoomPacket));
    }
    void Promise.all(sent).then(() => { d.inflight = false; d.at = this.now(); });
    this.complete(d);
  }
  private complete(d: Delivery) {
    if (d.acks.size !== d.targets.size) return;
    if (d.message.direction === 'out') d.message.status = 'delivered';
    else { this.receipts.set(d.message.id, d.message.author); for (const [peer, p] of this.peers) if (p.identity === d.message.author && p.ready) this.tx(peer, { t: 'receipt', to: p.session, id: d.message.id } as RoomPacket); }
    // Retain bounded delivery metadata to answer retries after a lost receipt.
    this.publish();
  }
  markRetry(id: string) { const message = this.messages.find(m => m.id === id && m.direction === 'out'); if (message && message.status !== 'delivered') { message.status = 'retry'; this.publish(); } }
  retry(id: string) {
    const m = this.messages.find(m => m.id === id && m.direction === 'out');
    if (!m || m.status === 'delivered') return;
    this.restoredPending.delete(id);
    const d = this.deliveries.get(id);
    if (this.o.mode === 'create' && d) {
      if (this.members.length > 1) this.beginDelivery(m); else m.status = 'queued';
    }
    else { this.attempts.delete(id); m.status = 'queued'; this.deliver(m); }
    this.publish();
  }
  tick() {
    if (this.disposed || !this.live()) return;
    const now = this.now();
    for (const [id, p] of this.typing) if (p.until <= now) this.typing.delete(id);
    if (this.o.mode === 'join') {
      if (!this.linked) return;
      if (!this.host) { if (now - this.lastHello >= 2000) this.hello(); return; }
      if (this.members.length === 1 && now - this.lastHello > 2000) { this.lastHello = now; this.tx('host', { t: 'ready', to: this.host, challenge: this.challenge } as RoomPacket); }
      if (now - this.hostSeen > 180000) { this.link('host', false); return; }
      for (const m of this.messages) {
        const a = this.attempts.get(m.id);
        if (m.direction === 'out' && m.status === 'sending' && a && !a.pending && now - a.at > (this.o.ackWaitMs ?? 45000)) {
          if (a.count >= 3) m.status = 'retry'; else this.deliver(m);
        }
      }
    } else {
      for (const [peer, p] of this.peers) if (now - p.seen > 180000) { this.peers.delete(peer); this.roster(); }
      for (const d of this.deliveries.values()) if (d.acks.size < d.targets.size && !d.inflight && now - d.at > (this.o.ackWaitMs ?? 45000) && d.attempts < 3) this.broadcast(d);
      for (const d of this.deliveries.values()) if (d.message.direction === 'out' && d.acks.size < d.targets.size && d.attempts >= 3 && !d.inflight && now - d.at > (this.o.ackWaitMs ?? 45000)) d.message.status = 'retry';
    }
    if (now - this.lastPing > 7000) {
      this.lastPing = now;
      if (this.o.mode === 'create') for (const [peer, p] of this.peers) if (p.ready) this.tx(peer, { t: 'ping', to: p.session } as RoomPacket);
      if (this.o.mode === 'join' && this.host) this.tx('host', { t: 'ping', to: this.host } as RoomPacket);
    }
    this.publish();
  }
  private live(): boolean {
    if (!this.expired && this.expiresAt && this.now() >= this.expiresAt) {
      this.expired = true; this.epoch++; this.linked = false; this.peers.clear(); this.members = []; this.messages = []; this.seen.clear(); this.receipts.clear(); this.deliveries.clear(); this.attempts.clear(); this.typing.clear(); this.codec.dispose();
      this.problem = 'Room Expired.'; this.publish();
    }
    return !this.expired;
  }
  setExpiry(value: number): boolean {
    if (!Number.isSafeInteger(value) || value <= 0 || value > this.now() + ROOM_LIFETIME + 300000) return false;
    this.expiresAt = this.expiresAt ? Math.min(this.expiresAt, value) : Math.min(value, this.now() + ROOM_LIFETIME);
    return this.live();
  }
  private activity(id: string, name: string, active: boolean) {
    if (active) this.typing.set(id, { name, until: this.now() + 5000 }); else this.typing.delete(id);
    this.publish();
  }
  setTyping(active: boolean) {
    if (!this.live() || (active === this.wasTyping && this.now() - this.lastTyping < 2000)) return;
    this.wasTyping = active; this.lastTyping = this.now();
    if (this.o.mode === 'create') for (const [peer, p] of this.peers) if (p.ready) this.tx(peer, { t: 'activity', to: p.session, member: this.identity, name: this.o.name, active } as RoomPacket);
    if (this.o.mode === 'join' && this.host) this.tx('host', { t: 'typing', to: this.host, active } as RoomPacket);
  }
  resetLinks() {
    if (this.o.mode === 'join') this.link('host', false);
    else { this.peers.clear(); this.roster(); }
  }
  clearHistory() { this.messages = []; this.deliveries.clear(); this.attempts.clear(); this.publish(); }
  dispose() { this.disposed = true; this.epoch++; this.peers.clear(); this.messages = []; this.deliveries.clear(); this.seen.clear(); this.receipts.clear(); this.typing.clear(); this.codec.dispose(); }
}
