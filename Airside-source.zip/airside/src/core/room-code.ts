import { normaliseCode, type RandomBytes } from './wire';
const LETTERS = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
const DIGITS = '0123456789';
export const ROOM_LIFETIME = 24 * 60 * 60 * 1000;
export function validRoomCode(code: string): boolean { return /^[A-HJ-NP-Z]{3}[0-9]{3}$/.test(normaliseCode(code)); }
export function createRoomCode(random: RandomBytes): string {
  // Rejection sampling avoids bias in the 24-letter alphabet.
  let letters = '';
  while (letters.length < 3) { for (const b of random(8)) if (b < 240 && letters.length < 3) letters += LETTERS[b % 24]; }
  let digits = '';
  while (digits.length < 3) { for (const b of random(8)) if (b < 250 && digits.length < 3) digits += DIGITS[b % 10]; }
  return letters + digits;
}
export function formatRoomCode(code: string): string { const c = normaliseCode(code); return c.length === 6 ? `${c.slice(0, 3)} ${c.slice(3)}` : c; }
