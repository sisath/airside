import { WireCodec, randomId, MAX_TEXT, type RandomBytes, type Packet, type Message } from './wire';

export type ChatMessage = { id: string; text: string; at: number; direction: 'in' | 'out'; status: 'queued' | 'sending' | 'delivered' | 'retry' };
export type SessionStatus = 'waiting' | 'verifying' | 'connected';
export type SessionSnapshot = { status: SessionStatus; peerName: string; messages: ChatMessage[]; problem: string | null };
type Options = { code: string; name: string; random: RandomBytes; send: (base64: string) => Promise<void>; changed: (state: SessionSnapshot) => void; now?: () => number };

// Application acknowledgements, not successful BLE writes, establish delivery.
export class ChatSession {
  private codec: WireCodec;
  private local: string;
  private peer = '';
  private peerName = '';
  private linked = false;
  private status: SessionStatus = 'waiting';
  private messages: ChatMessage[] = [];
  private seen = new Set<string>();
  private attempts = new Map<string, { count: number; time: number }>();
  private chain = Promise.resolve();
  private epoch = 0;
  private lastHello = 0;
  private lastPing = 0;
  private lastSeen = 0;
  private problem: string | null = null;
  private disposed = false;
  private now: () => number;
  constructor(private options: Options) {
    this.codec = new WireCodec(options.code, options.random);
    this.local = randomId(options.random);
    this.now = options.now ?? Date.now;
  }
  snapshot(): SessionSnapshot { return { status: this.status, peerName: this.peerName, messages: this.messages.map(m => ({ ...m })), problem: this.problem }; }
  private publish() { if (!this.disposed) this.options.changed(this.snapshot()); }
  private transmit(packet: Packet) {
    const epoch = this.epoch;
    this.chain = this.chain.then(async () => {
      if (this.disposed || !this.linked || epoch !== this.epoch) return;
      await this.options.send(this.codec.encode(packet));
    }).catch(() => {
      if (this.disposed || epoch !== this.epoch) return;
      this.problem = 'The Bluetooth transfer was interrupted. Reconnect to try again.';
      this.publish();
    });
  }
  setLinked(linked: boolean) {
    if (this.disposed || this.linked === linked) return;
    this.linked = linked;
    this.epoch++;
    this.chain = Promise.resolve();
    this.peer = '';
    this.local = randomId(this.options.random);
    this.status = linked ? 'verifying' : 'waiting';
    this.problem = null;
    this.attempts.clear();
    this.messages.forEach(m => { if (m.direction === 'out' && m.status !== 'delivered') m.status = 'queued'; });
    if (linked) this.hello();
    this.publish();
  }
  private hello() {
    this.lastHello = this.now();
    this.transmit({ v: 1, t: 'hello', session: this.local, name: this.options.name });
  }
  receive(base64: string) {
    if (this.disposed || !this.linked) return;
    let p: Packet;
    try { p = this.codec.decode(base64); } catch { return; } // Unauthenticated traffic never changes chat state.
    if (p.session === this.local) return;
    if (p.t === 'hello') {
      this.transmit({ v: 1, t: 'welcome', session: this.local, name: this.options.name, replyTo: p.session });
      return;
    }
    if (p.t === 'welcome') {
      if (p.replyTo !== this.local) return;
      if (this.peer && this.peer !== p.session) return;
      const first = this.status !== 'connected';
      this.peer = p.session;
      this.peerName = p.name;
      this.lastSeen = this.now();
      this.status = 'connected';
      this.problem = null;
      if (first) {
        // Help the other side complete its challenge if its original hello was lost.
        this.hello();
        this.messages.filter(m => m.direction === 'out' && m.status !== 'delivered').forEach(m => this.deliver(m));
      }
      this.publish();
      return;
    }
    if (this.status !== 'connected' || p.session !== this.peer || p.peer !== this.local) return;
    this.lastSeen = this.now();
    if (p.t === 'message') {
      if (!this.seen.has(p.id)) {
        // Never evict deduplication IDs mid-session; bound total messages instead.
        if (this.messages.length >= 1000) { this.problem = 'Chat is full. Start a fresh chat to continue.'; this.publish(); return; }
        this.seen.add(p.id);
        this.messages.push({ id: p.id, text: p.text, at: this.now(), direction: 'in', status: 'delivered' });
      }
      this.transmit({ v: 1, t: 'ack', session: this.local, peer: this.peer, id: p.id });
      this.publish();
    } else if (p.t === 'ack') {
      const m = this.messages.find(m => m.id === p.id && m.direction === 'out');
      if (m) { m.status = 'delivered'; this.attempts.delete(m.id); this.publish(); }
    } else if (p.t === 'ping') {
      this.transmit({ v: 1, t: 'pong', session: this.local, peer: this.peer });
    }
  }
  send(text: string): string {
    text = text.trim();
    if (!text || text.length > MAX_TEXT) throw new Error(`Messages must contain 1–${MAX_TEXT} characters.`);
    if (this.messages.length >= 1000) throw new Error('Chat is full. Start a fresh chat to continue.');
    const m: ChatMessage = { id: randomId(this.options.random), text, at: this.now(), direction: 'out', status: 'queued' };
    this.messages.push(m);
    if (this.status === 'connected') this.deliver(m);
    this.publish();
    return m.id;
  }
  private deliver(m: ChatMessage) {
    const old = this.attempts.get(m.id);
    this.attempts.set(m.id, { count: (old?.count ?? 0) + 1, time: this.now() });
    m.status = 'sending';
    const p: Message = { v: 1, t: 'message', session: this.local, peer: this.peer, id: m.id, text: m.text, at: m.at };
    this.transmit(p);
  }
  retry(id: string) {
    const m = this.messages.find(m => m.id === id && m.direction === 'out');
    if (!m || m.status === 'delivered') return;
    this.attempts.delete(id);
    m.status = 'queued';
    if (this.status === 'connected') this.deliver(m);
    this.publish();
  }
  tick() {
    if (this.disposed || !this.linked) return;
    const now = this.now();
    if (this.status !== 'connected') {
      if (now - this.lastHello >= 2000) this.hello();
      return;
    }
    if (now - this.lastSeen > 25000) {
      this.setLinked(false);
      this.problem = 'Your partner stopped responding. Tap Reconnect on both phones.';
      this.publish();
      return;
    }
    if (now - this.lastPing > 7000) { this.lastPing = now; this.transmit({ v: 1, t: 'ping', session: this.local, peer: this.peer }); }
    for (const m of this.messages) {
      if (m.direction !== 'out' || m.status !== 'sending') continue;
      const attempt = this.attempts.get(m.id);
      if (!attempt || now - attempt.time < 6000) continue;
      if (attempt.count >= 3) { m.status = 'retry'; this.publish(); }
      else { this.deliver(m); this.publish(); }
    }
  }
  clearHistory() {
    this.messages = [];
    this.attempts.clear();
    // Keep received IDs so a late retry cannot restore a cleared message.
    this.publish();
  }
  dispose() { this.disposed = true; this.linked = false; this.epoch++; }
}
