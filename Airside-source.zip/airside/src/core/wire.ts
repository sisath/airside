import { xchacha20poly1305 } from '@noble/ciphers/chacha.js';
import { sha256 } from '@noble/hashes/sha2.js';
import { bytesToHex, concatBytes, utf8ToBytes } from '@noble/hashes/utils.js';
import { fromByteArray, toByteArray } from 'base64-js';

export type RandomBytes = (length: number) => Uint8Array;
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // 32 symbols; no 0/O/1/I.
export const MAX_TEXT = 1000;
export const MAX_PACKET = 8192;
export function normaliseCode(code: string): string { return code.toUpperCase().replace(/[\s-]/g, ''); }
export function validCode(code: string): boolean { return /^[A-HJ-NP-Z2-9]{20}$/.test(normaliseCode(code)); }
export function createCode(random: RandomBytes): string {
  return Array.from(random(20), b => ALPHABET[b & 31]).join('');
}
export function formatCode(code: string): string { return normaliseCode(code).match(/.{1,5}/g)?.join('-') ?? ''; }
export function roomUUID(code: string): string {
  const h = bytesToHex(sha256(utf8ToBytes(`airside-discovery-v1:${normaliseCode(code)}`))).slice(0, 32);
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}
export function randomId(random: RandomBytes): string { return bytesToHex(random(16)); }

export type Hello = { v: 1; t: 'hello'; session: string; name: string };
export type Welcome = { v: 1; t: 'welcome'; session: string; name: string; replyTo: string };
export type Message = { v: 1; t: 'message'; session: string; peer: string; id: string; text: string; at: number };
export type Ack = { v: 1; t: 'ack'; session: string; peer: string; id: string };
export type Ping = { v: 1; t: 'ping' | 'pong'; session: string; peer: string };
export type Packet = Hello | Welcome | Message | Ack | Ping;
const idOK = (x: unknown): x is string => typeof x === 'string' && /^[a-f0-9]{32}$/.test(x);
export function parsePacket(value: unknown): Packet {
  if (!value || typeof value !== 'object') throw new Error('Invalid packet');
  const p = value as Record<string, unknown>;
  if (p.v !== 1 || !idOK(p.session)) throw new Error('Unsupported packet');
  if (p.t === 'hello' || p.t === 'welcome') {
    if (typeof p.name !== 'string' || p.name.length < 1 || p.name.length > 32) throw new Error('Invalid name');
    if (p.t === 'welcome' && !idOK(p.replyTo)) throw new Error('Invalid challenge');
  } else {
    if (!idOK(p.peer)) throw new Error('Invalid peer');
    if (p.t === 'message' || p.t === 'ack') {
      if (!idOK(p.id)) throw new Error('Invalid message ID');
      if (p.t === 'message' && (typeof p.text !== 'string' || !p.text.trim() || p.text.length > MAX_TEXT || typeof p.at !== 'number' || !Number.isSafeInteger(p.at) || p.at < 0)) throw new Error('Invalid message');
    } else if (p.t !== 'ping' && p.t !== 'pong') throw new Error('Unknown packet');
  }
  return p as unknown as Packet;
}

export class WireCodec {
  private readonly key: Uint8Array;
  constructor(code: string, private readonly random: RandomBytes) {
    if (!validCode(code)) throw new Error('Enter all 20 characters of the pairing code.');
    this.key = sha256(utf8ToBytes(`airside-encryption-v1:${normaliseCode(code)}`));
  }
  encode(packet: Packet): string {
    parsePacket(packet);
    const nonce = this.random(24);
    const encrypted = xchacha20poly1305(this.key, nonce, utf8ToBytes('airside-v1')).encrypt(utf8ToBytes(JSON.stringify(packet)));
    const bytes = concatBytes(nonce, encrypted);
    if (bytes.length > MAX_PACKET) throw new Error('Message is too large');
    return fromByteArray(bytes);
  }
  decode(base64: string): Packet {
    if (base64.length > Math.ceil(MAX_PACKET / 3) * 4) throw new Error('Packet too large');
    const bytes = toByteArray(base64);
    if (bytes.length < 41 || bytes.length > MAX_PACKET) throw new Error('Invalid packet length');
    const plain = xchacha20poly1305(this.key, bytes.slice(0, 24), utf8ToBytes('airside-v1')).decrypt(bytes.slice(24));
    return parsePacket(JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(plain)));
  }
}
