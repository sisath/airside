import { Platform } from 'react-native';
import * as SecureStore from 'expo-secure-store';
import { createRecentChats } from '../core/recent-chats';
export type { RecentChat } from '../core/recent-chats';
const history = createRecentChats({
  getItemAsync: key => Platform.OS === 'web' ? Promise.resolve(null) : SecureStore.getItemAsync(key),
  setItemAsync: (key, value) => Platform.OS === 'web' ? Promise.resolve() : SecureStore.setItemAsync(key, value, { keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY }),
  deleteItemAsync: key => Platform.OS === 'web' ? Promise.resolve() : SecureStore.deleteItemAsync(key),
});
export const { loadRecentChats, rememberChat } = history;
