import * as SecureStore from 'expo-secure-store';
import { AndroidImportance } from 'expo-notifications';
import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
Notifications.setNotificationHandler({ handleNotification: async () => ({ shouldShowBanner: true, shouldShowList: true, shouldPlaySound: true, shouldSetBadge: false }) });
export async function enableAlerts(): Promise<boolean> {
  if (Platform.OS === 'android') await Notifications.setNotificationChannelAsync('room-messages', { name: "Room Messages", importance: AndroidImportance.DEFAULT });
  const permissions = await Notifications.requestPermissionsAsync(); return permissions.granted;
}
export async function notifyMessage(name: string) {
  const permission = await Notifications.getPermissionsAsync(); if (!permission.granted) return;
  // No message contents, code or media are copied into the notification tray.
  await Notifications.scheduleNotificationAsync({ content: { title: 'CloseBy', body: `${name} Sent A Message`, sound: true }, trigger: null });
}
export async function clearAlerts() { await Notifications.dismissAllNotificationsAsync(); }

export async function getAlertPreference(code: string): Promise<boolean> { return (await SecureStore.getItemAsync('closeby.alerts.' + code)) !== 'off'; }
export async function setAlertPreference(code: string, enabled: boolean): Promise<boolean> {
  const allowed = enabled ? await enableAlerts() : false;
  await SecureStore.setItemAsync('closeby.alerts.' + code, allowed ? 'on' : 'off');
  return allowed;
}
