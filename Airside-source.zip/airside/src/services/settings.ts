import type { RoomMode } from '../core/room-wire';
import { Platform } from 'react-native';
import * as SecureStore from 'expo-secure-store';
export type Settings = { name: string; code: string; mode?: RoomMode };
const KEY = 'airside.settings.v1';
export async function loadSettings(): Promise<Settings> {
  if (Platform.OS === 'web') return { name: '', code: '' };
  const raw = await SecureStore.getItemAsync(KEY);
  if (!raw) return { name: '', code: '' };
  try {
    const value = JSON.parse(raw);
    return { name: typeof value.name === 'string' ? value.name.slice(0, 32) : '', code: typeof value.code === 'string' ? value.code : '', mode: value.mode === 'create' ? 'create' : 'join' };
  } catch { return { name: '', code: '' }; }
}
export async function saveSettings(settings: Settings) {
  if (Platform.OS === 'web') return;
  await SecureStore.setItemAsync(KEY, JSON.stringify(settings), { keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY });
}
export async function forgetSettings() {
  if (Platform.OS !== 'web') await SecureStore.deleteItemAsync(KEY);
}
