export type TransportState = { status: string; message?: string };
export interface Transport {
  start(uuid: string): Promise<void>;
  send(base64: string): Promise<void>;
  stop(): Promise<void>;
  dispose(): void;
}
export type TransportHandlers = { status: (state: TransportState) => void; packet: (data: string) => void };
