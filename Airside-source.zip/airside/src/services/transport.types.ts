import type { RoomMode } from '../core/room-wire';
export type TransportState = { status: string; message?: string; peer?: string };
export interface Transport {
  start(uuid: string, mode: RoomMode): Promise<void>;
  send(base64: string, peer: string): Promise<void>;
  stop(): Promise<void>;
  dispose(): void;
}
export type TransportHandlers = { status: (state: TransportState) => void; packet: (data: string, peer: string) => void };
