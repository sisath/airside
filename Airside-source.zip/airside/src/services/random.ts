import * as Crypto from 'expo-crypto';

// Call the secure primitive directly. getRandomBytes has a Math.random fallback
// in some development/debugger configurations; pairing keys must never use it.
export function secureRandom(length: number): Uint8Array {
  return Crypto.getRandomValues(new Uint8Array(length));
}
