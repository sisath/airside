// TypeScript resolves this file; Metro selects transport.native.ts on phones.
import type { Transport, TransportHandlers } from './transport.types';
export function createTransport(_handlers: TransportHandlers): Transport {
  throw new Error("Bluetooth Messaging Requires The Installed iPhone Or Android App. Use Try The Demo To Explore The Design In A Browser.");
}
