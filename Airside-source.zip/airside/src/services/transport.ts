// TypeScript resolves this file; Metro selects transport.native.ts on phones.
import type { Transport, TransportHandlers } from './transport.types';
export function createTransport(_handlers: TransportHandlers): Transport {
  throw new Error('Bluetooth messaging requires the installed iPhone or Android app. Use Try the demo to explore the design in a browser.');
}
