import { NativeModule, requireOptionalNativeModule } from 'expo-modules-core';
import { PermissionsAndroid, Platform } from 'react-native';
import type { Transport, TransportHandlers } from './transport.types';
type Events = { onStatus: (value: { status: string; message: string }) => void; onPacket: (value: { payload: string }) => void };
declare class AirsideNative extends NativeModule<Events> {
  start(uuid: string): Promise<void>;
  send(payload: string): Promise<void>;
  stop(): Promise<void>;
}
export function createTransport(handlers: TransportHandlers): Transport {
  const native = requireOptionalNativeModule<AirsideNative>('AirsideBluetooth');
  if (!native) throw new Error('Bluetooth needs the installed Airside app. It is not available inside Expo Go.');
  const listeners = [native.addListener('onStatus', handlers.status), native.addListener('onPacket', event => handlers.packet(event.payload))];
  return {
    async start(uuid) {
      if (Platform.OS === 'android') {
        const permissions = Number(Platform.Version) >= 31
          ? [PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN, PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT]
          : [PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION];
        const result = await PermissionsAndroid.requestMultiple(permissions);
        if (permissions.some(p => result[p] !== PermissionsAndroid.RESULTS.GRANTED)) throw new Error('Allow Nearby devices access to connect. You can change this in Settings > Apps > Airside > Permissions.');
      }
      await native.start(uuid);
    },
    send: payload => native.send(payload),
    stop: () => native.stop(),
    dispose: () => listeners.forEach(l => l.remove()),
  };
}
