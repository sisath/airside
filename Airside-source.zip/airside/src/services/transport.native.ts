import type { RoomMode } from '../core/room-wire';
import { NativeModule, requireOptionalNativeModule } from 'expo-modules-core';
import { PermissionsAndroid, Platform } from 'react-native';
import type { Transport, TransportHandlers } from './transport.types';
type Events = { onStatus: (value: { status: string; message: string; peer?: string }) => void; onPacket: (value: { payload: string; peer: string }) => void };
declare class AirsideNative extends NativeModule<Events> {
  start(uuid: string, mode: RoomMode): Promise<void>;
  send(payload: string, peer: string): Promise<void>;
  stop(): Promise<void>;
}
export function createTransport(handlers: TransportHandlers): Transport {
  const native = requireOptionalNativeModule<AirsideNative>('AirsideBluetooth');
  if (!native) throw new Error("Bluetooth Needs The Installed CloseBy App. It Is Not Available Inside Expo Go.");
  const listeners = [native.addListener('onStatus', handlers.status), native.addListener('onPacket', event => handlers.packet(event.payload, event.peer))];
  return {
    async start(uuid, mode) {
      if (Platform.OS === 'android') {
        const permissions = Number(Platform.Version) >= 31
          ? [PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN, PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT, ...(mode === 'create' ? [PermissionsAndroid.PERMISSIONS.BLUETOOTH_ADVERTISE] : [])]
          : [PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION];
        const result = await PermissionsAndroid.requestMultiple(permissions);
        if (permissions.some(p => result[p] !== PermissionsAndroid.RESULTS.GRANTED)) throw new Error('Allow Nearby devices access to connect. You can change this in Settings > Apps > CloseBy > Permissions.');
      }
      await native.start(uuid, mode);
    },
    send: (payload, peer) => native.send(payload, peer),
    stop: () => native.stop(),
    dispose: () => listeners.forEach(l => l.remove()),
  };
}
