import { Directory, File, Paths } from 'expo-file-system';
import * as SecureStore from 'expo-secure-store';
import { fromByteArray, toByteArray } from 'base64-js';
import { sealChat, openChat, type SavedChat } from '../core/chat-archive';
import { validRoomCode } from '../core/room-code';
import type { RoomMode } from '../core/room-wire';
import { secureRandom } from './random';
const directory = () => new Directory(Paths.document, 'closeby-chats');
const label = (code: string, mode: RoomMode) => {
  if (!validRoomCode(code)) throw Error('Invalid saved room code.');
  return code + '-' + mode;
};
const keyName = (id: string) => 'closeby.archive.' + id;
let queue: Promise<unknown> = Promise.resolve();
function serial<T>(action: () => Promise<T>): Promise<T> { const task = queue.then(action); queue = task.catch(() => {}); return task; }
async function remove(id: string) {
  // Delete the per-room key first so an interrupted cleanup still removes access.
  await SecureStore.deleteItemAsync(keyName(id));
  const file = new File(directory(), id + '.json'); if (file.exists) file.delete();
  const pending = new File(directory(), id + '.next'); if (pending.exists) pending.delete();
}
export function loadArchive(code: string, mode: RoomMode): Promise<SavedChat | null> { return serial(async () => {
  const id = label(code, mode), file = new File(directory(), id + '.json');
  const pending = new File(directory(), id + '.next');
  if (!file.exists && !pending.exists) return null;
  const key = await SecureStore.getItemAsync(keyName(id));
  if (!key) { await remove(id); return null; }
  for (const candidate of [pending, file]) if (candidate.exists) {
    try { const chat = openChat(await candidate.text(), toByteArray(key), id); if (!chat) { await remove(id); return null; } return chat; }
    catch { /* A write interrupted before completion can fall back to the previous save. */ }
  }
  await remove(id); throw Error('Saved chat could not be verified.');
}); }
export function saveArchive(code: string, mode: RoomMode, chat: SavedChat): Promise<void> { return serial(async () => {
  const id = label(code, mode); if (chat.room.expiresAt <= Date.now()) { await remove(id); return; }
  let encoded = await SecureStore.getItemAsync(keyName(id));
  if (!encoded) { encoded = fromByteArray(secureRandom(32)); await SecureStore.setItemAsync(keyName(id), encoded, { keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY }); }
  const dir = directory(); dir.create({ intermediates: true, idempotent: true });
  const pending = new File(dir, id + '.next'), file = new File(dir, id + '.json');
  pending.write(sealChat(chat, toByteArray(encoded), id, secureRandom));
  if (file.exists) file.delete(); pending.move(file);
}); }
export function deleteArchive(code: string, mode: RoomMode) { return serial(() => remove(label(code, mode))); }
export function pruneArchives() { return serial(async () => {
  const dir = directory(); if (!dir.exists) return;
  const ids = new Set(dir.list().filter(file => file instanceof File && /^[A-Z]{3}[0-9]{3}-(create|join)\.(json|next)$/.test(file.name)).map(file => file.name.slice(0, -5)));
  for (const id of ids) {
    let live = false;
    for (const extension of ['next', 'json']) {
      const file = new File(dir, id + '.' + extension); if (!file.exists) continue;
      try { if (JSON.parse(await file.text()).expiresAt > Date.now()) live = true; } catch { /* Try the previous completed save. */ }
    }
    if (!live) await remove(id);
  }
}); }
