import { Platform, Vibration } from 'react-native';
export function pulseHeart() { Vibration.vibrate(Platform.OS === 'ios' ? [0, 140] : [0, 160, 120, 160], false); }
