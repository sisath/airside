import { useState } from 'react';
import { setAudioModeAsync, useAudioPlayer, useAudioPlayerStatus } from 'expo-audio';
import type { Attachment } from '../core/media';
import { attachmentURI } from './media';
export function useRoomPlayback() {
  const player = useAudioPlayer(null), status = useAudioPlayerStatus(player), [id, setId] = useState('');
  const toggle = async (a: Attachment) => {
    if (id === a.id && status.playing) { player.pause(); return; }
    // iOS resets omitted audio mode fields; explicitly restore audible playback.
    await setAudioModeAsync({ allowsRecording: false, playsInSilentMode: true, shouldRouteThroughEarpiece: false, shouldPlayInBackground: false, interruptionMode: 'doNotMix' });
    if (id !== a.id) { player.replace({ uri: attachmentURI(a) }); setId(a.id); }
    else if (status.didJustFinish || (status.duration > 0 && status.currentTime >= status.duration)) await player.seekTo(0);
    player.play();
  };
  return { playingId: status.playing ? id : '', toggle };
}
