import { File, Directory, Paths } from 'expo-file-system';
import * as ImagePicker from 'expo-image-picker';
import { ImageManipulator, SaveFormat } from 'expo-image-manipulator';
import { toByteArray } from 'base64-js';
import type { Attachment } from '../core/media';
const directory = () => new Directory(Paths.cache, 'closeby-room-media');
const managed = new Set<string>();
export async function initialiseMedia() {
  const dir = directory(); if (dir.exists) dir.delete(); dir.create({ intermediates: true, idempotent: true });
  // Recordings are transient; startup also removes leftovers after interruption.
  for (const folder of ['Audio', 'ExpoAudio']) { const d = new Directory(Paths.cache, folder); if (d.exists) for (const entry of d.list()) if (entry instanceof File && entry.name.startsWith('closeby-')) entry.delete(); }
}
export async function clearMedia() {
  for (const uri of managed) { try { const f = new File(uri); if (f.exists && uri.startsWith(Paths.cache.uri)) f.delete(); } catch { /* Retry on next launch. */ } }
  managed.clear(); const d = directory(); if (d.exists) d.delete();
}
export async function pickPhoto(): Promise<Uint8Array | null> {
  const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], allowsMultipleSelection: false, quality: 1, exif: false });
  if (result.canceled || !result.assets[0]) return null;
  const asset = result.assets[0];
  try {
    const context = ImageManipulator.manipulate(asset.uri);
    context.resize(asset.width >= asset.height ? { width: Math.min(480, asset.width) } : { height: Math.min(480, asset.height) });
    const image = await context.renderAsync();
    const output = await image.saveAsync({ format: SaveFormat.JPEG, compress: 0.45 });
    managed.add(output.uri);
    const outputFile = new File(output.uri);
    const bytes = await outputFile.bytes(); outputFile.delete(); managed.delete(output.uri);
    if (bytes.length > 64 * 1024) throw Error('This image is too detailed for Bluetooth. Choose a smaller photo.');
    return bytes;
  } finally {
    if (asset.uri.startsWith(Paths.cache.uri)) { try { new File(asset.uri).delete(); } catch { /* Startup clears managed files. */ } }
  }
}
export async function readVoice(uri: string): Promise<Uint8Array> {
  if (!uri.startsWith(Paths.cache.uri)) throw Error('Recording is outside the app cache.');
  managed.add(uri); const file = new File(uri), bytes = await file.bytes(); file.delete(); managed.delete(uri); return bytes;
}
export function discardVoice(uri: string | null) { if (!uri || !uri.startsWith(Paths.cache.uri)) return; try { const f = new File(uri); if (f.exists) f.delete(); } catch { /* Startup purges leftover recordings. */ } }
export function attachmentURI(a: Attachment): string {
  if (a.kind === 'photo') return `data:image/jpeg;base64,${a.base64}`;
  const dir = directory(); dir.create({ intermediates: true, idempotent: true });
  const f = new File(dir, `${a.id}.m4a`); if (!f.exists) f.write(toByteArray(a.base64)); managed.add(f.uri); return f.uri;
}
