import type { SavedChat } from '../core/chat-archive';
import type { RoomMode } from '../core/room-wire';
const rooms = new Map<string, SavedChat>();
export async function loadArchive(code: string, mode: RoomMode) { return rooms.get(code + mode) ?? null; }
export async function saveArchive(code: string, mode: RoomMode, chat: SavedChat) { rooms.set(code + mode, structuredClone(chat)); }
export async function deleteArchive(code: string, mode: RoomMode) { rooms.delete(code + mode); }
export async function pruneArchives() { for (const [id, chat] of rooms) if (chat.room.expiresAt <= Date.now()) rooms.delete(id); }
