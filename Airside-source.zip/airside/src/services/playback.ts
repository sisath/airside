import { useEffect, useRef, useState } from 'react';
import type { Attachment } from '../core/media';
export function useRoomPlayback() {
  const audio = useRef<HTMLAudioElement | null>(null), [playingId, setPlaying] = useState('');
  useEffect(() => () => { audio.current?.pause(); }, []);
  const toggle = async (a: Attachment) => {
    if (playingId === a.id) { audio.current?.pause(); setPlaying(''); return; }
    audio.current?.pause(); const player = new Audio(`data:${a.mime};base64,${a.base64}`); audio.current = player;
    player.onended = () => setPlaying(''); await player.play(); setPlaying(a.id);
  };
  return { playingId, toggle };
}
