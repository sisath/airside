export async function enableAlerts(): Promise<boolean> { return false; }
export async function notifyMessage(_name: string) {}
export async function clearAlerts() {}

const preferences = new Map<string, boolean>();
export async function getAlertPreference(code: string) { return preferences.get(code) ?? true; }
export async function setAlertPreference(code: string, enabled: boolean) { preferences.set(code, enabled); return enabled; }
