export async function enableAlerts(): Promise<boolean> { return false; }
export async function notifyMessage(_name: string) {}
export async function clearAlerts() {}
