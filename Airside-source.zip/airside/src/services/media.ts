import type { Attachment } from '../core/media';
export async function initialiseMedia() {}
export async function clearMedia() {}
export async function pickPhoto(): Promise<Uint8Array | null> { throw Error("Photo Selection Is Available In The Installed App."); }
export async function readVoice(_uri: string): Promise<Uint8Array> { throw Error("Voice Recording Is Available In The Installed App."); }
export function discardVoice(_uri: string | null) {}
export function attachmentURI(a: Attachment): string { return `data:${a.mime};base64,${a.base64}`; }

export async function recordVideo(): Promise<{ bytes: Uint8Array; durationMs: number } | null> { throw Error("Video Recording Is Available In The Installed App."); }
