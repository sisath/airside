import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import { AppState } from 'react-native';
import { RoomSession, type RoomSnapshot } from '../core/room';
import { type RoomMode, roomServiceUUID } from '../core/room-wire';
import { createCode, normaliseCode } from '../core/wire';
import { createTransport } from '../services/transport';
import type { Transport } from '../services/transport.types';
import { saveSettings } from '../services/settings';
import { secureRandom } from '../services/random';

const EMPTY: RoomSnapshot = { status: 'waiting', members: [], messages: [], problem: null };
type ContextValue = {
  chat: RoomSnapshot; running: boolean; demo: boolean; code: string; name: string; mode: RoomMode; bluetooth: string; error: string | null; backgrounded: boolean;
  start(name: string, code: string, mode: RoomMode): Promise<boolean>; startDemo(): Promise<void>; reconnect(): Promise<void>; end(): Promise<void>;
  send(text: string): void; retry(id: string): void; clear(): void;
};
const Context = createContext<ContextValue | null>(null);
export function ChatProvider({ children }: { children: React.ReactNode }) {
  const [chat, setChat] = useState(EMPTY), [running, setRunning] = useState(false), [demo, setDemo] = useState(false);
  const [code, setCode] = useState(''), [name, setName] = useState(''), [mode, setMode] = useState<RoomMode>('create');
  const [bluetooth, setBluetooth] = useState('idle'), [error, setError] = useState<string | null>(null), [backgrounded, setBackgrounded] = useState(false);
  const session = useRef<RoomSession | null>(null), transport = useRef<Transport | null>(null);
  const demoPeers = useRef<RoomSession[]>([]), timers = useRef<ReturnType<typeof setTimeout>[]>([]);
  const active = useRef(false), starting = useRef(false), generation = useRef(0);
  const config = useRef({ name: '', code: '', mode: 'create' as RoomMode });
  const cleanup = async () => {
    active.current = false; generation.current++;
    timers.current.forEach(clearTimeout); timers.current = [];
    session.current?.dispose(); session.current = null; demoPeers.current.forEach(p => p.dispose()); demoPeers.current = [];
    const old = transport.current; transport.current = null;
    try { await old?.stop(); } catch { /* Still dispose subscriptions. */ } old?.dispose();
  };
  useEffect(() => {
    const interval = setInterval(() => { session.current?.tick(); demoPeers.current.forEach(p => p.tick()); }, 1000);
    const listener = AppState.addEventListener('change', value => setBackgrounded(value !== 'active'));
    return () => { clearInterval(interval); listener.remove(); void cleanup(); };
  }, []);
  const start = async (displayName: string, pairingCode: string, roomMode: RoomMode) => {
    if (starting.current) return false;
    starting.current = true; await cleanup(); setError(null); setChat(EMPTY); setDemo(false);
    try {
      const userName = displayName.trim().slice(0, 32), clean = normaliseCode(pairingCode);
      if (!userName) throw Error('Enter your name first.');
      const epoch = generation.current;
      const value = new RoomSession({ code: clean, name: userName, mode: roomMode, random: secureRandom, changed: setChat,
        send: (payload, peer) => transport.current ? transport.current.send(payload, peer) : Promise.reject(Error('Bluetooth is not started')) });
      session.current = value; active.current = true;
      transport.current = createTransport({
        status: event => {
          if (!active.current || epoch !== generation.current) return;
          setBluetooth(event.status);
          if (event.status === 'linked') { value.link(event.peer || 'host', true); setError(null); }
          else if (event.status === 'disconnected') value.link(event.peer || 'host', false);
          else if (['error', 'poweredOff', 'idle'].includes(event.status) && roomMode === 'join') value.link('host', false);
          if (event.message) setError(event.message);
          else if (['advertising', 'scanning', 'connecting'].includes(event.status)) setError(null);
        }, packet: (payload, peer) => { if (active.current && epoch === generation.current) value.receive(payload, peer); },
      });
      await transport.current.start(roomServiceUUID(clean), roomMode);
      await saveSettings({ name: userName, code: clean, mode: roomMode });
      config.current = { name: userName, code: clean, mode: roomMode };
      setName(userName); setCode(clean); setMode(roomMode); setRunning(true); setChat(value.snapshot()); return true;
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not start Bluetooth.'); await cleanup(); setRunning(false); return false; }
    finally { starting.current = false; }
  };
  const startDemo = async () => {
    if (starting.current) return;
    starting.current = true; await cleanup();
    try {
      const demoCode = createCode(secureRandom);
      const schedule = (action: () => void, delay: number) => { timers.current.push(setTimeout(action, delay)); };
      const clients: RoomSession[] = [];
      const host = new RoomSession({ code: demoCode, name: 'You', mode: 'create', random: secureRandom, changed: setChat,
        send: async (payload, peer) => { schedule(() => clients[Number(peer)]?.receive(payload, 'host'), 10); } });
      ['Alex', 'Sam'].forEach((peerName, i) => {
        let received = 0;
        const client = new RoomSession({ code: demoCode, name: peerName, mode: 'join', random: secureRandom,
          changed: state => { const n = state.messages.filter(m => m.direction === 'in' && m.name === 'You').length;
            if (n > received) { received = n; schedule(() => client.send(i === 0 ? 'Message received!' : 'Same here — connected nearby.'), 800 + i * 500); } },
          send: async payload => { schedule(() => host.receive(payload, String(i)), 10); } });
        clients.push(client);
      });
      session.current = host; demoPeers.current = clients; active.current = true;
      setDemo(true); setError(null); setName('You'); setCode(demoCode); setMode('create'); setRunning(true); setBluetooth('demo');
      clients.forEach(p => p.link('host', true)); schedule(() => clients[0].send('Welcome to the group!'), 700);
      setChat(host.snapshot());
    } finally { starting.current = false; }
  };
  const reconnect = async () => {
    if (demo || starting.current) return;
    const saved = config.current, value = session.current, link = transport.current;
    if (!value || !link) return;
    starting.current = true; setError(null); value.resetLinks();
    try { await link.stop(); await link.start(roomServiceUUID(saved.code), saved.mode); }
    catch (e) { setError(e instanceof Error ? e.message : 'Could not reconnect.'); }
    finally { starting.current = false; }
  };
  const end = async () => { await cleanup(); setRunning(false); setChat(EMPTY); setDemo(false); setBluetooth('idle'); setError(null); };
  const send = (text: string) => { try { session.current?.send(text); } catch (e) { setError(e instanceof Error ? e.message : 'Could not send.'); } };
  return <Context.Provider value={{ chat, running, demo, name, code, mode, bluetooth, error, backgrounded, start, startDemo, reconnect, end, send, retry: id => session.current?.retry(id), clear: () => session.current?.clearHistory() }}>{children}</Context.Provider>;
}
export function useChat() { const ctx = useContext(Context); if (!ctx) throw Error('Missing ChatProvider'); return ctx; }
