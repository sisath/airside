import { toByteArray } from 'base64-js';
import { DEMO_PHOTO } from '../ui/demo-photo';
import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import { AppState } from 'react-native';
import { RoomSession, type RoomSnapshot, type RoomMessage } from '../core/room';
import { type RoomMode, roomServiceUUID } from '../core/room-wire';
import { normaliseCode } from '../core/wire';
import { createTransport } from '../services/transport';
import type { Transport } from '../services/transport.types';
import { saveSettings, clearSavedRoom } from '../services/settings';
import { SecureLinks, type JoinRequest } from '../core/secure-links';
import { createRoomCode, ROOM_LIFETIME } from '../core/room-code';
import { MediaAssembler, splitMedia, type Attachment, type MediaKind, type MediaChunk } from '../core/media';
import { initialiseMedia, clearMedia } from '../services/media';
import { notifyMessage, clearAlerts } from '../services/alerts';
import { secureRandom } from '../services/random';

export type DisplayMessage = RoomMessage & { attachment?: Attachment; progress?: number };
export type DisplaySnapshot = Omit<RoomSnapshot, 'messages'> & { messages: DisplayMessage[] };
const EMPTY: DisplaySnapshot = { status: 'waiting', expiresAt: 0, typing: [], members: [], messages: [], problem: null };
type ContextValue = {
  chat: DisplaySnapshot; pending: JoinRequest[]; verification: string; alert: string; transfer: number | null; running: boolean; demo: boolean; code: string; name: string; mode: RoomMode; bluetooth: string; error: string | null; backgrounded: boolean;
  start(name: string, code: string, mode: RoomMode, expiresAt?: number): Promise<boolean>; startDemo(): Promise<void>; reconnect(): Promise<void>; end(): Promise<void>;
  approve(peer: string): void; reject(peer: string): void; typing(active: boolean): void; sendAttachment(bytes: Uint8Array, kind: MediaKind, durationMs?: number): Promise<void>; cancelTransfer(): void;
  send(text: string): void; retry(id: string): void; clear(): void;
};
const Context = createContext<ContextValue | null>(null);
export function ChatProvider({ children }: { children: React.ReactNode }) {
  const [chat, setChat] = useState(EMPTY), [running, setRunning] = useState(false), [demo, setDemo] = useState(false);
  const [code, setCode] = useState(''), [name, setName] = useState(''), [mode, setMode] = useState<RoomMode>('create');
  const [bluetooth, setBluetooth] = useState('idle'), [error, setError] = useState<string | null>(null), [backgrounded, setBackgrounded] = useState(false);
  const [pending, setPending] = useState<JoinRequest[]>([]), [verification, setVerification] = useState(''), [alert, setAlert] = useState(''), [transfer, setTransfer] = useState<number | null>(null);
  const secure = useRef<SecureLinks | null>(null), assembler = useRef(new MediaAssembler());
  const transferBusy = useRef(false);
  const mediaEpoch = useRef(0), alerted = useRef(new Set<string>()), latest = useRef<RoomSnapshot>({ ...EMPTY });
  const outgoing = useRef(new Map<string, { chunks: MediaChunk[]; ids: string[] }>());
  const waiting = useRef(new Map<string, { resolve(): void; reject(error: Error): void; timer: ReturnType<typeof setTimeout> }>());
  const endingExpired = useRef(false);
  const update = (state: RoomSnapshot) => {
    latest.current = state;
    const messages: DisplayMessage[] = [], groups = new Map<string, DisplayMessage>();
    for (const m of state.messages) {
      if (!m.media) messages.push(m);
      else {
        const logical = `media:${m.author}:${m.media.id}`;
        let entry = groups.get(logical);
        if (!entry) { entry = { ...m, id: logical, progress: 0 }; groups.set(logical, entry); messages.push(entry); }
        try { const received = assembler.current.accept(m.author, m.media, m.at); entry.progress = received.progress; entry.attachment = received.attachment; } catch { entry.status = 'retry'; entry.text = 'Attachment could not be verified.'; }
        if (m.status !== 'delivered') entry.status = m.status;
      }
      const waiter = waiting.current.get(m.id);
      if (waiter && (m.status === 'delivered' || m.status === 'retry')) { clearTimeout(waiter.timer); waiting.current.delete(m.id); if (m.status === 'delivered') waiter.resolve(); else waiter.reject(Error('Attachment delivery was interrupted. Tap Retry.')); }
    }
    for (const m of groups.values()) if ((m.progress ?? 0) < 1) { if (m.direction === 'out' && !transferBusy.current) m.status = 'retry'; else if (m.status === 'delivered') m.status = 'sending'; }
    for (const m of messages) if (m.direction === 'in' && (!m.media || m.attachment) && !alerted.current.has(m.id)) {
      alerted.current.add(m.id); setAlert(`${m.name} sent ${m.media ? m.media.kind === 'photo' ? 'a photo' : 'a voice message' : 'a message'}`); void notifyMessage(m.name).catch(() => {});
    }
    setChat({ ...state, messages });
    if (state.status === 'expired' && !endingExpired.current) { endingExpired.current = true; setAlert('Room expired after 24 hours'); void cleanup().then(async () => { await clearSavedRoom(); await clearAlerts(); }); }
  };
  const session = useRef<RoomSession | null>(null), transport = useRef<Transport | null>(null);
  const demoPeers = useRef<RoomSession[]>([]), timers = useRef<ReturnType<typeof setTimeout>[]>([]);
  const active = useRef(false), starting = useRef(false), generation = useRef(0);
  const config = useRef({ name: '', code: '', mode: 'create' as RoomMode });
  const cancelTransfer = () => { mediaEpoch.current++; transferBusy.current = false; for (const w of waiting.current.values()) { clearTimeout(w.timer); w.reject(Error('Transfer cancelled')); } waiting.current.clear(); setTransfer(null); };
  const cleanup = async () => {
    cancelTransfer(); secure.current?.dispose(); secure.current = null; assembler.current.clear(); outgoing.current.clear(); alerted.current.clear(); setPending([]); setVerification('');
    try { await clearMedia(); } catch { /* Startup retries temporary-file cleanup. */ }
    active.current = false; generation.current++;
    timers.current.forEach(clearTimeout); timers.current = [];
    session.current?.dispose(); session.current = null; demoPeers.current.forEach(p => p.dispose()); demoPeers.current = [];
    const old = transport.current; transport.current = null;
    try { await old?.stop(); } catch { /* Still dispose subscriptions. */ } old?.dispose();
  };
  useEffect(() => {
    void initialiseMedia().catch(() => setError('Could not prepare temporary media storage.'));
    const interval = setInterval(() => { secure.current?.tick(); assembler.current.prune(Date.now()); session.current?.tick(); demoPeers.current.forEach(p => p.tick()); }, 1000);
    const listener = AppState.addEventListener('change', value => { setBackgrounded(value !== 'active'); session.current?.tick(); });
    return () => { clearInterval(interval); listener.remove(); void cleanup(); };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps -- interval and unmount cleanup use stable refs
  const start = async (displayName: string, pairingCode: string, roomMode: RoomMode, savedExpiry?: number) => {
    if (starting.current) return false;
    starting.current = true; await cleanup(); setError(null); setChat(EMPTY); setDemo(false); setAlert(''); endingExpired.current = false;
    try {
      const userName = displayName.trim().slice(0, 32), clean = normaliseCode(pairingCode);
      if (!userName) throw Error('Enter your name first.');
      const epoch = generation.current, expiresAt = roomMode === 'create' ? savedExpiry ?? Date.now() + ROOM_LIFETIME : 0;
      if (expiresAt && expiresAt <= Date.now()) throw Error('This room has expired. Generate a new code.');
      const value = new RoomSession({ code: clean, name: userName, mode: roomMode, random: secureRandom, expiresAt, changed: update,
        send: (payload, peer) => secure.current ? secure.current.send(payload, peer) : Promise.reject(Error('Bluetooth is not started')) });
      session.current = value; active.current = true;
      secure.current = new SecureLinks({ mode: roomMode, code: clean, name: userName, expiresAt, random: secureRandom,
        send: (payload, peer) => transport.current ? transport.current.send(payload, peer) : Promise.reject(Error('Bluetooth is not started')),
        packet: (payload, peer) => value.receive(payload, peer), linked: (peer, connected) => value.link(peer, connected),
        changed: (requests, number) => { if (epoch === generation.current) { setPending(roomMode === 'create' ? requests : []); setVerification(number); } },
        expiry: deadline => { value.setExpiry(deadline); void saveSettings({ name: userName, code: clean, mode: roomMode, expiresAt: deadline }); },
      });
      transport.current = createTransport({
        status: event => {
          if (!active.current || epoch !== generation.current) return;
          setBluetooth(event.status);
          if (event.status === 'linked') { secure.current?.link(event.peer || 'host', true); setError(null); }
          else if (event.status === 'disconnected') secure.current?.link(event.peer || 'host', false);
          else if (['error', 'poweredOff', 'idle'].includes(event.status) && roomMode === 'join') secure.current?.link('host', false);
          if (event.message) setError(event.message);
          else if (['advertising', 'scanning', 'connecting'].includes(event.status)) setError(null);
        }, packet: (payload, peer) => { if (active.current && epoch === generation.current) secure.current?.receive(payload, peer); },
      });
      await transport.current.start(roomServiceUUID(clean), roomMode);
      await saveSettings({ name: userName, code: clean, mode: roomMode, expiresAt });
      config.current = { name: userName, code: clean, mode: roomMode };
      setName(userName); setCode(clean); setMode(roomMode); setRunning(true); update(value.snapshot()); return true;
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not start Bluetooth.'); await cleanup(); setRunning(false); return false; }
    finally { starting.current = false; }
  };
  const startDemo = async () => {
    if (starting.current) return;
    starting.current = true; await cleanup();
    try {
      const demoCode = createRoomCode(secureRandom); endingExpired.current = false;
      const schedule = (action: () => void, delay: number) => { timers.current.push(setTimeout(action, delay)); };
      const clients: RoomSession[] = [];
      const host = new RoomSession({ code: demoCode, name: 'You', mode: 'create', random: secureRandom, changed: update,
        send: async (payload, peer) => { schedule(() => clients[Number(peer)]?.receive(payload, 'host'), 10); } });
      ['S', 'W'].forEach((peerName, i) => {
        let received = 0;
        const client = new RoomSession({ code: demoCode, name: peerName, mode: 'join', random: secureRandom,
          changed: state => { const n = state.messages.filter(m => m.direction === 'in' && m.name === 'You' && !m.media).length;
            if (n > received) { received = n; schedule(() => client.send(i === 0 ? 'Message received!' : 'Same here — connected nearby.'), 800 + i * 500); } },
          send: async payload => { schedule(() => host.receive(payload, String(i)), 10); } });
        clients.push(client);
      });
      session.current = host; demoPeers.current = clients; active.current = true;
      setDemo(true); setError(null); setName('You'); setCode(demoCode); setMode('create'); setRunning(true); setBluetooth('demo');
      clients.forEach(p => p.link('host', true)); schedule(() => clients[0].send('Welcome to the group!'), 700);
      schedule(() => { for (const chunk of splitMedia(toByteArray(DEMO_PHOTO), 'photo', secureRandom)) clients[0].send('', chunk); }, 1200);
      update(host.snapshot());
    } finally { starting.current = false; }
  };
  const reconnect = async () => {
    if (demo || starting.current) return;
    const saved = config.current, value = session.current, link = transport.current;
    if (!value || !link) return;
    starting.current = true; setError(null); cancelTransfer(); value.resetLinks();
    try { await link.stop(); await link.start(roomServiceUUID(saved.code), saved.mode); }
    catch (e) { setError(e instanceof Error ? e.message : 'Could not reconnect.'); }
    finally { starting.current = false; }
  };
  const end = async () => { await cleanup(); setRunning(false); setChat(EMPTY); setDemo(false); setBluetooth('idle'); setError(null); };
  const waitFor = (id: string) => new Promise<void>((resolve, reject) => {
    if (latest.current.messages.find(m => m.id === id)?.status === 'delivered') { resolve(); return; }
    const timer = setTimeout(() => { waiting.current.delete(id); session.current?.markRetry(id); reject(Error('Bluetooth transfer timed out. Tap Retry while everyone is connected.')); }, 180000);
    waiting.current.set(id, { resolve, reject, timer });
  });
  const runTransfer = async (item: { chunks: MediaChunk[]; ids: string[] }) => {
    if (transferBusy.current) throw Error('Finish the current transfer first.');
    const value = session.current; if (!value || value.snapshot().status !== 'connected') throw Error('Connect to the room before sending media.');
    const epoch = mediaEpoch.current; transferBusy.current = true; setTransfer(0); value.setTyping(false);
    try { for (let i = 0; i < item.chunks.length; i++) {
      if (epoch !== mediaEpoch.current) throw Error('Transfer cancelled');
      let id = item.ids[i];
      if (id) { if (latest.current.messages.find(m => m.id === id)?.status !== 'delivered') value.retry(id); }
      else { id = value.send('', item.chunks[i]); item.ids[i] = id; }
      await waitFor(id); if (epoch !== mediaEpoch.current) throw Error('Transfer cancelled'); setTransfer((i + 1) / item.chunks.length);
    } } finally { if (epoch === mediaEpoch.current) { transferBusy.current = false; setTransfer(null); } }
  };
  const sendAttachment = async (bytes: Uint8Array, kind: MediaKind, durationMs?: number) => {
    if (outgoing.current.size >= 50 || Array.from(outgoing.current.values()).reduce((n, item) => n + item.chunks[0].size, 0) + bytes.length > 4 * 1024 * 1024) throw Error('Room media storage is full. Clear the chat to continue.');
    const chunks = splitMedia(bytes, kind, secureRandom, durationMs), item = { chunks, ids: [] as string[] };
    outgoing.current.set(chunks[0].id, item); await runTransfer(item);
  };
  const retry = (id: string) => {
    if (id.startsWith('media:')) { const item = outgoing.current.get(id.split(':')[2]); if (item) void runTransfer(item).catch(e => setError(e.message)); }
    else session.current?.retry(id);
  };
  const clear = () => { cancelTransfer(); assembler.current.clear(); outgoing.current.clear(); session.current?.clearHistory(); void clearMedia(); void clearAlerts(); };
  const send = (text: string) => { try { session.current?.send(text); } catch (e) { setError(e instanceof Error ? e.message : 'Could not send.'); } };
  return <Context.Provider value={{ chat, running, demo, name, code, mode, bluetooth, error, backgrounded, pending, verification, alert, transfer, start, startDemo, reconnect, end, send, sendAttachment, cancelTransfer, typing: flag => session.current?.setTyping(flag), approve: peer => secure.current?.approve(peer), reject: peer => secure.current?.reject(peer), retry, clear }}>{children}</Context.Provider>;
}
export function useChat() { const ctx = useContext(Context); if (!ctx) throw Error('Missing ChatProvider'); return ctx; }
