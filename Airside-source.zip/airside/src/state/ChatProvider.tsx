import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { AppState, Platform } from 'react-native';
import { ChatSession, type SessionSnapshot } from '../core/session';
import { createCode, roomUUID, normaliseCode } from '../core/wire';
import { createTransport } from '../services/transport';
import type { Transport } from '../services/transport.types';
import { saveSettings } from '../services/settings';
import { secureRandom } from '../services/random';

const EMPTY: SessionSnapshot = { status: 'waiting', peerName: '', messages: [], problem: null };
const random = secureRandom;
type ContextValue = {
  chat: SessionSnapshot; running: boolean; demo: boolean; code: string; name: string; bluetooth: string; error: string | null; backgrounded: boolean;
  start(name: string, code: string): Promise<boolean>; startDemo(): Promise<void>; reconnect(): Promise<void>; end(): Promise<void>;
  send(text: string): void; retry(id: string): void; clear(): void;
};
const Context = createContext<ContextValue | null>(null);
export function ChatProvider({ children }: { children: React.ReactNode }) {
  const [chat, setChat] = useState(EMPTY);
  const [running, setRunning] = useState(false);
  const [demo, setDemo] = useState(false);
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [bluetooth, setBluetooth] = useState('idle');
  const [error, setError] = useState<string | null>(null);
  const [backgrounded, setBackgrounded] = useState(false);
  const session = useRef<ChatSession | null>(null);
  const transport = useRef<Transport | null>(null);
  const other = useRef<ChatSession | null>(null);
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);
  const active = useRef(false);
  const starting = useRef(false);
  const config = useRef({ name: '', code: '' });
  const cleanup = useCallback(async () => {
    active.current = false;
    timers.current.forEach(clearTimeout); timers.current = [];
    session.current?.dispose(); session.current = null;
    other.current?.dispose(); other.current = null;
    const old = transport.current; transport.current = null;
    try { await old?.stop(); } catch { /* disposal still releases subscriptions */ }
    old?.dispose();
  }, []);
  useEffect(() => {
    const interval = setInterval(() => { session.current?.tick(); other.current?.tick(); }, 1000);
    const listener = AppState.addEventListener('change', value => setBackgrounded(value !== 'active'));
    return () => { clearInterval(interval); listener.remove(); void cleanup(); };
  }, [cleanup]);
  const start = async (displayName: string, pairingCode: string) => {
    if (starting.current) return false;
    starting.current = true;
    await cleanup();
    setError(null); setChat(EMPTY); setDemo(false);
    try {
      const userName = displayName.trim().slice(0, 32);
      if (!userName) throw new Error('Enter your name first.');
      const clean = normaliseCode(pairingCode);
      const value = new ChatSession({ code: clean, name: userName, random, changed: setChat, send: payload => {
        if (!transport.current) return Promise.reject(new Error('Bluetooth is not started'));
        return transport.current.send(payload);
      } });
      session.current = value;
      active.current = true;
      transport.current = createTransport({
        status: event => {
          if (!active.current) return;
          setBluetooth(event.status);
          if (event.status === 'linked') { value.setLinked(true); setError(null); }
          else {
            if (['disconnected', 'idle', 'error', 'poweredOff'].includes(event.status)) value.setLinked(false);
            if (event.message) setError(event.message);
            else if (['advertising', 'scanning', 'connecting'].includes(event.status)) setError(null);
          }
        },
        packet: payload => value.receive(payload),
      });
      await saveSettings({ name: userName, code: clean });
      await transport.current.start(roomUUID(clean));
      config.current = { name: userName, code: clean };
      setName(userName); setCode(clean); setRunning(true);
      return true;
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not start Bluetooth.');
      await cleanup(); setRunning(false);
      return false;
    } finally { starting.current = false; }
  };
  const startDemo = async () => {
    if (starting.current) return;
    starting.current = true;
    await cleanup();
    const demoCode = createCode(random);
    let previousReceived = 0;
    const schedule = (action: () => void, delay: number) => { const t = setTimeout(action, delay); timers.current.push(t); };
    const local = new ChatSession({ code: demoCode, name: 'You', random, changed: setChat, send: async payload => { schedule(() => other.current?.receive(payload), 40); } });
    const replies = ['The clouds look like marshmallows ☁️', 'This is so much better than waving across the aisle 🤍', 'Snack trolley update: I’m ready 🍪'];
    const remote = new ChatSession({ code: demoCode, name: 'Your person', random, changed: state => {
      const received = state.messages.filter(m => m.direction === 'in').length;
      if (received > previousReceived) { previousReceived = received; schedule(() => other.current?.send(replies[(received - 1) % replies.length]), 900); }
    }, send: async payload => { schedule(() => session.current?.receive(payload), 40); } });
    session.current = local; other.current = remote; active.current = true;
    setDemo(true); setError(null); setName('You'); setCode(demoCode); setRunning(true); setBluetooth('demo');
    local.setLinked(true); remote.setLinked(true);
    schedule(() => remote.send('Did you get the window seat? 👀'), 500);
    starting.current = false;
  };
  const reconnect = async () => {
    if (demo) return;
    const value = session.current, link = transport.current;
    if (!value || !link || starting.current) return;
    starting.current = true;
    setError(null); value.setLinked(false);
    try { await link.stop(); await link.start(roomUUID(config.current.code)); }
    catch (e) { setError(e instanceof Error ? e.message : 'Could not reconnect.'); }
    finally { starting.current = false; }
  };
  const end = async () => { await cleanup(); setRunning(false); setChat(EMPTY); setDemo(false); setBluetooth('idle'); setError(null); };
  const send = (text: string) => { try { session.current?.send(text); } catch (e) { setError(e instanceof Error ? e.message : 'Could not send.'); } };
  return <Context.Provider value={{ chat, running, demo, name, code, bluetooth, error, backgrounded, start, startDemo, reconnect, end, send, retry: id => session.current?.retry(id), clear: () => session.current?.clearHistory() }}>{children}</Context.Provider>;
}
export function useChat() { const ctx = useContext(Context); if (!ctx) throw new Error('Missing ChatProvider'); return ctx; }
export const isHost = Platform.OS === 'ios';
