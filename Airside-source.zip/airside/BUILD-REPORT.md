# CloseBy 1.3 verification

Implemented encrypted per-room history, restoration after demo/switch/relaunch, saved partial transfers, explicit retry of unconfirmed restored messages, key deletion on clear/expiry, and system-camera video recording/playback (5s / 1MB).

49 protocol/archive/media tests pass. Typecheck, lint and browser walkthrough pass. Android and iPhone native build status is recorded with the delivered artifacts. Physical camera recording, native storage recovery, audio/video playback and multi-phone Bluetooth transfers remain unverified on hardware. Existing history discarded by earlier versions cannot be recovered.
