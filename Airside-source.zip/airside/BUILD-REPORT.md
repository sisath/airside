# CloseBy 1.1 validation status

This source replaces the original two-person Airside interface and protocol with code-based rooms.

Implemented: Create a chat / Join a chat on either platform; per-room 100-bit invitation code; up to eight software participants; owner-relayed encrypted text; participant roster and sender names; application-level group acknowledgements; retries and duplicate suppression; secure settings storage; explicit foreground/owner dependency; three-person solo demo.

Checks completed on Windows: TypeScript typecheck; ESLint; 31 protocol/cryptography tests; static web export; browser walkthrough of create/join, group demo, sender replies, delivery, 390px/320px layouts, dark mode, clear and end chat. Android Kotlin hosting/joining compiled. A complete ARM64 release build passed after shortening the Gradle cache path and archiving stale Ninja dependency caches. Its 24 native libraries were checked against the previous working package; the same development signing certificate was verified.

The final iPhone group build is being checked through the GitHub macOS workflow. A successful build of the original Airside app is not proof that this new Swift implementation compiles. Record the final cloud run outcome separately before treating an IPA as current.

No physical group-room test has been performed. Test each iPhone/Android owner/joiner combination, disconnects, owner loss and practical simultaneous connection limits before relying on it. Eight is the app limit, not a measured hardware guarantee. Android phones without BLE advertising can join but cannot host. Calls, media, internet transport, background notifications, identity verification, owner migration and late-join history are not implemented.

The source ZIP contains no generated native projects, build caches, Apple credentials or signing secrets. Identifiers retain the original com.airside.privatechat value for update continuity. The unsigned IPA output keeps the legacy Airside-unsigned.ipa filename for compatibility with the existing public repository workflow. Display name: CloseBy.
