# Airside build report

Prepared 15 November 2026.

## Free iPhone build workflow added

The source now includes a manually triggered GitHub Actions workflow, an unsigned physical-iPhone Release build script, and FREE-IPHONE-INSTALL.md. It targets a standard macos-26 runner and does not request Apple credentials or signing secrets. This workflow has not yet run against the user's account; it does not establish that an IPA exists or that iOS compilation passed. Installation uses a separate local Windows signing tool with a free Apple account and its seven-day provisioning limit.

## Delivered

- `Airside-android-test.apk`: standalone Android personal-test build, version 1.0.0, application ID `com.airside.privatechat`.
- `Airside-source.zip`: shared app source, native Bluetooth module sources for both platforms, lockfile, tests, assets, and documentation. Dependencies and generated platform build folders are excluded; run `npm ci` then Expo prebuild to regenerate them.
- Installation guide and screenshots from the running browser demo.

The APK is 37,392,574 bytes and supports ARM64 devices running Android 7/API 24 or newer. It targets API 36 and was compiled with API 37. It is signed with a development key for personal installation, not a production Play Store key. The JavaScript bundle is embedded; no Metro server is required.

SHA-256 of the delivered APK:

```text
7390BAE3C51B83DEA33298EC1F9A4DDF5ECE71D7A92B91318FA24900FE5ACC4A
```

## Checks passed

- TypeScript strict type checking.
- Expo ESLint checks.
- 17 protocol/crypto tests: random code formatting, deterministic room discovery, authenticated encryption, tamper/wrong-key rejection, Unicode, packet validation, two-way delivery, offline queues, lost acknowledgements, bounded retries, reconnects, old-session replay rejection, clear-history duplicate suppression, heartbeat timeouts, and disposal.
- Expo Doctor: all 20 checks passed.
- Production web export.
- Automated Chromium walkthrough: start demo, receive greeting, send text, receive simulated response, verify delivery, clear composer, check 390px/320px layouts and dark mode, clear history, and leave demo. No browser runtime errors. Screenshots visually inspected.
- Full Android release compilation, including the Kotlin Bluetooth module and C++ native dependencies. The final JavaScript update was rebuilt using the unchanged native C++ libraries from that successful full build.
- APK signature verified with Android `apksigner` (v2 signature).
- APK archive inspected: native Airside Bluetooth class, embedded JavaScript, and 24 ARM64 native libraries are present.
- Merged Android manifest inspected: BLE permissions and old-Android location permission are declared; microphone, contacts, and photo permissions are not requested by the app.
- Apple native autolinking resolves the local AirsideBluetooth pod and Swift module.

## Still needs your devices/account

**The iPhone app has not been compiled, signed, or installed.** This Windows session has no Xcode or Apple signing identity. The Swift source and build configuration are supplied, with instructions for a free Personal Team build on a Mac or a paid Apple Developer / Expo cloud device build.

**Physical Bluetooth interoperability remains untested.** No iPhone or Samsung was connected. Software tests and APK compilation cannot confirm radio behaviour, real range, Samsung permission behaviour, background suspension, or battery consumption. Complete the two-phone checklist in INSTALL.md before relying on it on a flight.

The browser demo uses the real encryption/session protocol with a simulated partner; it does not exercise the Bluetooth radio. The app is designed for foreground text chat with both displays awake. Calls, attachments, durable history, read receipts, and background notifications are not included.

## Build environment notes

Node 24, Expo SDK 58, React Native 0.88.1, Java 21, Android Gradle/SDK/NDK/CMake tooling were used on Windows. Windows native-build path limits were worked around using a local short CMake staging path and object-path hashing; no system registry settings were changed. Expo account authentication was not available, so the APK was built locally; no project was uploaded and no store publication occurred.

The dependency audit reported moderate glob-matching issues in Expo/ESLint build tooling, with no high or critical findings. An automatic suggested downgrade of Expo was not applied. These build tools do not process chat packets in the installed app.

Message encryption is implemented using Noble's cipher primitives and operating-system secure randomness, including in development builds. The application itself has not had an independent security audit and does not provide forward secrecy.
