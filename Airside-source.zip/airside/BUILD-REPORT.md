# CloseBy 1.2 build verification

Implemented: six-character room invitations; owner-approved X25519 links and comparison numbers; 24-hour room expiry with local cleanup; typing indicators; local received-message alerts; compressed photos; 15-second AAC voice messages; bounded chunked transfers with integrity checks, cancellation and retry.

Checks: 44 protocol/crypto/media tests pass, including complete approved-room delivery, wrong codes, replayed frames, expiry boundaries, group media acknowledgements, typing timeout, checksum failures, attachment size limits and post-clear receipt behavior. TypeScript and lint pass. Browser create/join, group demo/photo display, text delivery, narrow layouts, dark mode, clear and end chat checks pass. Android native audio/photo/notification modules compiled in a complete release build. Final artifact checks are recorded separately when packaging completes.

Expo SDK 58 notification config explicitly disables remote notifications. Configuration introspection confirms no APNs entitlement, preserving free-account iPhone signing. Android's INTERNET permission is blocked; no push token registration or internet messaging is implemented.

Outstanding physical validation: cross-device Bluetooth group operation, microphone recording and AAC playback, picker/compression behavior, interruption/retry timing, notification permission/delivery behavior, long-duration expiry and app suspension. Software tests and cloud compilation do not establish these hardware behaviors. The custom connection protocol has not had an independent security audit; verification numbers must be compared, and names are not verified identities.

The owner relays all messages and must remain present. Data expiry is enforced while running or at next launch/resume if suspended. There is no background-delivery guarantee, remote erasure of other apps' saved copies, internet fallback, owner migration, late-join history, video or general file transfer.
