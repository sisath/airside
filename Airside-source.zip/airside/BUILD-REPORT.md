# CloseBy 1.4 Verification

Implemented title-cased app labels, logo-to-chats navigation, minimal room menu with actual version, default-on per-room alerts, participant sheet, icon-only media toolbar and group heart/custom-heart messages. Encrypted history and original expiry remain intact.

51 protocol/archive/media/heart tests pass. Typecheck, lint and browser UI walkthrough pass. Browser tests cover group participants, heart/custom heart UI, unmodified user text, default alerts and toggling, code reveal, local clearing, home navigation and ending a chat at mobile widths and dark mode. Native vibration, notification permission behavior and multi-phone interoperability still require physical-phone testing.
