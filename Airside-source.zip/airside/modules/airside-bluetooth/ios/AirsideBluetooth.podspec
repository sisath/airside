Pod::Spec.new do |s|
  s.name = 'AirsideBluetooth'
  s.version = '1.0.0'
  s.summary = 'Direct BLE text transport for Airside'
  s.description = 'iOS peripheral role for an offline two-phone messenger.'
  s.license = { :type => 'MIT' }
  s.author = 'Airside'
  s.homepage = 'https://example.com/airside'
  s.platforms = { :ios => '16.4' }
  s.source = { :git => '' }
  s.static_framework = true
  s.dependency 'ExpoModulesCore'
  s.source_files = '**/*.{h,m,mm,swift}'
  s.frameworks = 'CoreBluetooth'
  s.swift_version = '5.0'
end
