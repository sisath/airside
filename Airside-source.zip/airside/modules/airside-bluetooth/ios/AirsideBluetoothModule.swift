import ExpoModulesCore
@preconcurrency import CoreBluetooth

private let rxUUID = CBUUID(string: "F0A10002-4F24-4B45-9C13-7A1500000001")
private let txUUID = CBUUID(string: "F0A10003-4F24-4B45-9C13-7A1500000001")
private typealias RoomEventSink = (String, [String: Any]) -> Void

// Both engines and every callback run on the main queue.
public class AirsideBluetoothModule: Module {
  private var host: RoomPeripheral?
  private var guest: RoomCentral?
  public func definition() -> ModuleDefinition {
    Name("AirsideBluetooth")
    Events("onStatus", "onPacket")
    AsyncFunction("start") { (uuid: String, mode: String) in
      self.host?.stop(); self.guest?.stop(); self.host = nil; self.guest = nil
      guard UUID(uuidString: uuid) != nil else { throw NSError(domain: "CloseBy", code: 1, userInfo: [NSLocalizedDescriptionKey: "Invalid room identifier"]) }
      let event: RoomEventSink = { [weak self] event, value in self?.sendEvent(event, value) }
      if mode == "create" { let h = RoomPeripheral(event); self.host = h; h.start(uuid) }
      else { let c = RoomCentral(event); self.guest = c; c.start(uuid) }
    }.runOnQueue(.main)
    AsyncFunction("send") { (payload: String, peer: String, promise: Promise) in
      if let host = self.host { host.send(payload, peer, promise) }
      else if let guest = self.guest { guest.send(payload, promise) }
      else { promise.reject("NOT_STARTED", "Open a room first") }
    }.runOnQueue(.main)
    AsyncFunction("stop") { self.host?.stop(); self.guest?.stop(); self.host = nil; self.guest = nil }.runOnQueue(.main)
    OnDestroy { let h = self.host, g = self.guest; DispatchQueue.main.async { h?.stop(); g?.stop() } }
  }
}

private final class FrameReader {
  private var bytes = Data()
  private var expected: Int?
  private var timer: Timer?
  func clear() { bytes.removeAll(); expected = nil; timer?.invalidate(); timer = nil }
  func receive(_ data: Data, packet: (Data) -> Void, invalid: @escaping () -> Void) {
    timer?.invalidate(); bytes.append(data)
    guard bytes.count <= 16392 else { clear(); invalid(); return }
    while true {
      if expected == nil {
        if bytes.count < 4 { break }
        let b = Array(bytes.prefix(4)); bytes.removeFirst(4)
        let n = (Int(b[0]) << 24) | (Int(b[1]) << 16) | (Int(b[2]) << 8) | Int(b[3])
        guard n > 0 && n <= 8192 else { clear(); invalid(); return }
        expected = n
      }
      guard let n = expected, bytes.count >= n else { break }
      let p = Data(bytes.prefix(n)); bytes.removeFirst(n); expected = nil; packet(p)
    }
    if expected != nil || !bytes.isEmpty {
      timer = Timer.scheduledTimer(withTimeInterval: 15, repeats: false) { [weak self] _ in self?.clear(); invalid() }
    }
  }
}
private func chunks(_ text: String, _ size: Int) -> [Data]? {
  guard let data = Data(base64Encoded: text), !data.isEmpty, data.count <= 8192 else { return nil }
  let n = data.count
  var frame = Data([UInt8((n >> 24) & 255), UInt8((n >> 16) & 255), UInt8((n >> 8) & 255), UInt8(n & 255)])
  frame.append(data)
  return stride(from: 0, to: frame.count, by: size).map { Data(frame[$0..<min($0 + size, frame.count)]) }
}

private final class RoomPeripheral: NSObject, CBPeripheralManagerDelegate, @unchecked Sendable {
  private var manager: CBPeripheralManager!
  private let event: RoomEventSink
  private var active = false
  private var room: CBUUID?
  private var tx: CBMutableCharacteristic?
  private var centrals: [String: CBCentral] = [:]
  private var readers: [String: FrameReader] = [:]
  private var target: String?
  private var output: [Data] = []
  private var promise: Promise?
  private var timer: Timer?
  init(_ event: @escaping RoomEventSink) { self.event = event; super.init(); manager = CBPeripheralManager(delegate: self, queue: .main) }
  private func status(_ s: String, _ message: String = "", peer: String = "") { event("onStatus", ["status": s, "message": message, "peer": peer]) }
  func start(_ uuid: String) { room = CBUUID(string: uuid); active = true; if manager.state == .poweredOn { install() } }
  func stop() {
    active = false
    if manager.state == .poweredOn { manager.stopAdvertising(); manager.removeAllServices() }
    readers.values.forEach { $0.clear() }; readers.removeAll(); centrals.removeAll(); fail("Room stopped"); tx = nil
  }
  private func install() {
    guard active, let room else { return }
    manager.stopAdvertising(); manager.removeAllServices()
    readers.values.forEach { $0.clear() }; readers.removeAll()
    for id in centrals.keys { status("disconnected", peer: id) }; centrals.removeAll(); fail("Bluetooth restarted")
    let rx = CBMutableCharacteristic(type: rxUUID, properties: [.write], value: nil, permissions: [.writeable])
    let tx = CBMutableCharacteristic(type: txUUID, properties: [.notify], value: nil, permissions: [])
    self.tx = tx
    let s = CBMutableService(type: room, primary: true); s.characteristics = [rx, tx]; manager.add(s)
  }
  func peripheralManagerDidUpdateState(_ peripheral: CBPeripheralManager) {
    if peripheral.state == .poweredOn { if active { install() }; return }
    for id in centrals.keys { status("disconnected", peer: id) }; centrals.removeAll()
    readers.values.forEach { $0.clear() }; readers.removeAll(); fail("Bluetooth disconnected")
    if active { status(peripheral.state == .poweredOff ? "poweredOff" : "error", "Bluetooth is unavailable. Enable Bluetooth access for CloseBy, then reconnect.") }
  }
  func peripheralManager(_ peripheral: CBPeripheralManager, didAdd service: CBService, error: Error?) {
    guard active, service.uuid == room else { return }
    if let error { status("error", error.localizedDescription); return }
    advertise()
  }
  private func advertise() {
    guard active, manager.state == .poweredOn, let room, !manager.isAdvertising else { return }
    // Keep advertising while clients are connected, allowing additional members.
    manager.startAdvertising([CBAdvertisementDataServiceUUIDsKey: [room]])
  }
  func peripheralManagerDidStartAdvertising(_ peripheral: CBPeripheralManager, error: Error?) {
    if active { if let error { status("error", error.localizedDescription) } else { status("advertising") } }
  }
  func peripheralManager(_ peripheral: CBPeripheralManager, central: CBCentral, didSubscribeTo characteristic: CBCharacteristic) {
    guard active, characteristic.uuid == txUUID else { return }
    let id = central.identifier.uuidString
    guard centrals[id] != nil || centrals.count < 7 else { return }
    readers[id]?.clear(); readers[id] = FrameReader(); centrals[id] = central
    status("linked", peer: id); advertise()
  }
  func peripheralManager(_ peripheral: CBPeripheralManager, central: CBCentral, didUnsubscribeFrom characteristic: CBCharacteristic) {
    let id = central.identifier.uuidString
    guard centrals.removeValue(forKey: id) != nil else { return }
    readers.removeValue(forKey: id)?.clear(); if target == id { fail("Participant disconnected") }
    status("disconnected", peer: id); advertise()
  }
  func peripheralManager(_ peripheral: CBPeripheralManager, didReceiveWrite requests: [CBATTRequest]) {
    guard let first = requests.first else { return }
    for r in requests {
      guard active, r.characteristic.uuid == rxUUID, readers[r.central.identifier.uuidString] != nil else { peripheral.respond(to: first, withResult: .writeNotPermitted); return }
      guard r.offset == 0, let v = r.value, !v.isEmpty else { peripheral.respond(to: first, withResult: .invalidOffset); return }
    }
    peripheral.respond(to: first, withResult: .success)
    for r in requests {
      let id = r.central.identifier.uuidString
      if let v = r.value { readers[id]?.receive(v, packet: { self.event("onPacket", ["payload": $0.base64EncodedString(), "peer": id]) }, invalid: { [weak self] in self?.status("error", "Incomplete message from a participant.") }) }
    }
  }
  func send(_ payload: String, _ peer: String, _ p: Promise) {
    guard active, let central = centrals[peer], tx != nil else { p.reject("DISCONNECTED", "Participant is not connected"); return }
    guard promise == nil else { p.reject("BUSY", "A transfer is in progress"); return }
    guard let data = chunks(payload, max(1, min(180, central.maximumUpdateValueLength))) else { p.reject("INVALID", "Invalid packet"); return }
    target = peer; output = data; promise = p
    timer = Timer.scheduledTimer(withTimeInterval: 20, repeats: false) { [weak self] _ in self?.fail("Transfer timed out") }
    drain()
  }
  private func drain() {
    guard let id = target, let central = centrals[id], let tx else { return }
    while let data = output.first {
      guard manager.updateValue(data, for: tx, onSubscribedCentrals: [central]) else { return }
      output.removeFirst()
    }
    timer?.invalidate(); timer = nil; target = nil; let p = promise; promise = nil; p?.resolve(nil)
  }
  func peripheralManagerIsReady(toUpdateSubscribers peripheral: CBPeripheralManager) { drain() }
  private func fail(_ reason: String) { timer?.invalidate(); timer = nil; output.removeAll(); target = nil; let p = promise; promise = nil; p?.reject("TRANSFER_FAILED", reason) }
}

private final class RoomCentral: NSObject, CBCentralManagerDelegate, CBPeripheralDelegate, @unchecked Sendable {
  private var manager: CBCentralManager!
  private let event: RoomEventSink
  private var active = false
  private var room: CBUUID?
  private var peripheral: CBPeripheral?
  private var rx: CBCharacteristic?
  private var ready = false
  private let reader = FrameReader()
  private var output: [Data] = []
  private var promise: Promise?
  private var timer: Timer?
  private var connectTimer: Timer?
  private var retryTimer: Timer?
  init(_ event: @escaping RoomEventSink) { self.event = event; super.init(); manager = CBCentralManager(delegate: self, queue: .main) }
  private func status(_ s: String, _ message: String = "") { event("onStatus", ["status": s, "message": message, "peer": "host"]) }
  func start(_ uuid: String) { room = CBUUID(string: uuid); active = true; if manager.state == .poweredOn { scan() } }
  func stop() { active = false; retryTimer?.invalidate(); connectTimer?.invalidate(); manager.stopScan(); close() }
  private func scan() {
    guard active, manager.state == .poweredOn, peripheral == nil, let room else { return }
    manager.scanForPeripherals(withServices: [room]); status("scanning")
  }
  func centralManagerDidUpdateState(_ central: CBCentralManager) {
    if central.state == .poweredOn { scan() }
    else { close(); if active { status(central.state == .poweredOff ? "poweredOff" : "error", "Bluetooth is unavailable. Enable Bluetooth access for CloseBy, then reconnect.") } }
  }
  func centralManager(_ central: CBCentralManager, didDiscover p: CBPeripheral, advertisementData: [String: Any], rssi RSSI: NSNumber) {
    guard active, peripheral == nil else { return }
    manager.stopScan(); peripheral = p; p.delegate = self; status("connecting"); manager.connect(p)
    connectTimer = Timer.scheduledTimer(withTimeInterval: 20, repeats: false) { [weak self] _ in self?.reconnect("Connection timed out. Looking for the room…") }
  }
  func centralManager(_ central: CBCentralManager, didConnect p: CBPeripheral) { guard active, p === peripheral, let room else { return }; p.discoverServices([room]) }
  func centralManager(_ central: CBCentralManager, didFailToConnect p: CBPeripheral, error: Error?) { if p === peripheral { reconnect("Could not connect. Retrying…") } }
  func centralManager(_ central: CBCentralManager, didDisconnectPeripheral p: CBPeripheral, error: Error?) { if p === peripheral { reconnect("Room owner disconnected. Searching nearby…") } }
  func peripheral(_ p: CBPeripheral, didDiscoverServices error: Error?) {
    guard active, p === peripheral else { return }
    guard error == nil, let service = p.services?.first(where: { $0.uuid == room }) else { reconnect("Room service unavailable."); return }
    p.discoverCharacteristics([rxUUID, txUUID], for: service)
  }
  func peripheral(_ p: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
    guard active, p === peripheral else { return }
    guard error == nil, let rx = service.characteristics?.first(where: { $0.uuid == rxUUID }), let tx = service.characteristics?.first(where: { $0.uuid == txUUID }) else { reconnect("Room characteristics unavailable."); return }
    self.rx = rx; p.setNotifyValue(true, for: tx)
  }
  func peripheral(_ p: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
    guard active, p === peripheral, characteristic.uuid == txUUID else { return }
    guard error == nil, characteristic.isNotifying else { reconnect("Could not subscribe to the room."); return }
    connectTimer?.invalidate(); ready = true; status("linked")
  }
  func peripheral(_ p: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
    guard active, p === peripheral, characteristic.uuid == txUUID, error == nil, let data = characteristic.value else { return }
    reader.receive(data, packet: { self.event("onPacket", ["payload": $0.base64EncodedString(), "peer": "host"]) }, invalid: { [weak self] in self?.reconnect("Incomplete Bluetooth message. Reconnecting…") })
  }
  func send(_ payload: String, _ p: Promise) {
    guard ready, let peripheral, rx != nil else { p.reject("DISCONNECTED", "Room owner is not connected"); return }
    guard promise == nil else { p.reject("BUSY", "A transfer is in progress"); return }
    guard let data = chunks(payload, max(1, min(180, peripheral.maximumWriteValueLength(for: .withResponse)))) else { p.reject("INVALID", "Invalid packet"); return }
    output = data; promise = p
    timer = Timer.scheduledTimer(withTimeInterval: 20, repeats: false) { [weak self] _ in self?.reconnect("Transfer timed out. Reconnecting…") }
    writeNext()
  }
  private func writeNext() {
    guard let peripheral, let rx else { return }
    guard let data = output.first else { timer?.invalidate(); timer = nil; let p = promise; promise = nil; p?.resolve(nil); return }
    peripheral.writeValue(data, for: rx, type: .withResponse)
  }
  func peripheral(_ p: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
    guard active, p === peripheral, characteristic.uuid == rxUUID, promise != nil else { return }
    if error != nil { reconnect("Bluetooth write failed. Reconnecting…"); return }
    if !output.isEmpty { output.removeFirst() }; writeNext()
  }
  private func close() {
    ready = false; rx = nil; reader.clear(); timer?.invalidate(); timer = nil; output.removeAll()
    let p = promise; promise = nil; p?.reject("DISCONNECTED", "Bluetooth disconnected")
    if let old = peripheral { peripheral = nil; old.delegate = nil; manager.cancelPeripheralConnection(old) }
  }
  private func reconnect(_ message: String) {
    connectTimer?.invalidate(); close(); guard active else { return }
    status("disconnected", message); retryTimer?.invalidate()
    retryTimer = Timer.scheduledTimer(withTimeInterval: 2, repeats: false) { [weak self] _ in self?.scan() }
  }
}

