import ExpoModulesCore
@preconcurrency import CoreBluetooth

// All peripheral state is used on the main queue, including Expo entry points.
public class AirsideBluetoothModule: Module {
  private var engine: AirsidePeripheral?
  public func definition() -> ModuleDefinition {
    Name("AirsideBluetooth")
    Events("onStatus", "onPacket")
    AsyncFunction("start") { (uuid: String) in
      if self.engine == nil {
        self.engine = AirsidePeripheral { [weak self] event, payload in self?.sendEvent(event, payload) }
      }
      try self.engine?.start(uuid)
    }.runOnQueue(.main)
    AsyncFunction("send") { (payload: String, promise: Promise) in
      guard let engine = self.engine else { promise.reject("NOT_STARTED", "Start a chat first"); return }
      engine.send(payload, promise)
    }.runOnQueue(.main)
    AsyncFunction("stop") {
      self.engine?.stop()
    }.runOnQueue(.main)
    OnDestroy {
      let engine = self.engine
      DispatchQueue.main.async { engine?.stop() }
    }
  }
}

private final class AirsidePeripheral: NSObject, CBPeripheralManagerDelegate, @unchecked Sendable {
  private let event: (String, [String: Any]) -> Void
  private var manager: CBPeripheralManager!
  private var serviceID: CBUUID?
  private let rxID = CBUUID(string: "F0A10002-4F24-4B45-9C13-7A1500000001")
  private let txID = CBUUID(string: "F0A10003-4F24-4B45-9C13-7A1500000001")
  private var rx: CBMutableCharacteristic?
  private var tx: CBMutableCharacteristic?
  private var central: CBCentral?
  private var active = false
  private var input = Data()
  private var expected: Int?
  private var output: [Data] = []
  private var sendPromise: Promise?
  private var sendTimer: Timer?
  private var readTimer: Timer?

  init(event: @escaping (String, [String: Any]) -> Void) {
    self.event = event
    super.init()
    manager = CBPeripheralManager(delegate: self, queue: .main)
  }
  private func status(_ value: String, _ message: String = "") { event("onStatus", ["status": value, "message": message]) }
  func start(_ uuid: String) throws {
    guard UUID(uuidString: uuid) != nil else { throw NSError(domain: "Airside", code: 1, userInfo: [NSLocalizedDescriptionKey: "Invalid room identifier"]) }
    stop()
    serviceID = CBUUID(string: uuid)
    active = true
    if manager.state == .poweredOn { installService() }
    else if manager.state == .poweredOff { status("poweredOff", "Turn Bluetooth on in Settings, then reconnect.") }
    else if manager.state == .unauthorized { status("error", "Allow Bluetooth access in Settings > Airside.") }
    else { status("starting") }
  }
  func stop() {
    active = false
    if manager.state == .poweredOn {
      manager.stopAdvertising()
      manager.removeAllServices()
    }
    central = nil
    rx = nil; tx = nil
    clearInput()
    failSend("Chat stopped")
    status("idle")
  }
  private func installService() {
    guard active, let serviceID else { return }
    manager.stopAdvertising()
    manager.removeAllServices()
    clearInput()
    let receive = CBMutableCharacteristic(type: rxID, properties: [.write], value: nil, permissions: [.writeable])
    let transmit = CBMutableCharacteristic(type: txID, properties: [.notify], value: nil, permissions: [])
    rx = receive; tx = transmit
    let service = CBMutableService(type: serviceID, primary: true)
    service.characteristics = [receive, transmit]
    manager.add(service)
  }
  func peripheralManagerDidUpdateState(_ peripheral: CBPeripheralManager) {
    if peripheral.state == .poweredOn { if active { installService() }; return }
    central = nil; clearInput(); failSend("Bluetooth disconnected")
    if !active { return }
    switch peripheral.state {
    case .poweredOff: status("poweredOff", "Turn Bluetooth on in Settings, then reconnect.")
    case .unauthorized: status("error", "Allow Bluetooth access in Settings > Airside.")
    case .unsupported: status("error", "This device does not support Bluetooth Low Energy.")
    default: status("disconnected", "Bluetooth is restarting.")
    }
  }
  func peripheralManager(_ peripheral: CBPeripheralManager, didAdd service: CBService, error: Error?) {
    guard active, service.uuid == serviceID else { return }
    if let error { status("error", error.localizedDescription); return }
    advertise()
  }
  private func advertise() {
    guard active, manager.state == .poweredOn, let serviceID else { return }
    guard !manager.isAdvertising else { return }
    manager.startAdvertising([CBAdvertisementDataServiceUUIDsKey: [serviceID], CBAdvertisementDataLocalNameKey: "Airside"])
  }
  func peripheralManagerDidStartAdvertising(_ peripheral: CBPeripheralManager, error: Error?) {
    guard active else { return }
    if let error { status("error", error.localizedDescription) } else { status("advertising") }
  }
  func peripheralManager(_ peripheral: CBPeripheralManager, central incoming: CBCentral, didSubscribeTo characteristic: CBCharacteristic) {
    guard active, characteristic.uuid == txID else { return }
    guard central == nil || central?.identifier == incoming.identifier else { return }
    central = incoming
    manager.stopAdvertising()
    clearInput()
    status("linked")
  }
  func peripheralManager(_ peripheral: CBPeripheralManager, central outgoing: CBCentral, didUnsubscribeFrom characteristic: CBCharacteristic) {
    guard central?.identifier == outgoing.identifier else { return }
    central = nil; clearInput(); failSend("Your partner disconnected")
    if active { status("disconnected"); advertise() }
  }
  func peripheralManager(_ peripheral: CBPeripheralManager, didReceiveWrite requests: [CBATTRequest]) {
    guard let first = requests.first else { return }
    for request in requests {
      guard active, request.characteristic.uuid == rxID, request.central.identifier == central?.identifier else {
        peripheral.respond(to: first, withResult: .writeNotPermitted); return
      }
      guard request.offset == 0, let value = request.value, !value.isEmpty else {
        peripheral.respond(to: first, withResult: .invalidOffset); return
      }
    }
    // CoreBluetooth expects one response for the entire write-request batch.
    peripheral.respond(to: first, withResult: .success)
    for request in requests { if let value = request.value { receive(value) } }
  }
  private func clearInput() { input.removeAll(); expected = nil; readTimer?.invalidate(); readTimer = nil }
  private func receive(_ data: Data) {
    readTimer?.invalidate()
    input.append(data)
    if input.count > 16392 { clearInput(); status("error", "Invalid Bluetooth data. Reconnect."); return }
    while true {
      if expected == nil {
        if input.count < 4 { break }
        let bytes = Array(input.prefix(4))
        let length = (Int(bytes[0]) << 24) | (Int(bytes[1]) << 16) | (Int(bytes[2]) << 8) | Int(bytes[3])
        input.removeFirst(4)
        guard length > 0 && length <= 8192 else { clearInput(); status("error", "Invalid Bluetooth frame. Reconnect."); return }
        expected = length
      }
      guard let count = expected, input.count >= count else { break }
      let packet = Data(input.prefix(count))
      input.removeFirst(count); expected = nil
      event("onPacket", ["payload": packet.base64EncodedString()])
    }
    if expected != nil || !input.isEmpty {
      readTimer = Timer.scheduledTimer(withTimeInterval: 15, repeats: false) { [weak self] _ in
        self?.clearInput(); self?.status("error", "An incomplete Bluetooth transfer timed out. Reconnect.")
      }
    }
  }
  func send(_ base64: String, _ promise: Promise) {
    guard active, central != nil, tx != nil else { promise.reject("DISCONNECTED", "Your partner is not connected"); return }
    guard sendPromise == nil else { promise.reject("BUSY", "A transfer is already in progress"); return }
    guard let data = Data(base64Encoded: base64), !data.isEmpty, data.count <= 8192 else { promise.reject("INVALID", "Invalid packet"); return }
    let n = data.count
    var frame = Data([UInt8((n >> 24) & 255), UInt8((n >> 16) & 255), UInt8((n >> 8) & 255), UInt8(n & 255)])
    frame.append(data)
    let size = max(1, min(180, central!.maximumUpdateValueLength))
    output = stride(from: 0, to: frame.count, by: size).map { Data(frame[$0..<min($0 + size, frame.count)]) }
    sendPromise = promise
    sendTimer = Timer.scheduledTimer(withTimeInterval: 20, repeats: false) { [weak self] _ in
      self?.failSend("Bluetooth transfer timed out")
      self?.status("error", "Bluetooth transfer timed out. Reconnect.")
    }
    drain()
  }
  private func drain() {
    guard let central, let tx else { return }
    while let first = output.first {
      if !manager.updateValue(first, for: tx, onSubscribedCentrals: [central]) { return }
      output.removeFirst()
    }
    sendTimer?.invalidate(); sendTimer = nil
    let promise = sendPromise; sendPromise = nil
    promise?.resolve(nil)
  }
  func peripheralManagerIsReady(toUpdateSubscribers peripheral: CBPeripheralManager) { drain() }
  private func failSend(_ reason: String) {
    sendTimer?.invalidate(); sendTimer = nil
    output.removeAll()
    let promise = sendPromise; sendPromise = nil
    promise?.reject("TRANSFER_FAILED", reason)
  }
}
