package expo.modules.airside

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.ParcelUuid
import android.util.Base64
import expo.modules.kotlin.Promise
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.util.UUID

@SuppressLint("MissingPermission")
internal class RoomHost(private val context: Context, private val handler: Handler, private val event: (String, Map<String, Any>) -> Unit) {
  private val rxID = UUID.fromString("f0a10002-4f24-4b45-9c13-7a1500000001")
  private val txID = UUID.fromString("f0a10003-4f24-4b45-9c13-7a1500000001")
  private val cccdID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
  private var server: BluetoothGattServer? = null
  private var adapter: BluetoothAdapter? = null
  private var tx: BluetoothGattCharacteristic? = null
  private var advertiser: BluetoothLeAdvertiser? = null
  private var room: UUID? = null
  private var active = false
  private val devices = mutableMapOf<String, BluetoothDevice>()
  private val inputs = mutableMapOf<String, ByteArrayOutputStream>()
  private val readTimers = mutableMapOf<String, Runnable>()
  private val sizes = mutableMapOf<String, Int>()
  private var promise: Promise? = null
  private var target: String? = null
  private var output: List<ByteArray> = emptyList()
  private var index = 0
  private val sendTimeout = Runnable { fail("Bluetooth transfer timed out") }
  private fun post(action: () -> Unit) { handler.post { if (active) try { action() } catch (_: SecurityException) { status("error", "Allow Nearby devices access for CloseBy.") } catch (e: Exception) { status("error", e.message ?: "Bluetooth interrupted") } } }
  private fun status(s: String, message: String = "", peer: String = "") = event("onStatus", mapOf("status" to s, "message" to message, "peer" to peer))
  fun start(uuid: UUID) {
    active = true; room = uuid
    val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    val adapter = manager.adapter; this.adapter = adapter
    if (adapter == null || !adapter.isEnabled) { status("poweredOff", "Turn Bluetooth on, then reconnect."); return }
    val advertiser = adapter.bluetoothLeAdvertiser
    if (advertiser == null) { status("error", "This Android phone cannot advertise Bluetooth rooms. Join a room from another phone instead."); return }
    this.advertiser = advertiser
    val gatt = manager.openGattServer(context, callback)
    if (gatt == null) { status("error", "Could not open the Bluetooth room."); return }
    server = gatt
    val rx = BluetoothGattCharacteristic(rxID, BluetoothGattCharacteristic.PROPERTY_WRITE, BluetoothGattCharacteristic.PERMISSION_WRITE)
    val tx = BluetoothGattCharacteristic(txID, BluetoothGattCharacteristic.PROPERTY_NOTIFY, 0)
    tx.addDescriptor(BluetoothGattDescriptor(cccdID, BluetoothGattDescriptor.PERMISSION_READ or BluetoothGattDescriptor.PERMISSION_WRITE))
    this.tx = tx
    val service = BluetoothGattService(uuid, BluetoothGattService.SERVICE_TYPE_PRIMARY)
    service.addCharacteristic(rx); service.addCharacteristic(tx)
    if (!gatt.addService(service)) status("error", "Could not publish the Bluetooth room.")
  }
  private val advertising = object : AdvertiseCallback() {
    override fun onStartSuccess(settingsInEffect: AdvertiseSettings) { post { status("advertising") } }
    override fun onStartFailure(errorCode: Int) { post { status("error", "Bluetooth room advertising failed ($errorCode). This device may not support hosting.") } }
  }
  private val callback = object : BluetoothGattServerCallback() {
    override fun onServiceAdded(status: Int, service: BluetoothGattService) { post {
      if (status != BluetoothGatt.GATT_SUCCESS || service.uuid != room) { this@RoomHost.status("error", "Room service could not be published."); return@post }
      val id = room ?: return@post
      advertiser?.startAdvertising(AdvertiseSettings.Builder().setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY).setConnectable(true).setTimeout(0).build(), AdvertiseData.Builder().addServiceUuid(ParcelUuid(id)).setIncludeDeviceName(false).build(), advertising)
    } }
    override fun onConnectionStateChange(device: BluetoothDevice, status: Int, newState: Int) { post {
      if (newState == BluetoothProfile.STATE_DISCONNECTED) remove(device.address)
    } }
    override fun onMtuChanged(device: BluetoothDevice, mtu: Int) { post { sizes[device.address] = minOf(180, maxOf(20, mtu - 3)) } }
    override fun onDescriptorReadRequest(device: BluetoothDevice, requestId: Int, offset: Int, descriptor: BluetoothGattDescriptor) { post {
      val data = if (devices.containsKey(device.address)) BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE else BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE
      server?.sendResponse(device, requestId, if (offset == 0 && descriptor.uuid == cccdID) BluetoothGatt.GATT_SUCCESS else BluetoothGatt.GATT_INVALID_OFFSET, offset, data)
    } }
    override fun onDescriptorWriteRequest(device: BluetoothDevice, requestId: Int, descriptor: BluetoothGattDescriptor, preparedWrite: Boolean, responseNeeded: Boolean, offset: Int, value: ByteArray) { val data = value.copyOf(); post {
      val id = device.address
      val enable = data.contentEquals(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
      val disable = data.contentEquals(BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE)
      val valid = descriptor.uuid == cccdID && !preparedWrite && offset == 0 && (enable || disable) && (!enable || devices.containsKey(id) || devices.size < 7)
      if (valid) {
        if (enable) { devices[id] = device; inputs[id] = ByteArrayOutputStream(); status("linked", peer = id) } else remove(id)
      }
      if (responseNeeded) server?.sendResponse(device, requestId, if (valid) BluetoothGatt.GATT_SUCCESS else BluetoothGatt.GATT_FAILURE, 0, null)
    } }
    override fun onCharacteristicWriteRequest(device: BluetoothDevice, requestId: Int, characteristic: BluetoothGattCharacteristic, preparedWrite: Boolean, responseNeeded: Boolean, offset: Int, value: ByteArray) { val data = value.copyOf(); post {
      val valid = characteristic.uuid == rxID && !preparedWrite && offset == 0 && devices.containsKey(device.address) && data.isNotEmpty()
      if (responseNeeded) server?.sendResponse(device, requestId, if (valid) BluetoothGatt.GATT_SUCCESS else BluetoothGatt.GATT_FAILURE, 0, null)
      if (valid) receive(device.address, data)
    } }
    override fun onNotificationSent(device: BluetoothDevice, status: Int) { post {
      if (target != device.address || promise == null) return@post
      if (status != BluetoothGatt.GATT_SUCCESS) { fail("Bluetooth notification failed"); return@post }
      index++; writeNext()
    } }
  }
  private fun receive(id: String, bytes: ByteArray) {
    readTimers.remove(id)?.let { handler.removeCallbacks(it) }
    val buffer = inputs[id] ?: return
    buffer.write(bytes)
    if (buffer.size() > 16392) { buffer.reset(); return }
    while (true) {
      val data = buffer.toByteArray()
      if (data.size < 4) break
      val n = ByteBuffer.wrap(data, 0, 4).int
      if (n !in 1..8192) { buffer.reset(); return }
      if (data.size < n + 4) break
      event("onPacket", mapOf("payload" to Base64.encodeToString(data.copyOfRange(4, n + 4), Base64.NO_WRAP), "peer" to id))
      buffer.reset(); buffer.write(data, n + 4, data.size - n - 4)
    }
    if (buffer.size() > 0) {
      val timeout = Runnable { inputs[id]?.reset(); readTimers.remove(id) }
      readTimers[id] = timeout; handler.postDelayed(timeout, 15000)
    }
  }
  fun send(payload: String, peer: String, p: Promise) {
    if (!active || !devices.containsKey(peer) || server == null || tx == null) { p.reject("DISCONNECTED", "Participant is not connected", null); return }
    if (promise != null) { p.reject("BUSY", "A transfer is in progress", null); return }
    val data = try { Base64.decode(payload, Base64.NO_WRAP) } catch (_: Exception) { byteArrayOf() }
    if (data.isEmpty() || data.size > 8192) { p.reject("INVALID", "Invalid packet", null); return }
    val frame = ByteBuffer.allocate(data.size + 4).putInt(data.size).put(data).array()
    output = frame.toList().chunked(sizes[peer] ?: 20).map { it.toByteArray() }
    target = peer; index = 0; promise = p; handler.postDelayed(sendTimeout, 20000); writeNext()
  }
  private fun writeNext() {
    val device = devices[target] ?: run { fail("Participant disconnected"); return }
    val characteristic = tx ?: return
    if (index >= output.size) {
      handler.removeCallbacks(sendTimeout); output = emptyList(); target = null; val p = promise; promise = null; p?.resolve(null); return
    }
    try {
      val accepted = if (Build.VERSION.SDK_INT >= 33) server?.notifyCharacteristicChanged(device, characteristic, false, output[index]) == BluetoothStatusCodes.SUCCESS
      else {
        @Suppress("DEPRECATION") characteristic.value = output[index]
        @Suppress("DEPRECATION") server?.notifyCharacteristicChanged(device, characteristic, false) == true
      }
      if (!accepted) fail("Bluetooth notification could not start")
    } catch (_: Exception) { fail("Bluetooth notification failed") }
  }
  private fun remove(id: String) {
    if (devices.remove(id) == null) return
    inputs.remove(id); sizes.remove(id); readTimers.remove(id)?.let { handler.removeCallbacks(it) }
    if (target == id) fail("Participant disconnected")
    status("disconnected", peer = id)
  }
  private fun fail(reason: String) { handler.removeCallbacks(sendTimeout); val p = promise; promise = null; target = null; output = emptyList(); p?.reject("TRANSFER_FAILED", reason, null) }
  fun stop() {
    active = false; fail("Room stopped")
    readTimers.values.forEach { handler.removeCallbacks(it) }; readTimers.clear(); inputs.clear(); devices.clear(); sizes.clear()
    try { advertiser?.stopAdvertising(advertising); server?.clearServices(); server?.close() } catch (_: Exception) { }
    advertiser = null; server = null; tx = null
  }
}
