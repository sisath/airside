package expo.modules.airside

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import android.util.Base64
import expo.modules.kotlin.Promise
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.util.UUID

@SuppressLint("MissingPermission")
class AirsideBluetoothModule : Module() {
  private var roomHost: RoomHost? = null
  private val handler = Handler(Looper.getMainLooper())
  private val rxID = UUID.fromString("f0a10002-4f24-4b45-9c13-7a1500000001")
  private val txID = UUID.fromString("f0a10003-4f24-4b45-9c13-7a1500000001")
  private val cccdID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
  private var roomID: UUID? = null
  private var active = false
  private var scanner: BluetoothLeScanner? = null
  private var scanCallback: ScanCallback? = null
  private var gatt: BluetoothGatt? = null
  private var rx: BluetoothGattCharacteristic? = null
  private var ready = false
  private var mtu = 23
  private var input = ByteArrayOutputStream()
  private var expected = -1
  private var output: List<ByteArray> = emptyList()
  private var outputIndex = 0
  private var sendPromise: Promise? = null
  private var generation = 0
  private val sendTimeout = Runnable { failSend("Bluetooth transfer timed out"); failConnection("Bluetooth transfer timed out. Reconnecting…") }
  private val readTimeout = Runnable { failConnection("An incomplete Bluetooth transfer timed out. Reconnecting…") }
  private val connectTimeout = Runnable { failConnection("Connection timed out. Keep the room owner nearby with CloseBy open.") }
  private val scanTimeout = Runnable { stopScan(); if (active) handler.postDelayed({ scan() }, 2500) }

  override fun definition() = ModuleDefinition {
    Name("AirsideBluetooth")
    Events("onStatus", "onPacket")
    AsyncFunction("start") { uuid: String, mode: String ->
      stopInternal()
      roomID = UUID.fromString(uuid)
      active = true
      if (mode == "create") {
        val context = appContext.reactContext ?: throw IllegalStateException("App context unavailable")
        roomHost = RoomHost(context, handler) { event, value -> sendEvent(event, value) }.also { it.start(UUID.fromString(uuid)) }
      } else scan()
    }.runOnQueue(expo.modules.kotlin.functions.Queues.MAIN)
    AsyncFunction("send") { payload: String, peer: String, promise: Promise ->
      val host = roomHost
      if (host != null) host.send(payload, peer, promise) else sendPacket(payload, promise)
    }.runOnQueue(expo.modules.kotlin.functions.Queues.MAIN)
    AsyncFunction("stop") { stopInternal() }.runOnQueue(expo.modules.kotlin.functions.Queues.MAIN)
    OnDestroy { post { stopInternal() } }
  }
  private fun status(value: String, message: String = "") = sendEvent("onStatus", mapOf("status" to value, "message" to message, "peer" to "host"))
  private fun post(action: () -> Unit) {
    handler.post {
      try { action() }
      catch (_: SecurityException) {
        stopInternal()
        status("error", "Bluetooth permission changed. Allow Nearby devices access, then reconnect.")
      }
      catch (error: Exception) { failConnection(error.message ?: "Bluetooth was interrupted. Reconnecting…") }
    }
  }
  private fun adapter(): BluetoothAdapter? = (appContext.reactContext?.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
  private fun scan() {
    if (!active || gatt != null || scanCallback != null) return
    try {
      val adapter = adapter()
      if (adapter == null) { status("error", "This device does not support Bluetooth."); return }
      if (!adapter.isEnabled) { status("poweredOff", "Turn Bluetooth on, then tap Reconnect."); return }
      val id = roomID ?: return
      val scanner = adapter.bluetoothLeScanner ?: run { status("error", "Bluetooth scanner is unavailable."); return }
      this.scanner = scanner
      val epoch = generation
      val callback = object : ScanCallback() {
        override fun onScanResult(type: Int, result: ScanResult) {
          post {
            if (!active || epoch != generation || gatt != null || scanCallback !== this) return@post
            stopScan()
            connect(result.device)
          }
        }
        override fun onScanFailed(errorCode: Int) {
          post {
            if (!active || epoch != generation || scanCallback !== this) return@post
            stopScan()
            status("disconnected", "Bluetooth discovery paused ($errorCode). Retrying…")
            handler.postDelayed({ if (active && epoch == generation) scan() }, 5000)
          }
        }
      }
      scanCallback = callback
      scanner.startScan(listOf(ScanFilter.Builder().setServiceUuid(ParcelUuid(id)).build()), ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), callback)
      status("scanning")
      handler.postDelayed(scanTimeout, 25000)
    } catch (_: SecurityException) { status("error", "Allow Nearby devices access in Settings > Apps > CloseBy > Permissions.") }
      catch (error: Exception) { status("error", error.message ?: "Bluetooth discovery failed.") }
  }
  private fun stopScan() {
    handler.removeCallbacks(scanTimeout)
    val callback = scanCallback; scanCallback = null
    try { if (callback != null) scanner?.stopScan(callback) } catch (_: Exception) { }
    scanner = null
  }
  private fun connect(device: BluetoothDevice) {
    status("connecting")
    val context = appContext.reactContext ?: return
    gatt = device.connectGatt(context, false, callback, BluetoothDevice.TRANSPORT_LE)
    handler.postDelayed(connectTimeout, 20000)
  }
  private val callback = object : BluetoothGattCallback() {
    override fun onConnectionStateChange(connection: BluetoothGatt, status: Int, newState: Int) {
      post {
        if (connection !== gatt || !active) return@post
        if (status == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_CONNECTED) {
          connection.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_HIGH)
          // MTU negotiation precedes all other GATT operations.
          if (!connection.requestMtu(185)) discover(connection)
        } else if (newState == BluetoothProfile.STATE_DISCONNECTED || status != BluetoothGatt.GATT_SUCCESS) {
          failConnection("Room owner disconnected. Searching nearby…")
        }
      }
    }
    override fun onMtuChanged(connection: BluetoothGatt, value: Int, status: Int) {
      post {
        if (connection !== gatt || !active) return@post
        mtu = if (status == BluetoothGatt.GATT_SUCCESS) value else 23
        discover(connection)
      }
    }
    override fun onServicesDiscovered(connection: BluetoothGatt, status: Int) {
      post {
        if (connection !== gatt || !active) return@post
        if (status != BluetoothGatt.GATT_SUCCESS) { failConnection("Could not discover the chat service."); return@post }
        val service = roomID?.let { connection.getService(it) }
        val receive = service?.getCharacteristic(rxID)
        val transmit = service?.getCharacteristic(txID)
        if (receive == null || transmit == null) { failConnection("The other device is not a CloseBy chat."); return@post }
        rx = receive
        val descriptor = transmit.getDescriptor(cccdID)
        if (descriptor == null || !connection.setCharacteristicNotification(transmit, true)) { failConnection("Could not enable messages."); return@post }
        val accepted = if (Build.VERSION.SDK_INT >= 33) {
          connection.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE) == BluetoothStatusCodes.SUCCESS
        } else {
          @Suppress("DEPRECATION")
          descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
          @Suppress("DEPRECATION")
          connection.writeDescriptor(descriptor)
        }
        if (!accepted) failConnection("Could not subscribe to messages.")
      }
    }
    override fun onDescriptorWrite(connection: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
      post {
        if (connection !== gatt || !active || descriptor.uuid != cccdID) return@post
        if (status != BluetoothGatt.GATT_SUCCESS) { failConnection("Message subscription failed."); return@post }
        handler.removeCallbacks(connectTimeout)
        ready = true
        this@AirsideBluetoothModule.status("linked")
      }
    }
    @Deprecated("Compatibility for Android 12 and older")
    override fun onCharacteristicChanged(connection: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
      if (Build.VERSION.SDK_INT >= 33) return
      @Suppress("DEPRECATION") val bytes = characteristic.value?.copyOf() ?: return
      post { if (connection === gatt && active && characteristic.uuid == txID) receive(bytes) }
    }
    override fun onCharacteristicChanged(connection: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
      val bytes = value.copyOf()
      post { if (connection === gatt && active && characteristic.uuid == txID) receive(bytes) }
    }
    override fun onCharacteristicWrite(connection: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
      post {
        if (connection !== gatt || !active || characteristic.uuid != rxID || sendPromise == null) return@post
        if (status != BluetoothGatt.GATT_SUCCESS) { failConnection("A Bluetooth write failed. Reconnecting…"); return@post }
        outputIndex++
        writeNext()
      }
    }
  }
  private fun discover(connection: BluetoothGatt) {
    if (!connection.discoverServices()) failConnection("Service discovery could not start.")
  }
  private fun sendPacket(base64: String, promise: Promise) {
    if (!ready || gatt == null || rx == null) { promise.reject("DISCONNECTED", "Your partner is not connected", null); return }
    if (sendPromise != null) { promise.reject("BUSY", "A transfer is already in progress", null); return }
    val bytes = try { Base64.decode(base64, Base64.NO_WRAP) } catch (_: Exception) { byteArrayOf() }
    if (bytes.isEmpty() || bytes.size > 8192) { promise.reject("INVALID", "Invalid packet", null); return }
    val frame = ByteBuffer.allocate(bytes.size + 4).putInt(bytes.size).put(bytes).array()
    val size = minOf(180, maxOf(20, mtu - 3))
    output = frame.toList().chunked(size).map { it.toByteArray() }
    outputIndex = 0; sendPromise = promise
    handler.postDelayed(sendTimeout, 20000)
    writeNext()
  }
  private fun writeNext() {
    val connection = gatt ?: return
    val receive = rx ?: return
    if (outputIndex >= output.size) {
      handler.removeCallbacks(sendTimeout)
      val promise = sendPromise; sendPromise = null; output = emptyList()
      promise?.resolve(null)
      return
    }
    try {
      val accepted = if (Build.VERSION.SDK_INT >= 33) {
        connection.writeCharacteristic(receive, output[outputIndex], BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == BluetoothStatusCodes.SUCCESS
      } else {
        receive.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        @Suppress("DEPRECATION") receive.value = output[outputIndex]
        @Suppress("DEPRECATION") connection.writeCharacteristic(receive)
      }
      if (!accepted) failConnection("Bluetooth was busy. Reconnecting…")
    } catch (_: Exception) { failConnection("Bluetooth transfer failed. Reconnecting…") }
  }
  private fun receive(bytes: ByteArray) {
    handler.removeCallbacks(readTimeout)
    input.write(bytes)
    if (input.size() > 16392) { failConnection("Invalid Bluetooth data."); return }
    while (true) {
      var data = input.toByteArray()
      if (expected < 0) {
        if (data.size < 4) break
        expected = ByteBuffer.wrap(data, 0, 4).int
        input.reset(); input.write(data, 4, data.size - 4)
        if (expected !in 1..8192) { failConnection("Invalid Bluetooth frame."); return }
        data = input.toByteArray()
      }
      if (data.size < expected) break
      val packet = data.copyOfRange(0, expected)
      input.reset(); input.write(data, expected, data.size - expected); expected = -1
      sendEvent("onPacket", mapOf("payload" to Base64.encodeToString(packet, Base64.NO_WRAP), "peer" to "host"))
    }
    if (expected >= 0 || input.size() > 0) handler.postDelayed(readTimeout, 15000)
  }
  private fun clearInput() { input.reset(); expected = -1; handler.removeCallbacks(readTimeout) }
  private fun failSend(reason: String) {
    handler.removeCallbacks(sendTimeout)
    val promise = sendPromise; sendPromise = null; output = emptyList()
    promise?.reject("TRANSFER_FAILED", reason, null)
  }
  private fun closeConnection() {
    ready = false; rx = null; mtu = 23
    handler.removeCallbacks(connectTimeout)
    clearInput(); failSend("Bluetooth disconnected")
    val old = gatt; gatt = null
    try { old?.disconnect(); old?.close() } catch (_: Exception) { }
  }
  private fun failConnection(message: String) {
    stopScan(); closeConnection()
    if (!active) return
    status("disconnected", message)
    val epoch = generation
    handler.postDelayed({ if (active && epoch == generation) scan() }, 1800)
  }
  private fun stopInternal() {
    roomHost?.stop(); roomHost = null
    active = false; generation++
    handler.removeCallbacksAndMessages(null)
    stopScan(); closeConnection()
    status("idle")
  }
}
