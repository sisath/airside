import { test } from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { fromByteArray, toByteArray } from 'base64-js';
import { createRoomCode, validRoomCode, formatRoomCode, ROOM_LIFETIME } from '../src/core/room-code';
import { SecureLinks, type JoinRequest } from '../src/core/secure-links';
import { RoomSession } from '../src/core/room';
import { MediaAssembler, splitMedia, MAX_MEDIA_BYTES, validMediaChunk } from '../src/core/media';
const random = (n: number) => new Uint8Array(randomBytes(n));
const flush = async () => { for (let n = 0; n < 1000; n++) await Promise.resolve(); };
const CODE = 'ABC123';
function securePair(guestCode = CODE) {
  let time = 100000, pending: JoinRequest[] = [], fingerprint = '', linked = false;
  const hostPackets: string[] = [], guestPackets: string[] = [], wires: string[] = [];
  const host = new SecureLinks({ mode: 'create', code: CODE, name: 'Owner', expiresAt: time + ROOM_LIFETIME, random, now: () => time, changed: p => { pending = p; }, expiry: () => {}, linked: () => {}, packet: p => hostPackets.push(p), send: async p => { wires.push(p); guest.receive(p, 'host'); } });
  const guest = new SecureLinks({ mode: 'join', code: guestCode, name: 'Visitor', random, now: () => time, changed: (_p, f) => { fingerprint = f; }, expiry: () => {}, linked: (_p, l) => { linked = l; }, packet: p => guestPackets.push(p), send: async p => { wires.push(p); host.receive(p, 'guest'); } });
  return { host, guest, hostPackets, guestPackets, wires, pending: () => pending, fingerprint: () => fingerprint, linked: () => linked, advance(n: number) { time += n; }, async connect() { guest.link('host', true); await flush(); } };
}
test('six-character codes round-trip ABC 123 and generate letters plus digits', () => {
  assert.equal(formatRoomCode('abc123'), 'ABC 123'); assert.ok(validRoomCode('ABC 123')); assert.ok(!validRoomCode('ABC12'));
  const codes = new Set(Array.from({ length: 200 }, () => createRoomCode(random))); assert.equal(codes.size, 200); for (const c of codes) assert.ok(validRoomCode(c));
});
test('fresh key agreement requires owner approval and matching verification numbers', async () => {
  const p = securePair(); await p.connect(); assert.equal(p.pending().length, 1); assert.equal(p.pending()[0].verification, p.fingerprint()); assert.equal(p.linked(), false);
  await assert.rejects(p.guest.send('not approved', 'host'));
  p.host.approve('guest'); await flush(); assert.equal(p.linked(), true); assert.equal(p.pending().length, 0);
  await p.guest.send('a private room packet', 'host'); assert.deepEqual(p.hostPackets, ['a private room packet']);
  await p.host.send('reply', 'guest'); assert.deepEqual(p.guestPackets, ['reply']);
  assert.ok(p.wires.every(w => !new TextDecoder().decode(toByteArray(w)).includes('a private room packet')));
});
test('wrong code cannot decrypt approval and rejected guests do not immediately reappear', async () => {
  const bad = securePair('DEF456'); await bad.connect(); assert.notEqual(bad.pending()[0].verification, bad.fingerprint()); bad.host.approve('guest'); await flush(); assert.equal(bad.linked(), false);
  const p = securePair(); await p.connect(); p.host.reject('guest'); p.advance(4000); p.guest.tick(); await flush(); assert.equal(p.pending().length, 0); assert.equal(p.linked(), false);
});
test('tampered data and old-link replays never reach the room after reconnect', async () => {
  const p = securePair(); await p.connect(); p.host.approve('guest'); await flush(); await p.guest.send('original', 'host');
  const old = p.wires[p.wires.length - 1]; p.host.receive(fromByteArray(new Uint8Array([1, 2, 3])), 'guest'); assert.equal(p.hostPackets.length, 1);
  p.host.link('guest', false); p.guest.link('host', false); p.guest.link('host', true); await flush(); p.host.approve('guest'); await flush(); p.host.receive(old, 'guest'); assert.equal(p.hostPackets.length, 1);
});
test('owner cannot admit guests after the 24-hour deadline', async () => {
  const p = securePair(); await p.connect(); p.advance(ROOM_LIFETIME + 1); p.host.approve('guest'); await flush(); assert.equal(p.linked(), false);
});
test('room expires exactly at its creation deadline, clears messages and rejects reuse', () => {
  let time = 100000;
  const room = new RoomSession({ code: CODE, name: 'Owner', mode: 'create', random, now: () => time, send: async () => {}, changed: () => {} });
  room.send('Before expiry'); const deadline = room.snapshot().expiresAt;
  time = deadline - 1; room.tick(); assert.notEqual(room.snapshot().status, 'expired');
  time++; room.tick(); assert.equal(room.snapshot().status, 'expired'); assert.equal(room.snapshot().messages.length, 0); assert.equal(room.snapshot().members.length, 0); assert.throws(() => room.send('Too late'), /expired/i);
  room.link('somebody', true); assert.equal(room.snapshot().status, 'expired'); assert.equal(room.setExpiry(time + ROOM_LIFETIME), false);
});
test('photo chunks reassemble out of order once, with exact byte and digest checks', () => {
  const bytes = new Uint8Array(4000); bytes.set([0xff, 0xd8]); bytes.set([0xff, 0xd9], bytes.length - 2);
  const chunks = splitMedia(bytes, 'photo', random), assembler = new MediaAssembler();
  let result; for (const c of [...chunks].reverse()) result = assembler.accept('author', c, 100);
  assert.deepEqual(toByteArray(result!.attachment!.base64), bytes); assert.equal(assembler.accept('author', chunks[0], 200).progress, 1);
  assert.throws(() => assembler.accept('author', { ...chunks[0], hash: 'a'.repeat(64) }, 200), /Conflicting/);
  const bad = new MediaAssembler(); const corrupt = chunks.map(c => ({ ...c })); corrupt[0].data = 'AAAA' + corrupt[0].data.slice(4); assert.throws(() => { for (const c of corrupt) bad.accept('author', c, 100); }, /verification/);
});
test('voice media bounds, valid MP4 envelope, incomplete transfer timeout and oversized rejection', () => {
  const bytes = new Uint8Array([0, 0, 0, 12, 102, 116, 121, 112, 77, 52, 65, 32]);
  const chunks = splitMedia(bytes, 'voice', random, 1200), assembler = new MediaAssembler();
  assert.equal(assembler.accept('speaker', chunks[0], 100).attachment?.mime, 'audio/mp4');
  assert.throws(() => splitMedia(new Uint8Array(MAX_MEDIA_BYTES + 1), 'photo', random)); assert.throws(() => splitMedia(bytes, 'voice', random, 15001));
  assert.equal(validMediaChunk({ ...chunks[0], total: 999999 }), false);
  const photo = new Uint8Array(5000); photo.set([255,216]); photo.set([255,217],4998); const parts = splitMedia(photo, 'photo', random);
  const incomplete = new MediaAssembler(); incomplete.accept('x', parts[0], 0); incomplete.prune(121000);
  assert.ok(incomplete.accept('x', parts[1], 121000).progress < 1);
});

test('approved secure links carry the complete short-code room handshake and message receipts', async () => {
  const now = () => 100000;
  let hostLink: SecureLinks, guestLink: SecureLinks;
  const owner = new RoomSession({ code: CODE, mode: 'create', name: 'Owner', random, now, send: (data, peer) => hostLink.send(data, peer), changed: () => {} });
  const guest = new RoomSession({ code: CODE, mode: 'join', name: 'Visitor', random, now, send: (data, peer) => guestLink.send(data, peer), changed: () => {} });
  hostLink = new SecureLinks({ code: CODE, mode: 'create', name: 'Owner', random, now, expiresAt: now() + ROOM_LIFETIME, send: async data => guestLink.receive(data, 'host'), packet: (data, peer) => owner.receive(data, peer), linked: (peer, value) => owner.link(peer, value), changed: () => {}, expiry: () => {} });
  guestLink = new SecureLinks({ code: CODE, mode: 'join', name: 'Visitor', random, now, send: async data => hostLink.receive(data, 'visitor'), packet: (data, peer) => guest.receive(data, peer), linked: (peer, value) => guest.link(peer, value), changed: () => {}, expiry: deadline => { guest.setExpiry(deadline); } });
  guestLink.link('host', true); await flush(); assert.equal(guest.snapshot().status, 'waiting');
  hostLink.approve('visitor'); await flush(); assert.equal(owner.snapshot().members.length, 2); assert.equal(guest.snapshot().status, 'connected');
  guest.send('Secure room hello'); await flush(); assert.equal(owner.snapshot().messages[0].text, 'Secure room hello'); assert.equal(guest.snapshot().messages[0].status, 'delivered');
});
