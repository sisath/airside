import { test } from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { ChatSession } from '../src/core/session';
import { WireCodec } from '../src/core/wire';
const random = (length: number) => new Uint8Array(randomBytes(length));
const CODE = 'ABCDEFGHJKLMNPQRSTUV';
const flush = async () => { for (let i = 0; i < 80; i++) await Promise.resolve(); };
function pair() {
  let time = 100000;
  const ab: string[] = [], ba: string[] = [];
  const codec = new WireCodec(CODE, random);
  let dropAck = false;
  const a = new ChatSession({ code: CODE, name: 'You', random, now: () => time, changed: () => {}, send: async packet => { ab.push(packet); b.receive(packet); } });
  const b = new ChatSession({ code: CODE, name: 'Her', random, now: () => time, changed: () => {}, send: async packet => { ba.push(packet); if (!dropAck || codec.decode(packet).t !== 'ack') a.receive(packet); } });
  return { a, b, codec, ab, ba, advance: (n: number) => { time += n; }, dropAcks: (v: boolean) => { dropAck = v; }, connect: async () => { a.setLinked(true); b.setLinked(true); await flush(); } };
}
test('mutual challenge handshake establishes the correct partner', async () => {
  const p = pair(); await p.connect();
  assert.equal(p.a.snapshot().status, 'connected'); assert.equal(p.b.snapshot().status, 'connected');
  assert.equal(p.a.snapshot().peerName, 'Her'); assert.equal(p.b.snapshot().peerName, 'You');
});
test('simultaneous two-way messages are delivered once and acknowledged', async () => {
  const p = pair(); await p.connect();
  p.a.send('Window seat! ☁️'); p.b.send('Lucky you 🤍'); await flush();
  for (const s of [p.a.snapshot(), p.b.snapshot()]) { assert.equal(s.messages.length, 2); assert.ok(s.messages.every(m => m.status === 'delivered')); }
  assert.equal(p.b.snapshot().messages.find(m => m.direction === 'in')?.text, 'Window seat! ☁️');
});
test('offline messages remain queued, then send after connecting', async () => {
  const p = pair(); p.a.send('Save this for later');
  assert.equal(p.a.snapshot().messages[0].status, 'queued');
  await p.connect();
  assert.equal(p.a.snapshot().messages[0].status, 'delivered'); assert.equal(p.b.snapshot().messages.length, 1);
});
test('lost acknowledgements retry without duplicating the received message', async () => {
  const p = pair(); await p.connect(); p.dropAcks(true); p.a.send('Snack?'); await flush();
  assert.equal(p.a.snapshot().messages[0].status, 'sending');
  p.advance(6500); p.a.tick(); p.b.tick(); await flush();
  assert.equal(p.b.snapshot().messages.length, 1);
  p.dropAcks(false); p.advance(6500); p.a.tick(); p.b.tick(); await flush();
  assert.equal(p.a.snapshot().messages[0].status, 'delivered'); assert.equal(p.b.snapshot().messages.length, 1);
});
test('three unacknowledged attempts require explicit retry', async () => {
  const p = pair(); await p.connect(); p.dropAcks(true); const id = p.a.send('Hello'); await flush();
  for (let i = 0; i < 3; i++) { p.advance(6500); p.a.tick(); p.b.tick(); await flush(); }
  assert.equal(p.a.snapshot().messages[0].status, 'retry');
  p.dropAcks(false); p.a.retry(id); await flush(); assert.equal(p.a.snapshot().messages[0].status, 'delivered');
});
test('reconnect invalidates old sessions and delivers pending messages', async () => {
  const p = pair(); await p.connect(); p.a.send('Old message'); await flush();
  const oldWire = p.ab.find(w => p.codec.decode(w).t === 'message')!;
  p.a.setLinked(false); p.b.setLinked(false); p.a.send('After reconnect'); await p.connect();
  assert.equal(p.b.snapshot().messages.length, 2);
  p.b.receive(oldWire); await flush(); assert.equal(p.b.snapshot().messages.length, 2);
  assert.equal(p.a.snapshot().messages[1].status, 'delivered');
});
test('a replayed welcome cannot satisfy a new challenge', async () => {
  const p = pair(); await p.connect(); const old = p.ba.find(w => p.codec.decode(w).t === 'welcome')!;
  p.a.setLinked(false); p.a.setLinked(true); p.a.receive(old);
  assert.equal(p.a.snapshot().status, 'verifying');
  p.a.dispose(); p.b.dispose(); await flush();
});
test('unauthenticated traffic and invalid messages do not alter state', async () => {
  const p = pair(); await p.connect(); const before = p.a.snapshot();
  p.a.receive('AAAA'); p.a.receive('invalid');
  assert.deepEqual(p.a.snapshot(), before); assert.throws(() => p.a.send(' ')); assert.throws(() => p.a.send('x'.repeat(1001)));
});
test('clear history does not let an in-flight retry restore a deleted message', async () => {
  const p = pair(); await p.connect(); p.dropAcks(true); p.a.send('Private'); await flush();
  p.b.clearHistory(); p.advance(6500); p.a.tick(); p.b.tick(); await flush();
  assert.equal(p.b.snapshot().messages.length, 0);
});
test('silent peers lose connected status rather than showing false delivery', async () => {
  const p = pair(); await p.connect(); p.advance(26000); p.a.tick();
  assert.equal(p.a.snapshot().status, 'waiting'); assert.match(p.a.snapshot().problem!, /stopped responding/);
});
test('disposed sessions neither send nor publish queued work', async () => {
  const p = pair(); p.a.setLinked(true); p.a.dispose(); await flush(); assert.equal(p.ab.length, 0);
});
