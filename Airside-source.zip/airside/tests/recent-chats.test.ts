import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createRecentChats } from '../src/core/recent-chats';
test('today rooms survive reload, concurrent saves, revisit and expire without extending deadlines', async () => {
  let time = new Date(2026, 10, 16, 12).getTime();
  const data = new Map<string, string>();
  const storage = { getItemAsync: async (k: string) => data.get(k) ?? null, setItemAsync: async (k: string, v: string) => { data.set(k, v); }, deleteItemAsync: async (k: string) => { data.delete(k); } };
  const history = createRecentChats(storage, () => time);
  const deadline = time + 3600000;
  await Promise.all(['ABC123', 'DEF456'].map(code => history.rememberChat({ code, name: 'S', mode: 'create', expiresAt: deadline })));
  assert.equal((await createRecentChats(storage, () => time).loadRecentChats()).length, 2);
  time += 1000;
  await history.rememberChat({ code: 'ABC123', name: 'W', mode: 'join', expiresAt: deadline });
  const rooms = await history.loadRecentChats();
  assert.equal(rooms.length, 2); assert.equal(rooms[0].code, 'ABC123'); assert.equal(rooms[0].expiresAt, deadline);
  await history.rememberChat({ code: 'GHI789', name: 'S', mode: 'join', expiresAt: 0 });
  assert.equal((await history.loadRecentChats()).length, 2, 'unapproved joins are not saved');
  time = deadline;
  assert.deepEqual(await history.loadRecentChats(), []);
  assert.equal(data.has('closeby.recent.ABC123'), false);
});
test('previous calendar day rooms leave the today list even before the 24-hour expiry', async () => {
  let time = new Date(2026, 10, 16, 23, 59).getTime();
  const data = new Map<string, string>();
  const history = createRecentChats({ getItemAsync: async k => data.get(k) ?? null, setItemAsync: async (k, v) => { data.set(k, v); }, deleteItemAsync: async k => { data.delete(k); } }, () => time);
  await history.rememberChat({ code: 'ABC123', name: 'S', mode: 'create', expiresAt: time + 86400000 });
  time += 120000;
  assert.deepEqual(await history.loadRecentChats(), []);
});
