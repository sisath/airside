import { test } from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { RoomSession } from '../src/core/room';
import { RoomCodec, parseRoomPacket, roomServiceUUID } from '../src/core/room-wire';
const random = (n: number) => new Uint8Array(randomBytes(n));
const CODE = 'ABCDEFGHJKLMNPQRSTUV';
const flush = async () => { for (let n = 0; n < 1000; n++) await Promise.resolve(); };
function room(count = 3) {
  let time = 100000;
  const codec = new RoomCodec(CODE, random);
  let filter = (_from: string, _to: string, _payload: string) => true;
  const sent: { from: string; to: string; payload: string }[] = [];
  const guests: RoomSession[] = [];
  const host = new RoomSession({ code: CODE, name: 'Owner', mode: 'create', random, now: () => time, ackWaitMs: 6000, changed: () => {}, send: async (payload, peer) => {
    sent.push({ from: 'host', to: peer, payload }); if (filter('host', peer, payload)) guests[Number(peer)]?.receive(payload, 'host');
  } });
  for (let i = 0; i < count - 1; i++) guests.push(new RoomSession({ code: CODE, name: `Guest ${i}`, mode: 'join', random, now: () => time, ackWaitMs: 6000, changed: () => {}, send: async payload => {
    sent.push({ from: String(i), to: 'host', payload }); if (filter(String(i), 'host', payload)) host.receive(payload, String(i));
  } }));
  return { host, guests, codec, sent, advance(n: number) { time += n; }, filter(fn: typeof filter) { filter = fn; },
    connect: async () => { guests.forEach(g => g.link('host', true)); await flush(); }, tick: async () => { host.tick(); guests.forEach(g => g.tick()); await flush(); } };
}
test('owner and multiple guests mutually authenticate and share roster', async () => {
  const r = room(4); await r.connect();
  for (const p of [r.host, ...r.guests]) { assert.equal(p.snapshot().status, 'connected'); assert.equal(p.snapshot().members.length, 4); }
});
test('guest-to-guest and owner messages carry names and require all recipients to acknowledge', async () => {
  const r = room(); await r.connect(); r.guests[0].send('Hello group'); await flush(); r.host.send('Welcome'); await flush();
  for (const p of [r.host, ...r.guests]) { assert.equal(p.snapshot().messages.length, 2); assert.ok(p.snapshot().messages.every(m => m.status === 'delivered')); }
  assert.equal(r.guests[1].snapshot().messages[0].name, 'Guest 0');
});
test('one missing recipient ack does not falsely mark group delivery', async () => {
  const r = room(); await r.connect(); r.filter((from, _to, payload) => !(from === '1' && r.codec.decode(payload).t === 'ack'));
  r.guests[0].send('Check'); await flush(); assert.equal(r.guests[0].snapshot().messages[0].status, 'sending');
  for (let i = 0; i < 3; i++) { r.advance(6500); await r.tick(); }
  assert.equal(r.guests[0].snapshot().messages[0].status, 'retry'); assert.equal(r.guests[1].snapshot().messages.length, 1);
  r.filter(() => true); r.guests[0].retry(r.guests[0].snapshot().messages[0].id); await flush();
  assert.equal(r.guests[0].snapshot().messages[0].status, 'delivered'); assert.equal(r.guests[1].snapshot().messages.length, 1);
});
test('lost receipt is recovered by duplicate submission without duplicate messages', async () => {
  const r = room(); await r.connect(); r.filter((_from, _to, payload) => r.codec.decode(payload).t !== 'receipt');
  r.guests[0].send('Once'); await flush(); assert.equal(r.guests[0].snapshot().messages[0].status, 'sending');
  r.filter(() => true); r.advance(6500); await r.tick();
  assert.equal(r.guests[0].snapshot().messages[0].status, 'delivered'); assert.equal(r.host.snapshot().messages.length, 1);
});
test('offline messages wait and late joiners do not receive room history', async () => {
  const r = room(); r.host.send('Queued'); assert.equal(r.host.snapshot().messages[0].status, 'queued');
  r.guests[0].link('host', true); await flush(); assert.equal(r.host.snapshot().messages[0].status, 'delivered');
  r.guests[1].link('host', true); await flush(); assert.equal(r.guests[1].snapshot().messages.length, 0);
});
test('lost ready and roster packets recover by repeated ready challenge', async () => {
  const r = room(); r.filter((_from, _to, payload) => !['ready', 'roster'].includes(r.codec.decode(payload).t)); await r.connect();
  assert.notEqual(r.guests[0].snapshot().status, 'connected'); r.filter(() => true); r.advance(2500); await r.tick();
  assert.equal(r.guests[0].snapshot().status, 'connected'); assert.equal(r.host.snapshot().members.length, 3);
});
test('wrong code and forged sender route never enter a room', async () => {
  const r = room(); await r.connect(); const before = r.host.snapshot();
  const wrong = new RoomCodec('ZZZZZZZZZZZZZZZZZZZZ', random);
  r.host.receive(wrong.encode({ v: 2, t: 'hello', session: 'a'.repeat(32), identity: 'c'.repeat(32), name: 'Intruder' }), 'x');
  r.guests[0].send('Valid'); await flush(); const submit = r.sent.find(p => r.codec.decode(p.payload).t === 'submit')!;
  r.host.receive(submit.payload, 'not-this-peer'); await flush();
  assert.equal(r.host.snapshot().members.length, before.members.length); assert.equal(r.host.snapshot().messages.length, 1);
});
test('fresh challenge prevents a replayed ready from admitting an old connection', async () => {
  const r = room(2); await r.connect(); const old = r.sent.find(p => r.codec.decode(p.payload).t === 'ready')!;
  const hello = r.sent.find(p => r.codec.decode(p.payload).t === 'hello')!;
  r.host.link('0', false); r.filter(() => false); r.host.receive(hello.payload, '0'); r.host.receive(old.payload, '0');
  assert.equal(r.host.snapshot().members.length, 1);
});
test('reconnect rejects old room traffic and delivers pending messages', async () => {
  const r = room(2); await r.connect(); r.host.send('Before'); await flush();
  const old = r.sent.find(p => r.codec.decode(p.payload).t === 'message')!;
  r.host.link('0', false); r.guests[0].link('host', false); r.guests[0].send('Pending'); r.guests[0].link('host', true); await flush();
  const before = r.guests[0].snapshot(); r.guests[0].receive(old.payload, 'host'); assert.deepEqual(r.guests[0].snapshot(), before);
  assert.equal(r.guests[0].snapshot().messages[1].status, 'delivered');
});
test('room has at most eight verified participants', async () => {
  const r = room(9); await r.connect(); assert.equal(r.host.snapshot().members.length, 8);
  assert.notEqual(r.guests[7].snapshot().status, 'connected'); assert.match(r.guests[7].snapshot().problem!, /full/);
});
test('clear keeps deduplication; inactive owner disconnects clients', async () => {
  const r = room(2); await r.connect(); r.host.send('Private'); await flush(); const packet = r.sent.find(p => r.codec.decode(p.payload).t === 'message')!;
  r.guests[0].clearHistory(); r.guests[0].receive(packet.payload, 'host'); assert.equal(r.guests[0].snapshot().messages.length, 0);
  r.advance(181000); r.guests[0].tick(); assert.equal(r.guests[0].snapshot().status, 'waiting');
});
test('room wire rejects invalid roster and isolates old discovery protocol', () => {
  assert.throws(() => parseRoomPacket({ v: 2, session: 'a'.repeat(32), t: 'roster', to: 'b'.repeat(32), members: [] }));
  assert.throws(() => new RoomCodec('bad', random)); assert.match(roomServiceUUID(CODE), /^[a-f0-9-]{36}$/);
});

test('an unconfirmed submission survives a sender reconnect without duplication', async () => {
  const r = room(); await r.connect(); r.filter((_from, _to, payload) => r.codec.decode(payload).t !== 'receipt');
  r.guests[0].send('Reconnect me'); await flush();
  r.host.link('0', false); r.guests[0].link('host', false); r.filter(() => true); r.guests[0].link('host', true); await flush();
  assert.equal(r.guests[0].snapshot().messages[0].status, 'delivered');
  assert.equal(r.guests[1].snapshot().messages.length, 1); assert.equal(r.host.snapshot().messages.length, 1);
});

test('a replayed hello on another physical link cannot evict a verified member', async () => {
  const r = room(2); await r.connect(); const hello = r.sent.find(p => r.codec.decode(p.payload).t === 'hello')!;
  r.host.receive(hello.payload, 'other-route'); await flush();
  assert.equal(r.host.snapshot().members.length, 2);
});

test('media chunks relay through a three-person room and all delivery receipts complete', async () => {
  const { splitMedia, MediaAssembler } = await import('../src/core/media');
  const r = room(); await r.connect(); const photo = new Uint8Array(4500); photo.set([255,216]); photo.set([255,217],4498);
  const chunks = splitMedia(photo, 'photo', random);
  for (const chunk of chunks) { r.guests[0].send('', chunk); await flush(); }
  const assembler = new MediaAssembler(); let attachment;
  for (const m of r.guests[1].snapshot().messages) if (m.media) attachment = assembler.accept(m.author, m.media, 100).attachment;
  assert.equal(attachment?.size, photo.length); assert.ok(r.guests[0].snapshot().messages.every(m => m.status === 'delivered'));
});
test('typing indicators relay to other members and clear automatically', async () => {
  const r = room(); await r.connect(); r.guests[0].setTyping(true); await flush();
  assert.equal(r.host.snapshot().typing[0].name, 'Guest 0'); assert.equal(r.guests[1].snapshot().typing[0].name, 'Guest 0');
  r.advance(6000); await r.tick(); assert.equal(r.guests[1].snapshot().typing.length, 0);
  r.host.setTyping(true); await flush(); assert.equal(r.guests[0].snapshot().typing[0].name, 'Owner');
  r.host.setTyping(false); await flush(); assert.equal(r.guests[0].snapshot().typing.length, 0);
});
test('room deadline is shared by guests and clears all in-memory group data', async () => {
  const r = room(); await r.connect(); r.host.send('Temporary'); await flush();
  const deadline = r.host.snapshot().expiresAt; assert.equal(r.guests[0].snapshot().expiresAt, deadline);
  r.advance(24 * 60 * 60 * 1000); await r.tick();
  for (const s of [r.host, ...r.guests]) { assert.equal(s.snapshot().status, 'expired'); assert.equal(s.snapshot().messages.length, 0); }
});

test('clearing owner history drops stored payloads but still confirms completed submissions', async () => {
  const r = room(2); await r.connect(); r.filter((_from, _to, payload) => r.codec.decode(payload).t !== 'receipt');
  r.guests[0].send('Clear this'); await flush(); r.host.clearHistory(); assert.equal(r.host.snapshot().messages.length, 0);
  r.filter(() => true); r.advance(6500); await r.tick(); assert.equal(r.guests[0].snapshot().messages[0].status, 'delivered'); assert.equal(r.host.snapshot().messages.length, 0);
});
