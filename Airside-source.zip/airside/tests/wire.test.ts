import { test } from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { fromByteArray, toByteArray } from 'base64-js';
import { WireCodec, createCode, formatCode, normaliseCode, validCode, roomUUID, parsePacket, type Packet } from '../src/core/wire';
const random = (length: number) => new Uint8Array(randomBytes(length));
const code = 'ABCDE' + 'FGHJK' + 'LMNPQ' + 'RSTUV';
const hello: Packet = { v: 1, t: 'hello', session: 'a'.repeat(32), name: 'Stani' };
test('generated pairing codes have 100 random bits and round-trip formatting', () => {
  for (let i = 0; i < 100; i++) {
    const value = createCode(random);
    assert.equal(value.length, 20); assert.ok(validCode(value));
    assert.equal(normaliseCode(formatCode(value).toLowerCase()), value);
  }
  assert.ok(!validCode('A'.repeat(19))); assert.ok(!validCode('O'.repeat(20)));
});
test('discovery is deterministic and independent from the wire key domain', () => {
  assert.equal(roomUUID(code), roomUUID(formatCode(code).toLowerCase()));
  assert.notEqual(roomUUID(code), roomUUID('B'.repeat(20)));
  assert.match(roomUUID(code), /^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$/);
});
test('both phones decrypt an authenticated packet with independently generated nonces', () => {
  const a = new WireCodec(code, random), b = new WireCodec(formatCode(code), random);
  const first = a.encode(hello), second = a.encode(hello);
  assert.notEqual(first, second); assert.deepEqual(b.decode(first), hello);
  assert.ok(!Buffer.from(toByteArray(first)).toString('utf8').includes('Stani'));
});
test('wrong codes and tampered ciphertexts are rejected', () => {
  const a = new WireCodec(code, random), b = new WireCodec('B'.repeat(20), random);
  const wire = a.encode(hello); assert.throws(() => b.decode(wire));
  const bytes = toByteArray(wire); bytes[30] ^= 1;
  assert.throws(() => a.decode(fromByteArray(bytes)));
  assert.throws(() => a.decode('A'.repeat(20000)));
  assert.throws(() => a.decode('AAAA'));
});
test('multibyte text, emoji, and newlines survive encryption', () => {
  const codec = new WireCodec(code, random);
  const packet: Packet = { v: 1, t: 'message', session: 'a'.repeat(32), peer: 'b'.repeat(32), id: 'c'.repeat(32), text: 'Здравей 🤍\nこんにちは ☁️ '.repeat(30), at: 12345 };
  assert.deepEqual(codec.decode(codec.encode(packet)), packet);
});
test('malformed and unsupported packets cannot enter the protocol', () => {
  for (const packet of [null, {}, { ...hello, v: 2 }, { ...hello, session: 'bad' }, { ...hello, name: '' }, { ...hello, t: 'unknown' }, { v: 1, t: 'message', session: 'a'.repeat(32), peer: 'b'.repeat(32), id: 'c'.repeat(32), text: 'a'.repeat(1001), at: 1 }]) assert.throws(() => parsePacket(packet));
});
