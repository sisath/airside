import { test } from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { RoomSession } from '../src/core/room';
import { RoomCodec, parseRoomPacket } from '../src/core/room-wire';
import { openChat, sealChat } from '../src/core/chat-archive';
const random = (n: number) => new Uint8Array(randomBytes(n));
const flush = async () => { for (let n = 0; n < 2000; n++) await Promise.resolve(); };
test('heart and custom heart messages reach every participant once, including receipt retries', async () => {
  const code = 'ABC123', guests: RoomSession[] = [], codec = new RoomCodec(code, random);
  let dropReceipt = false, time = 1000;
  const host = new RoomSession({ code, mode: 'create', name: 'S', random, now: () => time, changed: () => {}, send: async (payload, peer) => { if (!(dropReceipt && codec.decode(payload).t === 'receipt')) guests[Number(peer)].receive(payload, 'host'); } });
  for (const name of ['W', 'T']) { const index = guests.length; guests.push(new RoomSession({ code, mode: 'join', name, random, now: () => time, ackWaitMs: 6000, changed: () => {}, send: async payload => { host.receive(payload, String(index)); } })); }
  guests.forEach(g => g.link('host', true)); await flush();
  host.send('♥', undefined, true); await flush();
  dropReceipt = true; guests[0].send('thinking of you exactly like this', undefined, true); await flush();
  dropReceipt = false; time += 7000; guests[0].tick(); await flush();
  for (const member of [host, ...guests]) {
    assert.equal(member.snapshot().messages.length, 2);
    assert.ok(member.snapshot().messages.every(m => m.heart === true));
    assert.equal(member.snapshot().messages[1].text, 'thinking of you exactly like this');
  }
  assert.equal(guests[0].snapshot().messages[1].status, 'delivered');
  const key = random(32), restored = openChat(sealChat({ room: guests[0].history(), outgoing: [] }, key, 'ABC123-join', random), key, 'ABC123-join', time)!;
  assert.equal(restored.room.messages[1].heart, true);
  assert.equal(restored.room.messages[1].text, 'thinking of you exactly like this');
});
test('invalid heart flags are rejected at the room wire boundary', () => {
  const packet = { v: 2, t: 'submit', session: 'a'.repeat(32), to: 'b'.repeat(32), id: 'c'.repeat(32), text: '♥', heart: true };
  assert.equal(parseRoomPacket(packet).t, 'submit');
  assert.throws(() => parseRoomPacket({ ...packet, heart: 'true' }));
  assert.throws(() => parseRoomPacket({ ...packet, heart: false }));
  assert.throws(() => parseRoomPacket({ ...packet, media: {} }));
});
