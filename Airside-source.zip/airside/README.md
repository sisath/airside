# Airside

A private, offline text messenger for one iPhone and one Samsung/Android phone. The iPhone hosts a Bluetooth Low Energy service; Android connects to it. The interface follows the warm green design preview, including light/dark mode, quick replies, and a clearly labelled demo.

## Start here

Read [INSTALL.md](INSTALL.md) for installation and the two-phone test checklist. **The iPhone version must be built and signed for your device before the two of you can chat.** A browser demo cannot provide iPhone-to-Android Bluetooth messaging.

For the free Windows route, see [FREE-IPHONE-INSTALL.md](FREE-IPHONE-INSTALL.md). The included GitHub Actions workflow builds an unsigned IPA on a standard cloud Mac; a Windows sideloading tool then signs it locally with a free Apple account. The workflow must actually run successfully before there is an iPhone binary to install.

This is a first version for personal testing, not a published store app. It needs validation on your actual phones before you rely on it during a flight. Keep both apps open, Bluetooth enabled, and the phones nearby. Follow the airline's instructions.

## Included

- One React Native / Expo SDK 58 app for iOS and Android, with Expo Router.
- Native iOS CoreBluetooth peripheral and Android BLE central implementations in `modules/airside-bluetooth/`.
- A random 100-bit pairing code, private service discovery, and authenticated XChaCha20-Poly1305 encryption through the maintained Noble cipher library.
- Fresh session challenges, message acknowledgements, retries, duplicate suppression, and messages queued in memory while disconnected.
- Connection status, manual reconnect, Android reconnect after link loss, permission/error explanations, and screen-awake behaviour while chatting.
- Secure device storage for the name and pairing code; no message-history files, accounts, server, analytics, microphone, contacts, or photo access.
- Browser/native demo mode with a simulated partner. Demo messages never go to another phone.

## Development

Use Node.js 22.13+ (Node 24 recommended) and npm.

```sh
npm ci
npm run check
npm run web
```

The browser is an interface demo. Native Bluetooth is not available through Expo Go or a browser.

### Build using Expo Build (EAS)

These commands require your Expo account. The project has not been linked or uploaded to an account.

```sh
npx eas-cli@latest login
npx eas-cli@latest build:configure
npx eas-cli@latest build --platform android --profile preview
```

The `preview` profile produces a standalone Android APK with its JavaScript bundled, so it does not need a development server or internet after installation. For an iPhone device build, a paid Apple Developer account and registered iPhone are needed with Expo's ad hoc route:

```sh
npx eas-cli@latest device:create
npx eas-cli@latest build --platform ios --profile preview
```

No app is uploaded to either store by these commands. An iOS build will ask for signing credentials and device registration; use your own account.

### Local iPhone build

On a Mac with Xcode and CocoaPods, a free Apple ID can be used for personal-device testing with Apple's provisioning limits. See INSTALL.md. Use a **Release** build for offline use; Debug normally expects a running development server.

```sh
npm ci
npx expo prebuild --platform ios
npx expo run:ios --device --configuration Release
```

If automatic signing needs attention, open the generated Xcode workspace and choose your Personal Team in Signing & Capabilities. The bundle identifier can be changed in app.json if required. Do not edit generated native projects for persistent customisations; use app.json or a config plugin.

### Local Android build

Install Java 21, Android SDK platform 37.0, build tools 37.0.0, NDK 27.1.12297006, and CMake 3.22.1. Set JAVA_HOME and ANDROID_HOME to their installation directories. On Windows, use Ninja 1.12+ to avoid long-path failures; Expo's Windows troubleshooting page is linked below.

```sh
npm ci
npx expo prebuild --platform android
```

Then in `android/`:

```sh
./gradlew assembleRelease -PreactNativeArchitectures=arm64-v8a
```

On Windows use `gradlew.bat`. The generated local template signs release APKs with a development key. This is sufficient for personal sideload testing, **not Play Store distribution**. Use Expo Build's credential management for a store release. The local APK is in `android/app/build/outputs/apk/release/app-release.apk`.

## How the transport works

The code derives a room-specific 128-bit BLE service UUID and, using a separate domain, a 256-bit encryption key from the random pairing code. The code is generated with the operating system's secure random generator, not a user-chosen password. Every encrypted packet has a fresh 192-bit nonce and authentication tag. Possession of the code grants access to the conversation; share it privately and generate a new code if it leaks. There is no forward secrecy or independently verified device identity, and the application has not had an independent security audit.

The GATT service has a write-with-response characteristic for Android-to-iPhone packets and a notify characteristic for iPhone-to-Android packets. Each packet is prefixed with a 4-byte big-endian length. Native code fragments and reassembles it, caps packets at 8 KiB, serialises writes, handles notification backpressure, and times out partial transfers. MTU negotiation changes throughput, not the wire format.

After subscribing, both phones exchange encrypted hello/welcome challenges. Chat packets are bound to the two fresh session identifiers. A message becomes **Delivered** only when the other application acknowledges its ID. A missing acknowledgement causes up to three send attempts before showing a manual Retry action. Received IDs suppress duplicates even if an acknowledgement is lost. On reconnection, unsatisfied outgoing messages are retried while the app remains running. A heartbeat removes the Connected state when the peer stops responding.

Messages exist in memory only, with a 1,000-message limit per visible conversation. Closing/restarting the app loses history and unsent messages. Clearing history affects this device only. The name and code are held in the platform's secure storage and can be removed from Settings. Native callbacks and JS messages are scoped to active connections; no background delivery guarantee is made.

## Verification

```sh
npm run check
npx expo-doctor
npx expo export --platform web
npx playwright install chromium
node scripts/verify-ui.cjs
```

The protocol tests cover encryption/tamper rejection, invalid packet rejection, Unicode, fresh challenges, replay rejection across sessions, simultaneous messaging, lost acknowledgements, bounded retries, offline queues, reconnects, and clear-history deduplication. The browser walkthrough verifies the interactive demo, message status, small-screen layout, dark mode, and settings actions. These checks do not prove physical Bluetooth interoperability or iOS compilation.

## References

- [Expo native module API](https://docs.expo.dev/modules/module-api/)
- [Expo internal distribution and iOS account requirements](https://docs.expo.dev/build/internal-distribution/)
- [Apple Personal Team account limits](https://developer.apple.com/help/account/basics/about-your-developer-account)
- [Expo Windows long-path build guidance](https://docs.expo.dev/troubleshooting/windows-long-paths/)
- [Android Bluetooth permissions](https://developer.android.com/develop/connectivity/bluetooth/bt-permissions)

## License

The Airside source is MIT licensed. Dependencies retain their respective licences.
