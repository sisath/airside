const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const { chromium } = require('@playwright/test');
const root = path.resolve(__dirname, '../dist');
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.ttf': 'font/ttf', '.woff': 'font/woff', '.png': 'image/png' };
const server = http.createServer((req, res) => {
  let url = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
  let file = path.resolve(root, '.' + url);
  if (!file.startsWith(root + path.sep) && file !== root) { res.writeHead(403).end(); return; }
  if (fs.existsSync(file) && fs.statSync(file).isDirectory()) file = path.join(file, 'index.html');
  if (!fs.existsSync(file) && fs.existsSync(file + '.html')) file += '.html';
  if (!fs.existsSync(file)) { res.writeHead(404).end(); return; }
  res.setHeader('Content-Type', mime[path.extname(file)] || 'application/octet-stream');
  fs.createReadStream(file).pipe(res);
});
(async () => {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 1, colorScheme: 'light' });
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  try {
    await page.goto(`http://127.0.0.1:${server.address().port}`, { waitUntil: 'networkidle' });
    await page.getByRole('button', { name: 'Create a chat', exact: true }).waitFor();
    await page.getByRole('button', { name: 'Join a chat', exact: true }).waitFor();
    await page.getByRole('button', { name: 'Create a chat', exact: true }).click();
    await page.getByRole('button', { name: 'Copy chat code', exact: true }).waitFor();
    await page.getByRole('button', { name: 'Back', exact: true }).click();
    await page.getByRole('button', { name: 'Join a chat', exact: true }).click();
    await page.getByLabel('Chat code', { exact: true }).fill('ABC 123');
    await page.getByLabel('Your name', { exact: true }).fill('Taylor');
    await page.screenshot({ path: path.resolve(__dirname, '../../CloseBy-join-preview.png'), fullPage: true });
    await page.getByRole('button', { name: 'Back', exact: true }).click();
    await page.screenshot({ path: path.resolve(__dirname, '../../CloseBy-welcome-preview.png'), fullPage: true });
    await page.getByRole('button', { name: /Try the demo/ }).click();
    await page.getByText('Welcome to the group!', { exact: true }).waitFor();
    await page.getByText('3 people · Your room', { exact: true }).waitFor();
    await page.getByLabel('Message', { exact: true }).fill('Hello everyone');
    await page.getByRole('button', { name: 'Send message', exact: true }).click();
    await page.getByText('Message received!', { exact: true }).waitFor();
    await page.getByText('Same here — connected nearby.', { exact: true }).waitFor();
    await page.getByText(/Delivered/).first().waitFor();
    await page.getByLabel('Photo from S', { exact: true }).waitFor();
    assert.equal(await page.getByLabel('Message', { exact: true }).inputValue(), '');
    await page.screenshot({ path: path.resolve(__dirname, '../../CloseBy-chat-preview.png'), fullPage: true });
    assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), '390px viewport must not overflow');
    await page.setViewportSize({ width: 320, height: 740 });
    assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), '320px viewport must not overflow');
    await page.emulateMedia({ colorScheme: 'dark' });
    await page.screenshot({ path: path.resolve(__dirname, '../../CloseBy-dark-preview.png'), fullPage: true });
    await page.getByRole('button', { name: 'Chat settings', exact: true }).click();
    await page.getByRole('button', { name: 'Clear messages on this phone', exact: true }).click();
    await page.getByRole('button', { name: 'Confirm', exact: true }).click();
    await page.getByRole('button', { name: 'Close settings', exact: true }).click();
    await page.getByText('No messages yet').waitFor();
    await page.getByRole('button', { name: 'Chat settings', exact: true }).click();
    await page.getByRole('button', { name: 'Leave the demo', exact: true }).click();
    await page.getByRole('button', { name: 'Confirm', exact: true }).click();
    await page.getByRole('button', { name: /Try the demo/ }).waitFor();
    assert.deepEqual(errors, [], 'No browser runtime errors');
    console.log('PASS: create/join screens, three-member encrypted room demo, sending, two simulated replies, delivery, empty composer, 320px layout, dark mode, clear history, end chat.');
  } finally { await browser.close(); server.close(); }
})().catch(error => { console.error(error); server.close(); process.exitCode = 1; });
