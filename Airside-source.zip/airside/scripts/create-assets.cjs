const fs = require('node:fs');
const path = require('node:path');
const { PNG } = require('pngjs');
const root = path.resolve(__dirname, '../assets');
function rounded(x, y, l, t, r, b, radius) {
  const qx = Math.abs(x - (l + r) / 2) - (r - l) / 2 + radius;
  const qy = Math.abs(y - (t + b) / 2) - (b - t) / 2 + radius;
  return Math.min(Math.max(qx, qy), 0) + Math.hypot(Math.max(qx, 0), Math.max(qy, 0)) <= radius;
}
function render(size, transparent) {
  const png = new PNG({ width: size, height: size });
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const u = x / size, v = y / size;
    let color = transparent ? [0, 0, 0, 0] : [49, 92, 72, 255];
    const outer = rounded(u, v, .255, .295, .745, .665, .085);
    const inner = rounded(u, v, .275, .315, .725, .645, .065);
    const tail = u >= .29 && u <= .40 && v >= .64 && v <= .75 - (u - .29);
    if ((outer && !inner) || tail) color = [255, 253, 248, 255];
    const hx = (u - .50) / .085, hy = -((v - .48) / .085);
    if (Math.pow(hx * hx + hy * hy - 1, 3) - hx * hx * hy * hy * hy <= 0) color = [220, 235, 214, 255];
    const i = (y * size + x) * 4;
    png.data.set(color, i);
  }
  return PNG.sync.write(png);
}
fs.writeFileSync(path.join(root, 'icon.png'), render(1024, false));
fs.writeFileSync(path.join(root, 'adaptive-icon.png'), render(1024, true));
fs.writeFileSync(path.join(root, 'favicon.png'), render(64, false));
