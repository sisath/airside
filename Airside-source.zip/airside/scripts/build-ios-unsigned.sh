#!/usr/bin/env bash
set -euo pipefail

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo 'An Apple SDK is required. Run this script in the supplied GitHub macOS workflow.' >&2
  exit 1
fi

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUTPUT="$PROJECT_ROOT/build/ios-unsigned"
WORKSPACE="$PROJECT_ROOT/ios/Airside.xcworkspace"
mkdir -p "$OUTPUT"
if [[ ! -d "$WORKSPACE" ]]; then
  echo 'Generate the native project and pods first: npx expo prebuild --platform ios' >&2
  exit 1
fi
if [[ -e "$OUTPUT/Airside-build.xcresult" ]]; then
  echo 'Use a fresh build output directory; an xcresult already exists.' >&2
  exit 1
fi

# This builds for a physical iPhone, not the simulator. Signing happens later,
# locally on Windows, using the user's own free Apple account.
xcodebuild \
  -workspace "$WORKSPACE" \
  -scheme Airside \
  -configuration Release \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  -derivedDataPath "$OUTPUT/DerivedData" \
  -resultBundlePath "$OUTPUT/Airside-build.xcresult" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY='' \
  build 2>&1 | tee "$OUTPUT/xcodebuild.log"

APP="$OUTPUT/DerivedData/Build/Products/Release-iphoneos/Airside.app"
test -d "$APP"
test -s "$APP/main.jsbundle"
EXECUTABLE=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleExecutable' "$APP/Info.plist")
test -s "$APP/$EXECUTABLE"
file "$APP/$EXECUTABLE" | grep -q arm64

STAGE="$(mktemp -d "$OUTPUT/package.XXXXXX")"
mkdir -p "$STAGE/Payload"
ditto "$APP" "$STAGE/Payload/Airside.app"
(
  cd "$STAGE"
  /usr/bin/zip -qry "$OUTPUT/Airside-unsigned.ipa" Payload
)
(
  cd "$OUTPUT"
  shasum -a 256 Airside-unsigned.ipa > Airside-unsigned.ipa.sha256
)
echo "Unsigned device app packaged at $OUTPUT/Airside-unsigned.ipa"
echo 'This IPA must be signed by a sideloading tool before it can be installed.'
