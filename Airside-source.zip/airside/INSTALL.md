# CloseBy 1.2 test and installation notes

Install the new APK on Android. On iPhone, download the successful GitHub run's unsigned IPA and sign it through Sideloadly using the same account/bundle settings as the existing installation. Both platforms need this update; previous 20-character-code builds cannot join 1.2 rooms.

1. Create a chat on one phone and enter a name. The six-character invitation code is displayed as ABC 123.
2. Join from another nearby phone with the code and a name.
3. Compare the verification number on the joining phone with the owner's pending request, then approve on the owner. Reject unexpected or mismatched requests.
4. Send text from each phone and check the participant names and delivery status. Test iPhone/iPhone, Android/Android and both mixed hosting directions.
5. Confirm typing indicators appear on the other phones and disappear after inactivity.
6. In Settings choose Enable message alerts and grant notification permission if desired. Receive a message with Bluetooth connected. Close/suspend the app and verify the UI does not promise reliable background delivery.
7. Select Photo, choose an on-device photo, and wait for transfer progress. Verify every connected recipient sees the image once. Photos are compressed and limited to 64 KB; detailed images may need a smaller selection.
8. Tap Record voice, grant microphone permission, record up to 15 seconds, then Send voice. Test playback on each platform, pause/replay, discard, permission denial, interruption by a call, and backgrounding during recording.
9. Interrupt a media transfer by moving out of range or disabling Bluetooth, then reconnect, approve the new connection and Retry. There is no automatic owner migration or old-history download for late joiners.
10. Check the expiry countdown. Unit tests cover the exact 24-hour boundary; a physical test should also leave a room overnight and reopen after expiry. Cached data is cleared when the app runs again if the OS had suspended it. Copies saved outside the app are outside CloseBy's control.

Keep every app open and the owner nearby. Eight is the software limit, not a measured guarantee of eight simultaneous radio connections on every device. Use Bluetooth only when airline and crew instructions allow it.
