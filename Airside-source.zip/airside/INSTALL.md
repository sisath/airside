# CloseBy installation and group test

## Install

- Android: install CloseBy-android-test.apk. This is a personal-test ARM64 release using a development signing key, not a Play Store release.
- iPhone: build the supplied macOS GitHub workflow, extract its unsigned IPA, and sign/install it with Sideloadly and your own Apple account. Free-account installs normally need refreshing every seven days. Keep the same account and bundle identifier to update the installed app. You must handle Apple authentication and iPhone developer-trust prompts yourself.
- Every participant needs the CloseBy group build. The original Airside two-person protocol cannot join these rooms.

## Start a room

1. On any supported phone, choose Create a chat, enter a display name, and create the room.
2. The owner can copy the code before opening the room, or reveal it from chat settings. Keep it private.
3. On up to seven other phones choose Join a chat, enter a name and the full code, then Join chat.
4. Allow Bluetooth/Nearby devices access. On Android, hosting additionally requires BLE advertising support. Unsupported phones show an error and can still try joining another owner's room.
5. Keep all apps open, Bluetooth on, and everyone close to the owner. A phone that leaves may need Reconnect. If the owner ends the room, guests must reconnect to a new or reopened room.

## Physical validation checklist

- Test two iPhones, two Android phones, and each mixed owner/joiner combination.
- With at least three phones, verify the participant names/count and send from every phone; each other connected member must receive exactly one copy with the correct name.
- Turn Bluetooth off on one recipient while another sends. Confirm the message is not falsely Delivered to everyone. Restore Bluetooth, reconnect, and test Retry.
- Join late and verify previous room history is not downloaded.
- Try the wrong code. Verify it does not join or decrypt another room.
- Leave/end the owner's room and verify guest status becomes disconnected. There is no owner migration.
- Check small screens, dark mode, permission denial, screen locking, Bluetooth toggling, and practical range. Foreground-only behavior means locking or backgrounding can interrupt the room.
- Follow airline and crew instructions before using Bluetooth on board.

Eight is the software room limit, not a verified guarantee of eight simultaneous physical Bluetooth connections on every phone. Radio interoperability, range and battery use must be checked on actual hardware.
