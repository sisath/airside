# CloseBy 1.3 device checklist

Install the Android APK on supported ARM64 Android phones. Install the unsigned iPhone IPA through Sideloadly using your existing Apple account; free signatures need periodic refresh. Update every participant to 1.3 for video support.

1. Create a room, join from another phone, compare verification numbers and approve. Send text, a photo and a voice message.
2. Return home, enter the demo, return home and reopen the real room. Previous messages/media should appear with the original expiry. Reapprove reconnections when prompted.
3. Close and reopen the app, then reopen the same room. History should still be present. Unconfirmed messages require explicit Retry and should not duplicate a delivered message.
4. With both phones nearby, tap Record video. Grant camera/microphone access, record a short clip under five seconds, and confirm it in the system camera. Clips above 1 MB are rejected; use a shorter clip. Keep the room open while the chunked transfer completes. Tap the video bubble to play; Close video releases the player.
5. Test a video in both directions. If the system camera interrupted Bluetooth, reconnect before retrying. Transfers may take several minutes.
6. Clear messages: history should remain empty after demo switching and app restart. Leaving a room should preserve its history. Expired history should disappear while running or on next launch/resume.

Fully offline delivery is not reliable while the app is suspended or closed. No internet push services are used. Room expiry is based on phone clocks.
