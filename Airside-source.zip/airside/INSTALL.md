# Install and try Airside

## What is still needed

You need Airside installed on **both phones**. The iPhone app must be compiled and signed using your Apple account. Windows cannot run Xcode, and no Apple signing identity was provided in this session. The iOS source is included, but an installable iPhone binary cannot be produced here. Neither phone-to-phone Bluetooth behaviour nor iOS compilation has been verified on physical devices.

The Samsung can use the included **Airside-android-test.apk** directly; a Google Play account is unnecessary for this personal test. It is an **ARM64 personal-test release**, signed with a development key, for Android 7 or newer. It bundles the app, so it works without a development server. It is not a Play Store release.

## Samsung / Android

1. Transfer the Airside APK to the Samsung before travelling.
2. Open it to install. Android may ask you to allow installation from the app that opened the file. On Samsung, Auto Blocker may prevent installation from outside a store; if you choose to change this, restore your security settings afterwards.
3. Open Airside. Enter her name and the code shown on the iPhone.
4. Tap **Find our chat**, then allow **Nearby devices**. On Android 11 and earlier the operating system requires location permission for BLE scanning, and location services may also need to be enabled. Airside does not collect location.

No Play Store publication or payment is needed for a personal APK installation. If a prior installation with a different signing key exists, it must be removed before installing this build; uninstalling loses its saved settings.

## iPhone: free personal testing with a Mac

This route needs access to a Mac with Xcode, Node.js, and CocoaPods, plus your iPhone and Apple ID.

1. Copy the source project to the Mac and run `npm ci`.
2. Run `npx expo prebuild --platform ios` to generate the Xcode workspace and install pods.
3. Open `ios/Airside.xcworkspace` in Xcode. Under the Airside app target's **Signing & Capabilities**, choose your **Personal Team** and enable automatic signing. Choose a unique bundle identifier if Xcode requests one; change it in app.json for future generated builds too.
4. Connect the iPhone, trust the Mac, and enable Developer Mode if iOS asks.
5. Build for your iPhone in **Release** configuration. In Xcode, use Product > Scheme > Edit Scheme > Run > Build Configuration > Release, then run. Alternatively use `npx expo run:ios --device --configuration Release` once signing is configured.
6. Open Airside independently of the Mac and allow Bluetooth access. Confirm it still opens when Wi-Fi and mobile data are off.

Apple's free Personal Team provisioning has short validity limits (typically seven days), so rebuild shortly before your flight. Check [Apple's account limits](https://developer.apple.com/help/account/basics/about-your-developer-account). Expo Go does not contain the custom Bluetooth module and cannot substitute for this build.

## iPhone: cloud build with a paid Apple Developer account

There is also a free Windows option: use the included GitHub cloud build and sign the resulting IPA locally using a free Apple account. See [FREE-IPHONE-INSTALL.md](FREE-IPHONE-INSTALL.md). The steps below describe the separate paid Expo signing route.

If you do not have a Mac, use Expo's cloud build service with your own Expo login and paid Apple Developer account. Do not put passwords into source files.

```sh
npm ci
npx eas-cli@latest login
npx eas-cli@latest build:configure
npx eas-cli@latest device:create
npx eas-cli@latest build --platform ios --profile preview
```

Register your actual iPhone before building. Expo will guide you through signing and give you the installation link. The project identifier must be configured for your account by the CLI. See [Expo's internal distribution documentation](https://docs.expo.dev/build/internal-distribution/). No account was created, charged, or signed into during this work.

## Pair the two phones

1. Open the iPhone app, enter your name, and copy its pairing code. Send it privately to her beforehand or let her type it while you are together. A code contains 20 characters in four groups of five; it has no I, O, 0, or 1.
2. On the iPhone tap **Open our chat**.
3. On the Samsung enter the same code and tap **Find our chat**.
4. Keep both apps in front. Both should show the other person's name and **Connected nearby**. Only then has the private session been verified.
5. Type a message. **Delivered** means it reached the other app, not that your partner has read it.

## Test before relying on it

- Put both phones in airplane mode, then re-enable Bluetooth as permitted by the airline. Turn Wi-Fi off for this test.
- Open both standalone apps without a computer or development server.
- Exchange messages in both directions, including emoji, accented/non-Latin text, and a long message.
- Switch Bluetooth off on the Samsung. A message on the iPhone should remain queued or unacknowledged, never falsely Delivered.
- Turn Bluetooth back on; tap **Reconnect** on both phones if necessary. Confirm the queued message arrives once.
- Walk apart and back together to check your actual useful range.
- Check that Settings can reveal/copy the saved pairing code, clear only your local messages, end the chat, and forget saved pairing.
- Expect interruptions if either app is backgrounded or its screen is locked. This version deliberately keeps the chat display awake; it does not promise background delivery.

Use the app only when crew instructions permit Bluetooth use. Close it when you finish to stop keeping the display awake.

## Troubleshooting

- **No connection:** confirm exactly the same pairing code, both apps open, and Bluetooth enabled. Tap Reconnect on both. Ensure the iPhone created/hosts the chat; this first version does not support two Android hosts or two iPhones.
- **Permission denied:** enable Bluetooth for Airside on iOS or Nearby devices on Android in device Settings, then reconnect. For Android 11 and earlier, check location permission and the system location switch too.
- **Cannot find native module / Expo Go:** install a native build. The demo does not test real Bluetooth.
- **Queued / Sending / Not delivered:** the other app has not acknowledged the message. Keep both apps open and reconnect; tap the retry label if needed.
- **Old messages gone:** messages are intentionally temporary and are lost when the app closes. They are not backed up or sent to a server.
